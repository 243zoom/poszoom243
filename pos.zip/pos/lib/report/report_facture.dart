import 'package:flutter/material.dart';
import 'dart:io';

import 'package:pdf/widgets.dart' as pw;

class PDF extends StatefulWidget {
  @override
  _PDFState createState() => _PDFState();
}
final doc = pw.Document();
class _PDFState extends State<PDF> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
