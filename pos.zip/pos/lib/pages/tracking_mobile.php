<?php



$bdd=new PDO('mysql:dbname=robisarl_gpsdb; host=108.167.189.78; charset=utf8','robisarl_ruessi','Ruessi1234_'); 

$json = file_get_contents('php://input'); 
$obj = json_decode($json,true);

$mobile = $obj['mobile'];  
$date_send =date('y-m-d'); 
//insert into table 

$r=$bdd->query("INSERT INTO `tracking_mobile`(`number`, `date_tracking`) VALUES ('$mobile','$date_send')");





?>