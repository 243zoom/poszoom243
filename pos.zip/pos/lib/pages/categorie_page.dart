

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/categorieModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/commons/narrow_app_bar.dart';
import 'package:smartpos/pages/Commande_client_page.dart';
import 'package:smartpos/pages/UI.dart';
import 'package:smartpos/pages/add_categorie.dart';
import 'package:smartpos/pages/sous_categoriePage.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/pages/Login_page.dart';

import 'package:smartpos/pages/parametre_pos.dart';

class CategoriePage extends StatefulWidget {
  @override
  CategoriePageState createState() => CategoriePageState();
}
@override
class CategoriePageState extends State<CategoriePage> {
  int compteur;
  String userSearchInput = "";
  TextEditingController categorie_text = TextEditingController();
  TextEditingController search=TextEditingController();
  ScrollController _scrollController =ScrollController();
@override
void initState() {
  super.initState();
   setState(() {
     Load_Cat();
   });
  //dispose();
}
  Future<List<CategorieModel>> Load_Cat() async {
    var data= await DBProvider_new.db.getAllCategorie();
    return data;
  }

  startTimer()async{

    var dur=Duration(seconds: 1);
    return Timer(dur,route);
  }

  route(){
    Navigator.of(context).pop();
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => super.widget));


  }
  List<CategorieModel> list = List<CategorieModel>();
  List<CategorieModel> filteredList = List<CategorieModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.Categorie.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }


  Widget build(BuildContext context) {

    Future _showDialogLoad(context) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        SpinKitCircle(
                          color: Colors.blue,
                          size: 35.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

    //Future<CategorieModel> yourAsyncFetch() => Future.delayed(Duration(seconds: 3), () =>  CategorieModel());
    Future _showDialogCategorie(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: categorie_text,
                                  decoration: new InputDecoration(labelText: "Categorie",
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: FlatButton(onPressed: (){
                                      if(categorie_text.text.toString().isEmpty){
                                        MessageToast m=MessageToast('Veuillez saisir la categorie !');
                                        m.ShowMessage();
                                      }else{
                                        CategorieModel categorieModel= CategorieModel(Categorie:categorie_text.text.toString());
                                        DBProvider_new.db.newCategorie(categorieModel);
                                        print("Success");
                                        categorie_text.clear();
                                        Navigator.of(context).pop();

                                        startTimer();
                                        _showDialogLoad(context);

                                        setState(() {
                                          Load_Cat();
                                        });
                                      }
                                    },
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(18.0),
                                            side: BorderSide(color: Colors.blue[700])
                                        ),
                                        color: Colors.blue[700],
                                        child: Text("Ajouter",style: TextStyle(color: Colors.white),) ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

    Future _showDialogEdit(context,String item,int id) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: categorie_text,
                                  decoration: new InputDecoration(labelText: item,
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: FlatButton(onPressed: (){
                                      if(categorie_text.text.toString().isEmpty){
                                        MessageToast m=MessageToast('Veuillez saisir la categorie !');
                                        m.ShowMessage();
                                      }else{
                                       // CategorieModel categorieModel= CategorieModel(Categorie:categorie_text.text.toString());
                                       DBProvider_new.db.EditCategorie(categorie_text.text.toString(),id);

                                        print("Modify");
                                        categorie_text.clear();
                                        Navigator.of(context).pop();

                                        startTimer();
                                        _showDialogLoad(context);

                                        setState(() {
                                          Load_Cat();
                                        });
                                      }
                                    },
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(18.0),
                                            side: BorderSide(color: Colors.blue[700])
                                        ),
                                        color: Colors.blue[700],
                                        child: Text("Modifier la categorie",style: TextStyle(color: Colors.white),) ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );
    }

    //Confirme to delete

    Future _showDialogDelete(context,int id) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        Text('Voulez-vous confirmer la suppression ?',style: TextStyle(color: Colors.black),),
                        SizedBox(height: 11,),
                        Row(
                          children: [
                            InkWell(
                              onTap: (){


                                Navigator.of(context).pop();

                                DBProvider_new.db.deleteCategorie(id.toString());

                               /* Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));*/


                                setState(() {



                                });
                              },
                              child: Text('Oui',style: TextStyle(color: Colors.blue),),
                            ),
                            Spacer(),
                            InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));
                              },
                              child: Text('Non',style: TextStyle(color: Colors.red),),
                            )
                          ],
                        )
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

    final orientation = MediaQuery.of(context).orientation;
    var now = DateTime.now();
    String d= DateFormat().format(now);

    return Scaffold(

     // backgroundColor: Colors.blueGrey[100],

      body:  Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
          children: [

            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Categories',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),
            Container(
              height: 60,
              color: Colors.white.withOpacity(0.5),
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: TextField(
                    controller: search,
                    onChanged: (value) {
                      _filterList(value);
                    },
                    decoration: InputDecoration(
                        border: InputBorder.none,

                        prefixIcon: Icon(Icons.search),
                        hintText: "Recherche",
                        hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                  ),
                ),
              ),
              //color: Colors.black12.withOpacity(0.5),
            ),


            Expanded(
                child: Container(
                  color: Colors.white.withOpacity(0.5),
                  child: FutureBuilder<List<CategorieModel>>(
                      future: DBProvider_new.db.getAllCategorie(),

                      builder: (BuildContext context, AsyncSnapshot<List<CategorieModel>> snapshot) {
                        if (snapshot.hasData) {
                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          }
                          return GridView.builder(
                              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 200,
                                  childAspectRatio: 4 / 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10),
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length,

                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                        child: Center(
                                          child: InkWell(
                                            onTap: (){
                                              //load sous categorie 
                                              Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (context) => Sous_CategoriePage(filteredList[index].id),
                                              ),
                                            );
                                            },
                                          child:Container(
                                              width: 150,
                                              //height: double.infinity,
                                              child: Stack(

                                                children: [
                                                  Container(
                                                    // semanticContainer: true,
                                                    // clipBehavior: Clip.antiAliasWithSaveLayer,
                                                      child:Center(
                                                        child: Padding(
                                                          padding: const EdgeInsets.only(top:25.0,right: 5.0,bottom: 25),
                                                          child: Image(
                                                            image: AssetImage(
                                                              'assets/menu/categories.png',
                                                            ),
                                                            width: 90,
                                                          ),
                                                        ),
                                                      )
                                                    /*shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                elevation: 5,*/
                                                    // margin: EdgeInsets.all(10),
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets.all(8.0),
                                                    child: Container(
                                                      width: 140,
                                                      height: 140,

                                                      //   color: Colors.blueGrey[900].withOpacity(0.5),
                                                      child: Stack(
                                                        children: [
                                                          Align(
                                                            alignment: Alignment(0.0,1.0),
                                                            child: Container(
                                                              height: 30,
                                                              color: Colors.white,
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                children: [

                                                                  InkWell(
                                                                    onTap: (){
                                                                      _showDialogEdit(context,filteredList[index].Categorie,filteredList[index].id);
                                                                    },
                                                                    child: Icon(Icons.edit,size: 20,color: Colors.blue,),
                                                                  ),
                                                                  SizedBox(width: 5,),
                                                                  Text(filteredList[index].Categorie.toString()),
                                                                  SizedBox(width: 5,),
                                                                  InkWell(
                                                                    onTap: (){
                                                                      _showDialogDelete(context,filteredList[index].id);
                                                                    },
                                                                    child: Icon(Icons.delete,size: 20,color: Colors.red,),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                      decoration: BoxDecoration(
                                                        //color: Colors.white,
                                                        color: Colors.blueGrey[900].withOpacity(0.5),
                                                        borderRadius: BorderRadius.all(
                                                          Radius.circular(15) ,

                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              )
                                           ) ,
                                          ),
                                        )
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                )



            ),

          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add,color: Colors.white,),
       // backgroundColor: Colors.deepOrange,
        backgroundColor: Colors.blue[700],
        onPressed: (){
          //AddCategorieDialog(context);

          _showDialogCategorie(context);
          setState(() {
            Load_Cat();
          });

        },
      ),
    );
  }
}
