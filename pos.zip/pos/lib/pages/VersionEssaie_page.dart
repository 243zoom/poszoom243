import 'package:flutter/material.dart';
import 'package:smartpos/pages/Profile_page.dart';

class MessageEssaieDefaultPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
backgroundColor: Colors.white,
      body: Column(

        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Center(
            child: Container(
              child: Icon(Icons.timer,size: 50,color: Colors.grey,),
            ),
          ),

          SizedBox(height: 10,),

          Container(
            child:Text("Vous utilisez l'application en essaie de 7 jours",style: TextStyle(color: Colors.blue),),

          ),

          Padding(
            padding: const EdgeInsets.all(10.0),
            child: FlatButton(onPressed: (){

              Navigator.pushReplacement(context, MaterialPageRoute(

                  builder:(context)=> Profile_UI()

              )
              );

            },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                    side: BorderSide(color: Colors.blueAccent)
                ),
                color: Colors.blueAccent,
                child: Text("Continuer",style: TextStyle(color: Colors.white),) ),
          ),

        ],
      ),
    );
  }
}
