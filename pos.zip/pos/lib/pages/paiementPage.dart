
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/pages/Appercu_facture.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';

class Historique_page extends StatefulWidget {
  @override
  _Historique_pageState createState() => _Historique_pageState();
}
String prix="";
class _Historique_pageState extends State<Historique_page> {
  ScrollController _scrollController =ScrollController();
  TextEditingController search=TextEditingController();

  @override


  List<CommandeModel> list = List<CommandeModel>();
  List<CommandeModel> filteredList = List<CommandeModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.view_client.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }


  Widget build(BuildContext context) {

    void Prix(String pd) async {
      String count = await   DBProvider_new.db.getPrix_produit(pd);
      setState(() => prix = count);
    }
    Future<String>Name_produitById(String  id_parse)async{
      String name=await DBProvider_new.db.getViewProduitNameByID(id_parse);
      return name;
    }

    Future<String>Name_ClientById(String  id_parse)async{
      String name=await DBProvider_new.db.getViewProduitClientByID(id_parse);
      return name;
    }

    var now = DateTime.now();
    String d= DateFormat().format(now);


    return  Scaffold(



      body:  Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
         // crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[

            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 70,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Paiements',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),

            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),



            Container(
            color:Colors.white.withOpacity(0.5),
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: TextField(
                    controller: search,
                    onChanged: (value) {
                      _filterList(value);
                    },
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.search),
                        hintText: "Recherche",
                        hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                  ),
                ),
              ),
              //color: Colors.black12.withOpacity(0.5),
            ),

            Expanded(
                child: Container(
                  color: Colors.white.withOpacity(0.5),
                  child: FutureBuilder<List<CommandeModel>>(
                      future: DBProvider_new.db.getAllCommande(),

                      builder: (BuildContext context, AsyncSnapshot<List<CommandeModel>> snapshot) {
                        if (snapshot.hasData) {
                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          }
                          return ListView.builder(
                            /*  gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 200,
                                  childAspectRatio: 4 / 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10),*/
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length,

                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                        child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Card(
                                              elevation: 2,
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                              child: ListTile(
                                                title: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Icon(Icons.person,color: Colors.grey,),
                                                        SizedBox(width: 5,),
                                                        Text(
                                                            filteredList[index].view_client
                                                        ),
                                                        Spacer(),
                                                        Icon(Icons.date_range,size: 18,color: Colors.grey[500],),
                                                        Text(
                                                          filteredList[index].date_commande,
                                                          style: TextStyle(fontSize: 15,color: Colors.grey[500]),
                                                        )
                                                      ],
                                                    ),
                                                    SizedBox(height: 5,),

                                                    Row(
                                                      children: [
                                                        Row(
                                                          children: [

                                                            Icon(Icons.shopping_cart_rounded,color: Colors.amber,size: 18,),
                                                            SizedBox(width: 5,),

                                                            Text(
                                                              filteredList[index].view_produit,
                                                            ),

                                                            SizedBox(width: 7,),
                                                            Row(
                                                          children: [
                                                            Container(
                                                              
                                                            // decoration: BoxDecoration(shape: BoxShape.circle, color: primaryColor),
                                                              child: Center(
                                                                child: Text(' Qt : ' +
                                                                  filteredList[index].quantite,
                                                                  style: TextStyle(color: Colors.black),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                           /* Container(
                                                              width: 25,
                                                              height: 25,
                                                              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.brown),
                                                              child: Center(
                                                                child: Text(
                                                                  filteredList[index].quantite,
                                                                  style: whiteSubHeadingTextStyle,
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ),
                                                            ),*/


                                                          ],
                                                        ),

                                                      ],
                                                    ),


                                                    /* Text(
                                          ''+item.quantite,
                                          style: TextStyle(fontSize: 18,color: Colors.grey[900]),
                                        ),*/

                                                  ],
                                                ),
                                                /*onTap: (){
                                      Prix(item.produit_id);
                                      Navigator.push( context, MaterialPageRoute( builder: (context) => Appercu(item.quantite,item.produit_id,"100")), ).then((value) => setState(() {

                                        // Load_Produit();
                                      }));
                                    },*/

                                              ),

                                            )
                                        )
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                )



            ),
          ],
        ),
      ),
    );
  }
}
