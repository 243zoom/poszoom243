import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/class_dart/categorieModel.dart';
import 'package:smartpos/class_dart/hotreload.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/commons/narrow_app_bar.dart';
import 'package:smartpos/pages/add_produit_page.dart';
import 'package:smartpos/pages/modifier_produit_page.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';

 String yes="";
class ProduitPage extends StatefulWidget {
  @override
  String handler;
  _ProduitPageState createState() => _ProduitPageState();
}
class _ProduitPageState extends State<ProduitPage> {
  @override
  String searchDialogSource;

  File imageFile;
 String  _currentCategorieModel="";
  Uint8List _bytesImage;
  String  base64Image;
  TextEditingController _produit=TextEditingController();
  TextEditingController _prix=TextEditingController();
  TextEditingController stock_ctr=TextEditingController();
  String userSearchInput = "";
  TextEditingController categorie_text = TextEditingController();
  TextEditingController search=TextEditingController();
  ScrollController _scrollController =ScrollController();

  int number =0 ;
  List _device = [
    "Devise",
    "CDF",
    "USD"
  ];

  List<DropdownMenuItem<String>> _dropDownMenuItems;
  String _currentDevice;

  void countPeople() async {
    int count = await DBProvider_new.db.getCountProduit();
    setState(() => number = count);
  }
  List<ProduitModel> list = List<ProduitModel>();
  List<ProduitModel> filteredList = List<ProduitModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.Produit.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }

  Future<void> _showSelectionDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text("From where do you want to take the photo?"),
              content:  SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    GestureDetector(
                      child: Text("Gallery"),
                      onTap: () {
                        _openGallery(context);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text("Camera"),
                      onTap: () {
                        // _openCamera(context);
                        getImageFromCamera();
                      },
                    )
                  ],
                ),
              )
              );
        });
  }

  Future getImageFromCamera() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    List<int> imageBytes = image.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + image.path);
    _bytesImage = Base64Decoder().convert(base64Image);
    setState(() {
      imageFile = image;
      DBProvider_new.db.getAllCategorie();
      Navigator.of(context).pop();

    });


  }

  void _openGallery(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.gallery);
    List<int> imageBytes = picture.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
  //  img= Image.memory(base64Decode(base64Image));
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + picture.path);
    this.setState(() {
      imageFile = picture;
      Navigator.of(context).pop();
    });
    // Navigator.of(context).pop();
  }

  _setImageView() {
    if (imageFile != null) {
      return Image.file(imageFile);
    } else {
      // return Text("Please select an image");

      return Icon(
        Icons.image,
        color: Colors.grey,
        size: 30,
      );
    }
  }

@override
  void initState() {
  _dropDownMenuItems = getDropDownMenuItems();
  _currentDevice = _dropDownMenuItems[0].value;

    // TODO: implement initState
    super.initState();

  setState(() {
    Load_Produit();
  });
}
  List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = new List();
    for (String city in _device) {
      items.add(new DropdownMenuItem(value: city, child: new Text(city)));
    }
    return items;
  }
  void changedDropDownItem(String selectedCity) {
    setState(() {
      _currentDevice = selectedCity;
    });
  }
  Future<Null> _onRefresh() async{
    Completer<Null> completer = new Completer<Null>();
    Timer timer = new Timer(new Duration(seconds: 1), () {

      completer.complete();

    });
    return completer.future;
  }

  Future<List<ProduitModel>> Load_Produit() async {
    var data= await DBProvider_new.db.getAllProduit();
    return data;
  }
  @override

  Future _showDialogProduit(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      TextField(
                        autofocus: true,
                        controller: _produit,
                        decoration: new InputDecoration(
                          labelText: 'Produit',
                        ),
                      ),
                      Column(
                        //mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        // mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            child:  TextField(
                              autofocus: true,
                              controller: _prix,
                              keyboardType: TextInputType.number,
                              inputFormatters: <TextInputFormatter>[
                                WhitelistingTextInputFormatter.digitsOnly
                              ],
                              decoration: new InputDecoration(
                                labelText: 'Prix',
                              ),

                            ),
                          ),
                          Container(
                            child:  TextField(
                              autofocus: true,
                              controller: stock_ctr,
                              keyboardType: TextInputType.number,
                              inputFormatters: <TextInputFormatter>[
                                WhitelistingTextInputFormatter.digitsOnly
                              ],
                              decoration: new InputDecoration(
                                labelText: 'Stock',
                              ),

                            ),
                          ),
                          Container(

                            child:  DropdownButton(
                              value: _currentDevice,
                              items: _dropDownMenuItems,
                              // style: GoogleFonts.lato(color: Colors.grey[800]),
                              onChanged: changedDropDownItem,
                              elevation: 2,
                            ),
                          )
                          //Device

                        ],
                      ),

                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.max,
                          children: <Widget>[
                            FutureBuilder<List<CategorieModel>>(
                                future: DBProvider_new.db.getAllCategorie(),
                                builder: (BuildContext context,
                                    AsyncSnapshot<List<CategorieModel>> snapshot) {
                                  if (!snapshot.hasData) return CircularProgressIndicator();
                                  return DropdownButton<CategorieModel>(
                                    items: snapshot.data
                                        .map((user) => DropdownMenuItem<CategorieModel>(
                                      child: Text(user.Categorie),
                                      value: user,
                                    ))
                                        .toList(),
                                    onChanged: (CategorieModel value) {
                                      setState(() {
                                        //_currentUser = value;
                                        _currentCategorieModel=  value.Categorie;
                                      });
                                    },
                                    // isExpanded: false,
                                    //value: ,
                                    hint: Text('Categorie $_currentCategorieModel'),
                                  );
                                }),

                            // Text("$_currentCategorieModel" ),
                          ],
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.only(left:0.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,

                          children: [
                            InkWell(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text('image '),
                                  SizedBox(width: 2,),
                                  Container(
                                    width: 30,height: 30,
                                    child: _setImageView(),
                                  ),
                                ],
                              ),
                              onTap: () {

                                setState(() {
                                  _showSelectionDialog(context);
                                });
                              },
                            ),
                          ],
                        ),
                      )

                      //your code dropdown button here
                    ]);

            },
          ),

          actions: [
            FlatButton(onPressed: (){
              setState(() {
                if(_produit.text.toString().isEmpty){
                  print('champ produit vide !');
                } else if(_prix.text.toString().isEmpty) {
                  print('champ prix vide');
                }
                else if( _currentCategorieModel==""){
                  MessageToast m=MessageToast('Categorie vide !');
                  m.ShowMessage();
                }else if(base64Image==null){
                  MessageToast m=MessageToast('l\'image du produit vide !');
                  m.ShowMessage();
                }else if(_currentDevice=="devise"){
                  MessageToast m=MessageToast('Selectionnez la devise !');
                  m.ShowMessage();
                }
                else {
               /*   ProduitModel produit_m=ProduitModel(Produit: _produit.text.toString(),Categorie: _currentCategorieModel,image: base64Image,prix: _prix.text.toString(),devise: _currentDevice);
                  DBProvider_new.db.newProduit(produit_m);
                  Load_Produit();
                  print('sucess  cat $_currentCategorieModel and device $_currentDevice' );
                  Navigator.of(context).pop();
                  _produit.clear();
                  _prix.clear();*/
                  /*
                   */
                }
              });
            }, child: Text('Ajouter',style: TextStyle(color: Colors.white),),color: Colors.blue,)
          ],

        );

      },
    );

  }

  Future _showDialogDelete(context,int id) async {

    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[

                      Text('Voulez-vous confirmer la suppression ?',style: TextStyle(color: Colors.black),),
                      SizedBox(height: 11,),
                      Row(
                        children: [
                          InkWell(
                            onTap: (){


                              Navigator.of(context).pop();

                              DBProvider_new.db.deleteProduit(id);

                              /* Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));*/

                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (BuildContext context) => super.widget));
                            },
                            child: Text('Oui',style: TextStyle(color: Colors.blue),),
                          ),
                          Spacer(),
                          InkWell(
                            onTap: (){
                              Navigator.of(context).pop();
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (BuildContext context) => super.widget));
                            },
                            child: Text('Non',style: TextStyle(color: Colors.red),),
                          )
                        ],
                      )
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }

  Widget build(BuildContext context) {
    var now = DateTime.now();
    String d= DateFormat().format(now);

    return Scaffold(

      body:  Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,
            )
        ),
        child: Column(
          children: [

            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Produits',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 16),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

            Container(
              color:Colors.white.withOpacity(0.5),
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: TextField(
                    controller: search,
                    onChanged: (value) {
                      _filterList(value);
                    },
                    decoration: InputDecoration(
                        border: InputBorder.none,

                        prefixIcon: Icon(Icons.search),
                        hintText: "Recherche",
                        hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                  ),
                ),
              ),
              //color: Colors.black12.withOpacity(0.5),
            ),

            Expanded(
                child: Container(
                  color:Colors.white.withOpacity(0.5),
                  child: FutureBuilder<List<ProduitModel>>(
                      future: DBProvider_new.db.getAllProduit(),
                      builder: (BuildContext context, AsyncSnapshot<List<ProduitModel>> snapshot) {
                        if (snapshot.hasData) {
                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          }

                          return GridView.builder(
                              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 200,
                                  childAspectRatio: 3 / 2,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10),
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length,

                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                      child: Center(
                                        child: Container(
                                            width: 150,
                                            //height: double.infinity,
                                            child: Stack(

                                              children: [
                                                Container(
                                                  // semanticContainer: true,
                                                  // clipBehavior: Clip.antiAliasWithSaveLayer,
                                                    child:Center(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(top:25.0,right: 5.0,bottom: 25),
                                                        child: filteredList[index].image == null
                                                            ? new Text('No image.')
                                                            :  Image.file(
                                                          File(filteredList[index].image.toString()),
                                                          fit: BoxFit.contain,
                                                          width: 90,
                                                        ),
                                                      ),
                                                    )
                                                  /*shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                elevation: 5,*/
                                                  // margin: EdgeInsets.all(10),
                                                ),
                                                Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Container(
                                                    width: 140,
                                                    height: 140,

                                                    //   color: Colors.blueGrey[900].withOpacity(0.5),
                                                    child: Stack(
                                                      children: [
                                                        Align(
                                                          alignment: Alignment(0.0,0.0),
                                                          child: Container(
                                                           // width: 30,
                                                            height: 30.5,                                       
                                                            decoration: BoxDecoration(
                                                      //color: Colors.white,
                                                          /*color: Colors.amber.withOpacity(0.9),
                                                          borderRadius: BorderRadius.all(
                                                            Radius.circular(15) ,

                                                          ),*/
                                                        ),
                                                            child: Padding(
                                                              padding: const EdgeInsets.all(8.0),
                                                              child: Text( filteredList[index].devise+' : '+filteredList[index].prix,style: TextStyle(color: Colors.white,fontSize: 14),),
                                                            ),
                                                          ),
                                                        ),
                                                        Align(
                                                          alignment: Alignment(0.0,1.0),
                                                          child: Container(
                                                            height: 30,
                                                           // color: Colors.white.withOpacity(0.2),
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                              children: [

                                                                InkWell(
                                                                  onTap: (){
                                                                    // _showDialogEdit(context,filteredList[index].Categorie,filteredList[index].id);
                                                                    Navigator.pushReplacement(
                                                                        context, MaterialPageRoute(builder: (context) => modifier_produit(filteredList[index].id,filteredList[index].Produit,filteredList[index].prix)));
                                                                    /*Navigator.of(context).push(
                                                                      MaterialPageRoute(
                                                                        builder: (context) => modifier_produit(filteredList[index].id,filteredList[index].Produit,filteredList[index].prix),
                                                                      ),
                                                                    );*/
                                                                  },
                                                                  child: Icon(Icons.edit,size: 20,color: Colors.blue[700],),
                                                                ),
                                                                SizedBox(width: 10,),
                                                                Text(filteredList[index].Produit.toString(),style: TextStyle(color: Colors.white),), 
                                                                SizedBox(width: 10,),

                                                                InkWell(
                                                                  onTap: (){
                                                                   _showDialogDelete(context,filteredList[index].id);
                                                                  },
                                                                  child: Icon(Icons.delete,size: 20,color: Colors.red,),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    decoration: BoxDecoration(
                                                      //color: Colors.white,
                                                      color: Colors.blueGrey[900].withOpacity(0.4),
                                                      borderRadius: BorderRadius.all(
                                                        Radius.circular(15) ,

                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            )
                                        ),
                                      ),
                                     
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                )



            ),

          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add,color: Colors.white,),
        // backgroundColor: Colors.deepOrange,
        backgroundColor: Colors.blue[700],
        onPressed: (){
          //AddCategorieDialog(context);
          //Load_Produit();
          //Navigator.of(context).pop();
   Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => Add_produit()));

          /*Navigator.push( context, MaterialPageRoute( builder: (context) => Add_produit()), ).then((value) => setState(() {
            // Load_Produit();
          }));*/

        },
      ),
    );
  }
}