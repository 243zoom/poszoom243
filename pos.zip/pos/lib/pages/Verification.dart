import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:get_mac/get_mac.dart';
import 'package:smartpos/pages/DemandeAct_Page.dart';
import 'package:smartpos/pages/Profile_page.dart';
import 'package:smartpos/pages/UI.dart';
import 'package:smartpos/pages/demandeActivation.dart';
class VerificationPage extends StatefulWidget {
  @override
  _VerificationPageState createState() => _VerificationPageState();
}

class _VerificationPageState extends State<VerificationPage> {
  String _platformID = 'Unknown';

  Future Verication(String adresse_mac) async{

    //String adresse_mac="123456789";
    var url = 'http://apirobipos.zoom243.com/index.php';

    // Store all data with Param Name.
    var data = {'adresse': adresse_mac};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.

    if (response.statusCode == 200) {
      // If the call to the server was successful, parse the JSON
     // List<dynamic> values=new List<dynamic>();
     // values = json.decode(response.body);

      Map<String, dynamic> data = json.decode(response.body);
      String  req = data["true"].toString();

      print('nst '+req.toString());

      if(req=="no_found"){
        //print('not actver'+req.toString());

        //donne une periode d'essaie
        Navigator.pushReplacement(context, MaterialPageRoute(

            builder:(context)=> DemandeActiviation()

        )
        );
      } else if(req=="invalide"){
        //fenetre de demande d'activation

        Fluttertoast.showToast(
            msg: "Application expirée,Veuillez le réactiver",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0
        );

        Navigator.pushReplacement(context, MaterialPageRoute(

            builder:(context)=> Activation()

        )
        );
      } else if(req=="encours"){
        Fluttertoast.showToast(
            msg: "Votre activation est valide",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0
        );

        Navigator.pushReplacement(context, MaterialPageRoute(
            builder:(context)=> Profile_UI()
        )
        );

        String  ip = data["ip"].toString();
        String  delais = data["delais"].toString();
        String  date = data["date"].toString();
        print('ip is '+ip.toString());

      }else if(req=="Attente"){
          //votre demande est en attente
        _showDialogLoadVerification(context);
      }

    } else {
      // If that call was not successful, throw an error.
      Fluttertoast.showToast(
          msg: "verifier votre connexion",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0
      );
      throw Exception('Failed to load post verifier votre connexion');
    }


  }
  Future<void> initPlatformState() async {
    String platformVersion;
    try {
      platformVersion = await GetMac.macAddress;
    } on PlatformException {
      platformVersion = 'Failed to get Device MAC Address.';

    }
    print("MAC-: " + platformVersion);
    Verication(platformVersion.toString());
    //
    if (!mounted) return;
    setState(() {
      _platformID = platformVersion;
    });
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initPlatformState();
   // Verication();

  }


  Future _showDialogLoadVerification(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,

                    children: <Widget>[

                      SizedBox(width: 5,),
                      Text('Votre demande est en attente veuillez patienter ou contacter le service client',style: TextStyle(color: Colors.blue),)
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body:Column(
        mainAxisAlignment: MainAxisAlignment.center,
       crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Center(
            child: Container(
              child:   Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SpinKitCircle(
                          color: Colors.grey[400],
                          size: 30.0,
                        ),

                  SizedBox(height: 8,),
                  Text("Verification d'activation",style: TextStyle(color: Colors.grey),)
                ],
              ),


            ),
          ),
        ],
      ),
    );
  }
}
