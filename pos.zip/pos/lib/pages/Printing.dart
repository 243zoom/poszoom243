import 'dart:typed_data';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/widgets.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/pages/Commande_client_page.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:intl/intl.dart';

int id_client;
String title;
String profile_name="";
String photo="";
String st_paiement="";

class PrintingPage extends StatefulWidget {

   PrintingPage(String title1,int id,String paiement){
     id_client=id;
      title=title1;
      st_paiement=paiement;
   }


  @override
  _PrintingPageState createState() => _PrintingPageState();
}

Future<String> Name_produitById(String id_parse) async {

  String name = await DBProvider_new.db.getViewProduitNameByID(id_parse);
  return name;
}


class _PrintingPageState extends State<PrintingPage> {

  int total_cdf=0;
  String paiement="";



  void getProfile() async{
    String  profile = await DBProvider_new.db.getNom_Profile();
    setState(() => profile_name = profile);

  }

   void TotalCommandeCDF() async{
    int  tt = await DBProvider_new.db.getTotalCommandeCDF();
    setState(() => total_cdf = tt);

  }

//_image= base64Decode(item.image);
//profile


  List<CommandeModel> items = new List();

  List<ProfileModel> profile_items = new List();

  @override
  void initState() {
    super.initState();

    TotalCommandeCDF();
    
    print('id client is '+id_client.toString());
    getPhoto();

    DBProvider_new.db.getAllNotes(id_client.toString()).then((notes) {
      setState(() {
        notes.forEach((note) {
          items.add(CommandeModel.fromMap(note));
        });

      });
    });

      

    DBProvider_new.db.getInfos().then((notes) {
      setState(() {
        notes.forEach((note) {
          profile_items.add(ProfileModel.fromMap(note));
        });

      });
    });

   
   


   

  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text(title)),
        body: PdfPreview(
          build: (format) => _generatePdf(format,title),
        ),
      ),
    );
  }
   
/*final image = pw.MemoryImage(
  File("assets/images/no_paye.jpg").readAsBytesSync(),
);*/

  int Total(String m, String nbre) {
    int a = int.parse(m);
    int b = int.parse(nbre);
    int c = a * b;

    return c;
  }
  void getPhoto() async{
    String  photo1 = await DBProvider_new.db.getPhoto();
    // setState(() =>  img=Image.memory(base64Decode(photo)));

    setState(() {
      photo=photo1;
    });

  }

  Future<Uint8List> _generatePdf(PdfPageFormat format, String title) async {
    
    final pdf = pw.Document();
    DateTime now = DateTime.now();
   // var imageProvider = MemoryImage(base64Decode("assets/images/no_paye.jpg"));
   // final PdfImage image = await pdfImageFromImageProvider(pdf: pw.document, image: imageProvider);

    //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
    String formattedDate = DateFormat('d:m:y h:m:s').format(now);
    pdf.addPage(
      pw.Page(
        pageFormat: format,
        build: (context) {
          return pw.Container(
              padding: const pw.EdgeInsets.all(18.0),
              child: pw.Column(

                //  mainAxisAlignment:pw.MainAxisAlignment.center,
                  crossAxisAlignment: pw.CrossAxisAlignment.center,
                  children: [
                    /*pw.Container(
                      width: 70.0,
                      height: 70.0,
                      child: pw.ClipOval(
                        child:photo== null
                            ? new pw.Text('No image.')
                            :  Image.file(
                            File(photo),
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),*/
                    /*pw.Text('Logo POS',
                        style: pw.TextStyle(
                          fontSize: 22,
                        )),*/

                    pw.Text(profile_items[0].business_name, style: pw.TextStyle(fontSize: 22)),
                    pw.Text('Email :'+profile_items[0].email, style: pw.TextStyle(fontSize: 15)),
                    pw.Text('Tel :'+profile_items[0].telephone, style: pw.TextStyle(fontSize: 15)),
                    pw.Text('Adresse :'+profile_items[0].adresse, style: pw.TextStyle(fontSize: 15)),

                    pw.Text('$formattedDate'),
                    // pw.Spacer(),
                    pw.SizedBox(height: 10),
                    pw.Divider(height: 6.0),
                    pw.Row(
                      children: [
                        pw.Text('Qt'),
                        pw.Spacer(),
                        pw.Text('Produit'),
                        pw.Spacer(),
                        pw.Text('Prix'),
                        pw.Spacer(),
                        pw.Text('Total'),
                      ],
                    ),
                    //content of table
                    pw.Row(
                      children: [
                        pw.ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (context, position) {
                              return pw.Column(children: [
                                pw.Divider(height: 5.0),
                                pw.Text(
                                  '${items[position].quantite}',
                                ),
                              ]);
                            }),
                        pw.Spacer(),
                        pw.ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (context, position) {
                              return pw.Column(children: [
                                pw.Divider(height: 5.0),
                                pw.Text(
                                  '${items[position].view_produit}',
                                ),
                              ]);
                            }),
                        pw.Spacer(),
                        pw.ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (context, position) {
                              return pw.Column(children: [
                                pw.Divider(height: 5.0),
                                pw.Text(
                                  '${items[position].montant}',
                                ),
                              ]);
                            }),
                        pw.Spacer(),
                        pw.ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (context, position) {
                              return pw.Column(children: [
                                pw.Divider(height: 5.0),
                                pw.Text(
                                  '${items[position].total}'
                                  //'${Total(items[position].montant, items[position].quantite)}',
                                ),
                              ]);
                            }),
                      ],
                    ),
                    pw.Divider(),
                    pw.Row(
                    children: [pw.Text('TOTAL CDF '), pw.Spacer(), pw.Text('$total_cdf')]),
                   // pw.Image(imageProvider),
                   pw.SizedBox(height: 10.0),
                    pw.Text("$st_paiement",style:pw.TextStyle(fontSize: 22)),
                  ]));
        },
      ),
    );

    return pdf.save();
  }
}
