import 'package:flutter/material.dart';
import 'package:smartpos/pages/DemandeAct_Page.dart';


class ExpiredPage extends StatefulWidget {
  @override
  _ExpiredPageState createState() => _ExpiredPageState();
}

class _ExpiredPageState extends State<ExpiredPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(

        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Center(
            child: Container(
              child: Icon(Icons.timer,size: 50,color: Colors.grey,),
            ),
          ),

          SizedBox(height: 10,),

          Center(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                child:Text("Version d'essaie expirée veuillez passer à l'activation ",style: TextStyle(color: Colors.blue),),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(10.0),
            child: FlatButton(onPressed: (){

              Navigator.pushReplacement(context, MaterialPageRoute(

                  builder:(context)=> Activation()

              )
              );

            },
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                    side: BorderSide(color: Colors.blueAccent)
                ),
                color: Colors.blueAccent,
                child: Text("Continuer",style: TextStyle(color: Colors.white),) ),
          ),

        ],
      ),
    );
  }
}
