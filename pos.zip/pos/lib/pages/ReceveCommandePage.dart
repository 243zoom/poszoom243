import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart'; 
 
import 'package:smartpos/class_dart/ReceveCommandeModel.dart'; 
 
import 'package:intl/intl.dart';
import 'package:smartpos/pages/FacturePOS.dart';
import 'package:smartpos/pages/FactutrReceveCommande.dart';
import 'package:smartpos/pages/Liste_commande_page.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
 
import 'dart:convert';
import 'package:http/http.dart' as http;

String client="";
String resto="";
class ReceveCommandePage extends StatefulWidget {
      ReceveCommandePage(String c,String rest){
        client=c;
        resto=rest;
      }
  @override
  _ReceveCommandePageState createState() => _ReceveCommandePageState();
}

class _ReceveCommandePageState extends State<ReceveCommandePage> {

   TextEditingController sarch_ctrl=TextEditingController();
   ScrollController _scrollController =ScrollController();
  List<ReceveCommandeModel> list = List<ReceveCommandeModel>();
  List<ReceveCommandeModel> filteredList = List<ReceveCommandeModel>();
  bool doItJustOnce = false;
  
  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.produit.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }
  
  @override
  Widget build(BuildContext context) {
     var now = DateTime.now();
    String d= DateFormat().format(now);
    return Scaffold(
      body: Container(
            decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
          children: [
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Commandes reçues',style: TextStyle(color: Colors.white,fontSize: 18),),
                  ),


                ],
              ),
            ),
 

            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

            Container(
               
               color: Colors.white.withOpacity(0.5),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Text('Client : '+client),
                    Spacer(),                    
                    Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: FlatButton(onPressed: (){
                          //
                          _showChoicePaiement(context);
                        },
                          color: Colors.blue[700],
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                              side: BorderSide(color: Colors.blue[700])
                          ),

                          child: Text('Action',style: TextStyle(color: Colors.white),),

                        ),
                      ),
                  ],
                ),
              ),
            ),

            Container(
                height: 60,
               color: Colors.white.withOpacity(0.5),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: TextField(
                      controller: sarch_ctrl,
                      onChanged: (value) {
                        _filterList(value);
                      },
                      decoration: InputDecoration(
                          border: InputBorder.none,

                          prefixIcon: Icon(Icons.search),
                          hintText: "Recherche",
                          hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                    ),
                  ),
                ),
                //color: Colors.black12.withOpacity(0.5),
              ),
            

            Expanded(
                child: Container(
                  color: Colors.white.withOpacity(0.5), 
                  child: FutureBuilder<List<ReceveCommandeModel>>( 
                     future: fetchCommande(),
                      builder: (BuildContext context, AsyncSnapshot<List<ReceveCommandeModel>> snapshot) {
                       
                        if (snapshot.hasData) {

                          Set_statut(String s){

                          var set_it="";
                          if(s=="0"){
                            return set_it="Attente";
                          }
                          else if(s=="1"){
                            return set_it="Facturé";
                          }else if(s=="2"){
                            return set_it="Payé";
                          }
                          return set_it;
                        }


                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          } 
                          return ListView.builder(
                             /* gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 200,
                                  childAspectRatio: 4 / 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10),*/
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length, 
                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Container(
                                                color: Colors.white,
                                                width: 150,
                                                height: 50,
                                                child: Padding(
                                                  padding: const EdgeInsets.only(left:8.0,top: 1.0),
                                                  child: Row(
                                                    children: [
                                                      Text(filteredList[index].produit), 
                                                      Spacer(),
                                                    
                                                   /*  SizedBox(width: 5.0,),
                                                      Container(
                                                         
                                                        child:Text('sds'+Set_statut(filteredList[index].ID.toString()).toString(),style: TextStyle(color: Colors.black),),
                                                      ),
                                                      SizedBox(width: 5.0,),*/
                                                    ],
                                                  ),
                                                ),
                                                

                                          ),
                                        )
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                ) 
            ),
          ],
        ),
      ),
    );
  }

Future _showChoicePaiement(context) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          onTap: (){
                              Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => FactureCommande(),
                              ),
                            );
                           /* Navigator.of(context).pop();
                            _showDialogLoad(context);*/
                            /*Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => FacturePOS(),
                                  ),
                                );*/
                          },
                          child: Text('Facturer'),
                        ),
                        /*Divider(),
                        InkWell(
                          onTap: (){
                            Navigator.of(context).pop();
                            _showDialogLoad(context);
                          },
                          child: Text('Paiement cash'),
                        ),
                       /* Divider(),
                       InkWell(
                         onTap: (){
                            
                          const url = 'https://api-testbed.maxicashapp.com/payentry?data={PayType:"MaxiCash",Amount:"1000",Currency:"maxiDollar",Telephone:"00243977081930",MerchantID:"bb61d2ccbfff48429f9f4097621e7b63",MerchantPassword:"8ff43c7c7da54d56a4627eed9ec9e00a",Language:"fr",Reference:"ROBI-POS",Accepturl:"zoom243.com",Cancelurl:"zoom243.com",Declineurl:"zoom243.com",NotifyURL:"zoom243.com"}';
                            launchURL(url);
                         },
                         child: Text('Maxicash paiement'),                         
                       ),*/
                       Divider(),
                        InkWell(
                         onTap: (){

                         },
                         child: Text('PayPal'),                         
                       ),*/
                        Divider(),
                        InkWell(
                         onTap: (){
                               //Navigator.of(context).pop();
                             //  _showDialogAddClient(context);
                            /*Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => ShareDemo(),
                                  ),
                                );*/
                         _showListPaiement(context);
                         },
                         child: Text('Paiement'),                         
                       ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

    Future _showListPaiement(context) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          onTap: (){
                            Navigator.of(context).pop();
                          //  _showDialogLoad(context);
                          },
                          child: Text('Paiement cash'),
                        ),
                        Divider(),
                       
                        InkWell(
                         onTap: (){

                         },
                         child: Text('PayPal'),                         
                       ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

   Future<List<ReceveCommandeModel>> fetchCommande() async {
      var url = 'http://apirobipos.zoom243.com/select_commande.php';
 

    var data = {'client': client,'resto':resto};

    var response = await http.post(url,body: json.encode(data)); 
 

    if (response.statusCode == 200) {

      final items = json.decode(response.body).cast<Map<String, dynamic>>();

      List<ReceveCommandeModel> studentList = items.map<ReceveCommandeModel>((json) {
        return ReceveCommandeModel.fromJson(json);
      }).toList(); 
      return studentList;

      }
     else {
      throw Exception('Failed to load data from Server.');
    }
  }
}