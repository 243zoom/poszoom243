import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:smartpos/class_dart/ClientFromServer.dart';
import 'package:smartpos/class_dart/ClientModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart'; 
import 'package:smartpos/class_dart/message.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/ReceveCommandePage.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';  
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class CommandePage extends StatefulWidget {
  @override
  _CommandePageState createState() => _CommandePageState();
}

class _CommandePageState extends State<CommandePage> {

   TextEditingController sarch_ctrl=TextEditingController();
   ScrollController _scrollController =ScrollController();
  List<ClientFromServer> list = List<ClientFromServer>();
  List<ClientFromServer> filteredList = List<ClientFromServer>();
  List<ProfileModel> profile_items = new List();
  bool doItJustOnce = false;
  
  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.clientName.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }
    @override
  void initState() { 
    // TODO: implement initState
   DBProvider_new.db.getInfos().then((notes) {
      setState(() {
        notes.forEach((note) {
          profile_items.add(ProfileModel.fromMap(note));
        });

      });
    });  
     super.initState(); 
  }
  @override
  Widget build(BuildContext context) {
     var now = DateTime.now();
    String d= DateFormat().format(now);
    return Scaffold(
      body: Container(
            decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
          children: [
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Client',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),

            

            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

            Container(
                height: 60,
               color: Colors.white.withOpacity(0.5),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: TextField(
                      controller: sarch_ctrl,
                      onChanged: (value) {
                        _filterList(value);
                      },
                      decoration: InputDecoration(
                          border: InputBorder.none,

                          prefixIcon: Icon(Icons.search),
                          hintText: "Recherche",
                          hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                    ),
                  ),
                ),
                //color: Colors.black12.withOpacity(0.5),
              ),
            

            Expanded(
                child: Container(
                  color: Colors.white.withOpacity(0.5), 
                  child: FutureBuilder<List<ClientFromServer>>( 
                     future: fetchStudents(),
                      builder: (BuildContext context, AsyncSnapshot<List<ClientFromServer>> snapshot) {
                       
                        if (snapshot.hasData) {
                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          } 
                          return ListView.builder(
                             /* gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 200,
                                  childAspectRatio: 4 / 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10),*/
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length, 
                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                        child: GestureDetector(
                                          onTap: (){
                                            Navigator.of(context).push(
                                            MaterialPageRoute(
                                              builder: (context) => ReceveCommandePage(filteredList[index].clientName.toString(),profile_items[0].email),
                                            ),
                                          );
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Container(
                                                  color: Colors.white,
                                                  width: 150,
                                                  height: 50,
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(left:8.0,top: 1.0),
                                                    child: Row(
                                                      children: [
                                                        Text(filteredList[index].clientName.toString()),

                                                        
                                                        Spacer(),
                                                         Text(filteredList[index].clientDate.toString()),
                                                        SizedBox(width: 5.0,),

                                                       //  Text('${filteredList[index].devise} '+filteredList[index].prix.toString()+' '),
                                                        /*GestureDetector(
                                                          onTap: (){
                                                            //_showDialogEdit(context,filteredList[index].subcategorie,filteredList[index].id);
                                                            },
                                                          child:Container(
                                                           decoration: BoxDecoration(
                                                            //color: Colors.white,
                                                            color:Colors.blue[700],
                                                            borderRadius: BorderRadius.all(
                                                              Radius.circular(10) ,

                                                            ),
                                                          ),
                                                          width: 70,
                                                          height: 29,
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Icon(Icons.edit,size: 15,color: Colors.white,),
                                                          ),
                                                        ),
                                                        ),*/
                                                       /* SizedBox(width: 5.0,),
                                                        GestureDetector(
                                                          onTap: (){
                                                               //  _showDialogDelete(context,filteredList[index].id);
                                                             },
                                                          child:Container(
                                                          width: 85,
                                                          height: 29,
                                                          decoration: BoxDecoration(
                                                            //color: Colors.white,
                                                            color:Colors.red[400],

                                                            borderRadius: BorderRadius.all(
                                                              Radius.circular(10) ,
                                                            ),

                                                          ),
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Icon(Icons.delete,size: 15,color: Colors.white,),
                                                          ),
                                                        ),
                                                        ),
                                                        SizedBox(width: 5.0,),*/
                                                      ],
                                                    ),
                                                  ),
                                                  

                                            ),
                                          ),
                                        )
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                ) 
            ),
          ],
        ),
      ),
    );
  }
   Future<List<ClientFromServer>> fetchStudents() async {
 
    var url = 'http://apirobipos.zoom243.com/select_client.php'; 

    var data = {'resto': profile_items[0].email};

    var response = await http.post(url,body: json.encode(data)); 


    if (response.statusCode == 200) {

      final items = json.decode(response.body).cast<Map<String, dynamic>>();

      List<ClientFromServer> studentList = items.map<ClientFromServer>((json) {
        return ClientFromServer.fromJson(json);
      }).toList();

      return studentList;
      }
     else {
      throw Exception('Failed to load data from Server.');
    }
  }
}