import 'dart:async';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/LoginModel.dart';
import 'package:smartpos/class_dart/PanierModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/pages/FacturePOS.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/add_Client.dart';
import 'package:smartpos/pages/choosePanier.dart';
import 'package:smartpos/pages/parametre_pos.dart'; 
import 'package:smartpos/utils/Database.dart'; 
import 'package:url_launcher/url_launcher.dart'; 
import 'package:http/http.dart' as http; 
import 'dart:convert';

class AchatPOS extends StatefulWidget {
  @override
  _AchatPOSState createState() => _AchatPOSState();
}


class _AchatPOSState extends State<AchatPOS> {
  @override

  ScrollController _scrollController =ScrollController();
  List<PanierModel> list = List<PanierModel>();
  List<PanierModel> filteredList = List<PanierModel>();
  bool doItJustOnce = false;
   String barcode = "";
  String qr_code="";

  TextEditingController _client_ctl=TextEditingController();
  TextEditingController produit_ctrl=TextEditingController();
  TextEditingController prix_ctrl=TextEditingController();

   List _device = ["Devise", "CDF", "USD"];
 
  String base64Image;
  List<DropdownMenuItem<String>> _dropDownMenuItems;
  String _currentDevice;
  String currentUser="";

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.produit.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }
  
  List<ProfileModel> profile_items = new List();
   

    

  @override
  void initState() {
    // _enabled = !_enabled;
    _dropDownMenuItems = getDropDownMenuItems();
    _currentDevice = _dropDownMenuItems[0].value;
    // TODO: implement initState
   DBProvider_new.db.getInfos().then((notes) {
      setState(() {
        notes.forEach((note) {
          profile_items.add(ProfileModel.fromMap(note));
        });

      });
    }); 

     DBProvider_new.db.getCurrentUser(0).then((notes) {
      setState(() {
        notes.forEach((note) {
         // login_items.add(LoginModel.fromMap(note));
          print('sd '+note['username']);
          currentUser=note['username'];
        });

      });
    }); 
     
     super.initState();

 

  }
 
void changedDropDownItem(String selectedCity) {
    setState(() {
      _currentDevice = selectedCity;
    });
  }

 List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = new List();
    for (String city in _device) {
      items.add(new DropdownMenuItem(value: city, child: new Text(city)));
    }
    return items;
  }

  

  
    
  Widget build(BuildContext context) {

     
 

    var now = DateTime.now();
    String d= DateFormat().format(now);

    Future _showDialogAddClient(context) async {

        return await showDialog<void>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SingleChildScrollView(
                            child: Column(

                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  //height: 30,
                                  child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: produit_ctrl,
                                    decoration: new InputDecoration(labelText: "Produit",
                                        border: OutlineInputBorder(
                                          borderSide: BorderSide(
                                            // color: Colors.red,
                                              width: 5.0),
                                        )

                                    ),
                                  ),
                                ),
                                ),
                                Container(
                                  //height: 30,
                                  child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: prix_ctrl,
                                    decoration: new InputDecoration(labelText: "Prix",
                                        border: OutlineInputBorder(
                                          borderSide: BorderSide(
                                            // color: Colors.red,
                                              width: 5.0),
                                        )

                                    ),
                                  ),
                                ),
                                ),

                                Container(
                                  //height: 30,
                                  child:  Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: DropdownButton(
                                    value: _currentDevice,
                                    items: _dropDownMenuItems,
                                    // style: GoogleFonts.lato(color: Colors.grey[800]),
                                    onChanged: changedDropDownItem,

                                    elevation: 2,
                                    style: TextStyle(color: Colors.black54),
                                    underline: Container(
                                      height: 2,
                                    ),
                                  ),
                                ),
                                  ),

                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: FlatButton(onPressed: (){

                                        setState(() {
                                          if(produit_ctrl.text.toString().isEmpty){
                                            MessageToast m=MessageToast('Veuillez saisir le client !');
                                            m.ShowMessage();
                                          }else if(prix_ctrl.text.isEmpty){
                                                     MessageToast m=MessageToast('Veuillez saisir le prix !');
                                            m.ShowMessage();
                                               
                                          }else{
                                             DateTime now = DateTime.now();
                                                //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
                                                String formattedDate = DateFormat('d:m:y h:m:s').format(now);
                                                PanierModel panierModel=PanierModel(client:_client_ctl.text,prix:prix_ctrl.text,devise: _currentDevice,date: formattedDate,produit:produit_ctrl.text );
                                                DBProvider_new.db.newPanier(panierModel); 
                                                Navigator.of(context).pop(); 
                                                startTimerAdd();
                                                _showDialogLoad(context);

                                          }

                                        });


                                      },
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(18.0),
                                              side: BorderSide(color: Colors.blue[700])
                                          ),
                                          color: Colors.blue[700],
                                          child: Text("Ajouter produit",style: TextStyle(color: Colors.white),) ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          //your code dropdown button here
                        ]),
                  );
                },
              ),

            );

          },
        );

      }

      

    return Scaffold(
      body: Container(
         decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),

        child: Column(
         
          children: [
          
          Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Panier',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),


            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

            /*Container(
              child: Text('sdsd ${profile_items[0].email}'),
            ),*/
           

            Container(
              //height: 20,
               decoration: BoxDecoration(
                        //color: Colors.white,
                        color: Colors.white.withOpacity(0.5),
                        borderRadius: BorderRadius.all(
                          Radius.circular(2) ,

                        ),
                      ),  
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                 
                 Padding(  padding: const EdgeInsets.all(8.0),
                                 child: GestureDetector(
                                   onTap: 
                                    barcodeScanning
                                   ,
                                   child:  Row(
                                      
                                     children: [
                                       Image(image: AssetImage('assets/images/bar_code.png'),width: 40,),
                                       //Text('$barcode'),
                                     ],
                                   ),
                                 ),
                               ),
                         

                          Padding(
                                 padding: const EdgeInsets.all(8.0),
                                 child: GestureDetector(
                                   onTap: 
                                     QrcodeScanning
                                   ,
                                   child:  Row(
                                      
                                     children: [
                                       Icon(Icons.qr_code_scanner,size: 40,),
                                      // Text('$qr_code'),
                                     ],
                                   ),
                                 ),
                               ),

                  GestureDetector(
                    onTap: (){
                       Navigator.pushReplacement(
                       context, MaterialPageRoute(builder: (context) => ChoosePanier(client_ctr.text)));

                    },
                    child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(Icons.search_rounded,color: Colors.blue[700],),
                  ),
                  ),
                  
                  GestureDetector(
                    onTap: (){
                      _showDialogAddClient(context);
 
                    },
                    child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(Icons.add_box,size: 35,color: Colors.blue[700],),
                  ),
                  ),
                    Padding(
                                 padding: const EdgeInsets.all(8.0),
                                 child: GestureDetector(
                                    onTap: (){
                                        DBProvider_new.db.deleteAllPanier();
                                        Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));
                                    },
                                   child:  Row(
                                      
                                     children: [
                                       Icon(Icons.restore_rounded,size: 40,color: Colors.red[700],),
                                      // Text('$qr_code'),
                                     ],
                                   ),
                                 ),
                               ),
              ],),
            ),


            
            Expanded(
                child: Container(
                  color: Colors.white.withOpacity(0.5), 
                  child: FutureBuilder<List<PanierModel>>( 
                     future: DBProvider_new.db.getAllProduitFromPanier(),
                      builder: (BuildContext context, AsyncSnapshot<List<PanierModel>> snapshot) {
                       
                        if (snapshot.hasData) {
                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          } 
                          return ListView.builder(
                             /* gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 200,
                                  childAspectRatio: 4 / 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10),*/
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length, 
                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Container(
                                                color: Colors.white,
                                                width: 150,
                                                height: 50,
                                                child: Padding(
                                                  padding: const EdgeInsets.only(left:8.0,top: 1.0),
                                                  child: Row(
                                                    children: [
                                                      Text(filteredList[index].produit.toString()),
                                                      
                                                      Spacer(),
                                                       Text('${filteredList[index].devise} '+filteredList[index].prix.toString()+' '),
                                                      /*GestureDetector(
                                                        onTap: (){
                                                          //_showDialogEdit(context,filteredList[index].subcategorie,filteredList[index].id);
                                                          },
                                                        child:Container(
                                                         decoration: BoxDecoration(
                                                          //color: Colors.white,
                                                          color:Colors.blue[700],
                                                          borderRadius: BorderRadius.all(
                                                            Radius.circular(10) ,

                                                          ),
                                                        ),
                                                        width: 70,
                                                        height: 29,
                                                        child: Padding(
                                                          padding: const EdgeInsets.all(8.0),
                                                          child: Icon(Icons.edit,size: 15,color: Colors.white,),
                                                        ),
                                                      ),
                                                      ),*/
                                                      SizedBox(width: 5.0,),
                                                      GestureDetector(
                                                        onTap: (){
                                                               _showDialogDelete(context,filteredList[index].id);
                                                           },
                                                        child:Container(
                                                        width: 85,
                                                        height: 29,
                                                        decoration: BoxDecoration(
                                                          //color: Colors.white,
                                                          color:Colors.red[400],

                                                          borderRadius: BorderRadius.all(
                                                            Radius.circular(10) ,
                                                          ),

                                                        ),
                                                        child: Padding(
                                                          padding: const EdgeInsets.all(8.0),
                                                          child: Icon(Icons.delete,size: 15,color: Colors.white,),
                                                        ),
                                                      ),
                                                      ),
                                                      SizedBox(width: 5.0,),
                                                    ],
                                                  ),
                                                ),
                                                

                                          ),
                                        )
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                ) 
            ),

            Row(
               mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
               FlatButton(onPressed: (){ 
                 _showChoicePaiement(context);
              },

              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
                side: BorderSide(color: Colors.blue[700])
                ),
                color: Colors.blue[700],
                child: Text("Valider",style: TextStyle(color: Colors.white),) ),
            ],)


        ],),
      ),
    );
  }
  launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url, forceWebView: true);
    } else {
      throw 'Could not launch $url';
    }
 }

  Future _showChoicePaiement(context) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          onTap: (){
                           /* Navigator.of(context).pop();
                            _showDialogLoad(context);*/
                            Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => FacturePOS(),
                                  ),
                                );
                          },
                          child: Text('Facturer'),
                        ),
                        /*Divider(),
                        InkWell(
                          onTap: (){
                            Navigator.of(context).pop();
                            _showDialogLoad(context);
                          },
                          child: Text('Paiement cash'),
                        ),
                       /* Divider(),
                       InkWell(
                         onTap: (){
                            
                          const url = 'https://api-testbed.maxicashapp.com/payentry?data={PayType:"MaxiCash",Amount:"1000",Currency:"maxiDollar",Telephone:"00243977081930",MerchantID:"bb61d2ccbfff48429f9f4097621e7b63",MerchantPassword:"8ff43c7c7da54d56a4627eed9ec9e00a",Language:"fr",Reference:"ROBI-POS",Accepturl:"zoom243.com",Cancelurl:"zoom243.com",Declineurl:"zoom243.com",NotifyURL:"zoom243.com"}';
                            launchURL(url);
                         },
                         child: Text('Maxicash paiement'),                         
                       ),*/
                       Divider(),
                        InkWell(
                         onTap: (){

                         },
                         child: Text('PayPal'),                         
                       ),*/
                        Divider(),
                        InkWell(
                         onTap: (){
                               Navigator.of(context).pop();
                               _showDialogAddClient(context);
                            /*Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => ShareDemo(),
                                  ),
                                );*/
                         },
                         child: Text('Ajouter la commande'),                         
                       ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

  Future _showDialogDelete(context,int id) async {

        return await showDialog<void>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[

                          Text('Voulez-vous confirmer la suppression ?',style: TextStyle(color: Colors.black),),
                          SizedBox(height: 11,),
                          Row(
                            children: [
                              InkWell(
                                onTap: (){


                                  Navigator.of(context).pop();

                                  DBProvider_new.db.deleteClient(id);

                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));


                                  setState(() {
                                    DBProvider_new.db.deletePanier(id);
                                  });
                                },
                                child: Text('Oui',style: TextStyle(color: Colors.blue),),
                              ),
                              Spacer(),
                              InkWell(
                                onTap: (){
                                  Navigator.of(context).pop();
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) => super.widget));
                                },
                                child: Text('Non',style: TextStyle(color: Colors.red),),
                              )
                            ],
                          )
                          //your code dropdown button here
                        ]),
                  );
                },
              ),

            );

          },
        );

      }

Future _showDialogAddClient(context) async {

        return await showDialog<void>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SingleChildScrollView(
                            child: Column(

                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: client_ctr,
                                    decoration: new InputDecoration(labelText: "Client",
                                        border: OutlineInputBorder(
                                          borderSide: BorderSide(
                                            // color: Colors.red,
                                              width: 5.0),
                                        )

                                    ),
                                  ),
                                ),

                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: FlatButton(onPressed: (){

                                        setState(() {
                                          if(client_ctr.text.toString().isEmpty){
                                            MessageToast m=MessageToast('Veuillez saisir le client !');
                                            m.ShowMessage();
                                          }else{

                                              DateTime now = DateTime.now();
                                              //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
                                              String date_add = DateFormat('d/m/y h:m:s').format(now);
                                            //recuperer tout les produits dans le panier 
                                            //inserer dans une table avec le nom du client 
                                            //
                                            sendClient(client_ctr.text,date_add,currentUser,profile_items[0].email);

                                            DBProvider_new.db.getCmdPanier().then((notes) {
                                              setState(() {
                                                notes.forEach((note) {
                                                  print(note['produit'].toString());
                                                  senddata(note['produit'], note['prix'], note['devise'], profile_items[0].email, date_add, currentUser,client_ctr.text);
                                                //  profile_items.add(ProfileModel.fromMap(note));
                                               // print('user '+currentUser);  
                                                });


                                              });
                                            });

                                             Navigator.of(context).pop();
                                           ///  client_ctr.clear();

                                          }

                                        });


                                      },
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(18.0),
                                              side: BorderSide(color: Colors.blue[700])
                                          ),
                                          color: Colors.blue[700],
                                          child: Text("Envoyer",style: TextStyle(color: Colors.white),) ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          //your code dropdown button here
                        ]),
                  );
                },
              ), 
            ); 
          },
        ); 
      }
      
   Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.grey,
                          size: 25.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }


  //String name="";
 startTimer() async {
    var dur = Duration(seconds: 1);
    return Timer(dur, route);
  }

  route() {
    Navigator.of(context).pop();
    // Navigator.of(context).pop();
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => super.widget));
    }

   startTimerAdd() async {
    var dur = Duration(seconds: 1);
    return Timer(dur, routeAdd);
  }

  routeAdd() {
    Navigator.of(context).pop();
    // Navigator.of(context).pop();
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => super.widget));
  }



  void getProduit(String code) async{
    String  produit = await DBProvider_new.db.getProduitByNameCodeCodeBar(code);
    String  prix = await DBProvider_new.db.getProduitPrixCodeCodeBar(code);
    String  devise = await DBProvider_new.db.getProduitDeviseCodeCodeBar(code);
    // setState(() =>  img=Image.memory(base64Decode(photo)));
    DateTime now = DateTime.now();
    //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
    String formattedDate = DateFormat('d:m:y h:m:s').format(now);

    setState(() {
    //  name=produit;

      if(produit.isNotEmpty){
        // Fluttertoast.showToast(
        //     msg:"no vide  $produit",
        //     toastLength: Toast.LENGTH_SHORT,
        //     gravity: ToastGravity.CENTER,
        //     timeInSecForIosWeb: 2,
        //     backgroundColor: Colors.blue,
        //     textColor: Colors.white,
        //     fontSize: 16.0
        // );

        PanierModel panierModel=PanierModel(client:_client_ctl.text,prix: prix,devise: devise,date: formattedDate,produit:produit );
        DBProvider_new.db.newPanier(panierModel);

      _showDialogLoad(context);
       startTimer(); 

      }else{
        Fluttertoast.showToast(
            msg:"Produit non trouvé",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 14.0
        );
      }
    });

  }
   Future barcodeScanning() async {
    try {
     ScanResult qrScanResult = await BarcodeScanner.scan();
      String qrResult = qrScanResult.rawContent;

      setState(() { 
      //barcode = qrResult; 
      getProduit(qrResult);
 
      });
    } on PlatformException catch (ex) {
      if (ex.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          barcode = "Camera was denied";
        });
      } else {
        setState(() {
          barcode = "Unknown Error $ex";
        });
      }
    } on FormatException {
      setState(() {
        barcode = "You pressed the back button before scanning anything";
      });
    } catch (ex) {
      setState(() {
        barcode = "Unknown Error $ex";
      });
    }
  }

 //QrcodeScanning
void getProduitQr(String code) async{
    String  produit = await DBProvider_new.db.getProduitByNameCodeQrCode(code);
     String  prix = await DBProvider_new.db.getProduitPrixCodeQrCode(code);
       String  devise = await DBProvider_new.db.getProduitDeviseCodeQrCode(code);
    // setState(() =>  img=Image.memory(base64Decode(photo)));
    DateTime now = DateTime.now();
    //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
    String formattedDate = DateFormat('d:m:y h:m:s').format(now);

    setState(() {
    //  name=produit; 
      if(produit.isNotEmpty){
        // Fluttertoast.showToast(
        //     msg:"no vide  $produit",
        //     toastLength: Toast.LENGTH_SHORT,
        //     gravity: ToastGravity.CENTER,
        //     timeInSecForIosWeb: 2,
        //     backgroundColor: Colors.blue,
        //     textColor: Colors.white,
        //     fontSize: 16.0
        // ); 
        PanierModel panierModel=PanierModel(client:_client_ctl.text,prix:prix ,devise: devise,date: formattedDate,produit:produit );
        DBProvider_new.db.newPanier(panierModel);

      _showDialogLoad(context);
       startTimer(); 

      }else{
        Fluttertoast.showToast(
            msg:"Produit non trouvé",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 14.0
        );
      }
    });

  }

Future QrcodeScanning() async {
    try {
     ScanResult qrScanResult = await BarcodeScanner.scan();
      String qrResult = qrScanResult.rawContent; 
      setState(() { 
      //barcode = qrResult; 
      getProduitQr(qrResult);
 
      });
    } on PlatformException catch (ex) {
      if (ex.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          qr_code = "Camera was denied";
        });
      } else {
        setState(() {
          qr_code = "Unknown Error $ex";
        });
      }
    } on FormatException {
      setState(() {
        qr_code = "You pressed the back button before scanning anything";
      });
    } catch (ex) {
      setState(() {
        qr_code = "Unknown Error $ex";
      });
    } 
  }

  // send data with internet 
  Future senddata(String produit,String prix,String devise,String resto,String date,String server,String client) async {
       var url = 'http://apirobipos.zoom243.com/commande.php';
    var data = {'resto': resto,"produit":produit,"prix":prix,"devise":devise,"date_add":date,"server":server,"client":client};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));
  }
  // client
    Future sendClient(String client,String date,String server,String resto) async {
       var url = 'http://apirobipos.zoom243.com/client.php';
    var data = {'client': client,"date":date,"server":server,"resto":resto};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));
  }

}