import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/utils/Database.dart';


class InfosPage extends StatefulWidget {
  @override
  _InfosPageState createState() => _InfosPageState();
}

class _InfosPageState extends State<InfosPage> {

  TextEditingController entreprise_ctrl=TextEditingController();
  TextEditingController email_ctrl=TextEditingController();
  TextEditingController telephone_ctrl=TextEditingController();
  TextEditingController adresse_ctrl=TextEditingController();


  List<ProfileModel> profile_items = new List();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    DBProvider_new.db.getInfos().then((notes) {
      setState(() {
        notes.forEach((note) {
          profile_items.add(ProfileModel.fromMap(note));
        });

      });
    });
  }

  @override
  Widget build(BuildContext context) {
 

     
 

    //edit place adresse

    Future _showDialogEditAdresse(context,String entreprise,String email,String addresse,String contact, int id) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: entreprise_ctrl,
                                  decoration: new InputDecoration(labelText:'Nom entreprise',
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),
                                
                                 Padding(
                               padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                 controller: email_ctrl,
                                  decoration: new InputDecoration(labelText:'Email',
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),
                               
                                Padding(
                               padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                 controller: telephone_ctrl,
                                  decoration: new InputDecoration(labelText:'Telephone',
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),
                               
                              Padding(
                               padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                 controller: adresse_ctrl,
                                  decoration: new InputDecoration(labelText:'adresse',
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),

                              Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: FlatButton(onPressed: (){

                                        DBProvider_new.db.EditInfos(id,entreprise_ctrl.text, email_ctrl.text, telephone_ctrl.text, adresse_ctrl.text);
                                
                                    entreprise_ctrl.clear();
                                    email_ctrl.clear();
                                    telephone_ctrl.clear();
                                    adresse_ctrl.clear();
                               
                                Navigator.of(context).pop();
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));
                                    },
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(18.0),
                                            side: BorderSide(color: Colors.blue[700])
                                        ),
                                        color: Colors.blue[700],
                                        child: Text("Modifier",style: TextStyle(color: Colors.white),) ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

  var now = DateTime.now();
    String d= DateFormat().format(now);


    return Scaffold(

      body: Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,
            )
        ),
        child: Column(
          children: [
            
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Infos',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

            Padding(
              
              padding: const EdgeInsets.all(8.0),
              child: Container(
                
                decoration: new BoxDecoration(
                color: Colors.white.withOpacity(0.5), //new Color.fromRGBO(255, 0, 0, 0.0),
                  borderRadius: new BorderRadius.all(
                     Radius.circular(5.0),
                     )
                ),
                  child: Column(
                    children: [
                         Padding(
                    padding: const EdgeInsets.all(8.0),
                    child:  Row(
                      children: [
                        Icon(Icons.person,size: 23,color: Colors.grey[700],),
                        SizedBox(width: 7,),
                        Text('${profile_items[0].business_name}',style: TextStyle(fontSize: 20,color: Colors.grey[700]),),
                        Spacer(),
                      /* InkWell(
                          onTap: (){
                            _showDialogEditEntreprise(context, profile_items[0].business_name, profile_items[0].id);
                          },
                          child: Icon(Icons.edit,color: Colors.blueGrey,size: 20,),
                        )*/
                      ],
                    ),
                   ),

                      Divider(),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child:  Row(
                children: [
                   Icon(Icons.email,size: 23,color: Colors.grey[700],),
                  SizedBox(width: 6,),
                  Text('${profile_items[0].email}',style: TextStyle(fontSize: 20,color: Colors.grey[700]),),
                   Spacer(),
                  /*InkWell(
                    onTap: (){
                      _showDialogEditEmail(context, profile_items[0].email, profile_items[0].id);
                    },
                    child: Icon(Icons.edit,color: Colors.blueGrey,size: 20,),
                  )*/
                ],
              ),
            ),
            Divider(),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child:  Row(
                children: [
                 Icon(Icons.phone,size: 23,color: Colors.grey[700],),
                  SizedBox(width: 6,),
                  Text('${profile_items[0].telephone}',style: TextStyle(fontSize: 20,color: Colors.grey[700]),),
                  Spacer(),
                 /* InkWell(
                    onTap: (){
                _showDialogEditTelephone(context, profile_items[0].telephone, profile_items[0].id);
                    },
                    child: Icon(Icons.edit,color: Colors.blueGrey,size: 20,),
                  )*/
                ],
              ),
            ),
            Divider(),
           Padding(
              padding: const EdgeInsets.all(8.0),
              child:  Row(
                children: [
                Icon(Icons.place,size: 23,color: Colors.grey[700],),
                  SizedBox(width: 6,),
                  Text('${profile_items[0].adresse}',style: TextStyle(fontSize: 20,color: Colors.grey[700]),),
                  Spacer(),
                  /*InkWell(
                    onTap: (){
                    _showDialogEditAdresse(context, profile_items[0].adresse, profile_items[0].id);
                    },
                    child: Icon(Icons.edit,color: Colors.blueGrey,size: 20,),
                  )*/
                ],
              ),
            ),

            InkWell(
                  onTap: (){
                    entreprise_ctrl.text=profile_items[0].business_name;
                    email_ctrl.text=profile_items[0].email;
                    adresse_ctrl.text=profile_items[0].adresse;
                    telephone_ctrl.text=profile_items[0].telephone;

                    _showDialogEditAdresse(context, profile_items[0].business_name,profile_items[0].email, profile_items[0].adresse, profile_items[0].telephone, profile_items[0].id);
                         //_showDialogEditTaux(context,taux_items[0].id,taux_items[0].usd);
                  },
                  child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    
                  decoration: new BoxDecoration(
                  color: Colors.blue[700], //new Color.fromRGBO(255, 0, 0, 0.0),
                  borderRadius: new BorderRadius.all(
                     Radius.circular(5.0),
                     )
                ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       Padding(padding:const EdgeInsets.all(8.0),  
                       child: Text('Modifer',style: TextStyle(color: Colors.white),),)
                      ],
                    ),
                  ),
                ),
                )
                    ],
                  ),
              ),
            ),
           
            
            
           

          ],
        ),
      )
    );
  }
}
