import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/tauxModel.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/Profile_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/utils/Database.dart';

class TauxPage extends StatefulWidget {
  @override
  _TauxPageState createState() => _TauxPageState();
}

class _TauxPageState extends State<TauxPage> {
  @override

 List<TauxModel> taux_items = new List();
 TextEditingController taux_usd=TextEditingController();
 TextEditingController taux_cdf=TextEditingController();

    @override
  void initState() {
     DBProvider_new.db.getTaux().then((notes) {
      setState(() {
        notes.forEach((note) {
          taux_items.add(TauxModel.fromMap(note));
        });

      });
    });
    
   
  }

  Widget build(BuildContext context) {

    
    //show editing 
    Future _showDialogEditTaux(context,int id,String usd) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(

                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        TextField(
                          controller:taux_usd ,
                          decoration: new InputDecoration(labelText: "1 USD "+usd+ " CDF",
                              //icon: Icon(Icons.mail,size: 15,)
                          ),

                        ),
                         
                       

                        SizedBox(height: 10,),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            FlatButton(onPressed: (){
                                DBProvider_new.db.EditTaux(id,taux_usd.text.toString());
                                
                                taux_usd.clear();
                                Navigator.of(context).pop();
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));

                            }, child: Text('Modifier',style: TextStyle(color: Colors.white),),color: Colors.blue,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18.0),
                                  side: BorderSide(color: Colors.blueAccent)
                              ),
                            ),
                          ],
                        )



                        //your code dropdown button here
                      ]),
                );
              },
            ),

            actions: [

            ],

          );

        },
      );

    } 

      var now = DateTime.now();
    String d= DateFormat().format(now);

    return Scaffold(

      body: Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
          children: [

            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 75,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(top:10.0,right: 10.0),
                    child: Text('Taux du jour',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),




                ],
              ),
            ),

           Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),


        Align(alignment: Alignment(0.0,0.0),child:  Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: 120,
               
               decoration: new BoxDecoration(
                  color: Colors.white, //new Color.fromRGBO(255, 0, 0, 0.0),
                  borderRadius: new BorderRadius.all(
                     Radius.circular(5.0),
                     )
                ),
              child: Column(children: [
                SizedBox(height: 5.0,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('1 USD : '+taux_items[0].usd+" CDF",),
                    ),
                  ],
                ),
               
               /* Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('CDF : '+taux_items[0].cdf),
                    ),
                  ],
                ),*/
                Divider(),
                InkWell(
                  onTap: (){
                         _showDialogEditTaux(context,taux_items[0].id,taux_items[0].usd);
                  },
                  child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    
                  decoration: new BoxDecoration(
                  color: Colors.blue[700], //new Color.fromRGBO(255, 0, 0, 0.0),
                  borderRadius: new BorderRadius.all(
                     Radius.circular(5.0),
                     )
                ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       Padding(padding:const EdgeInsets.all(8.0),  
                       child: Text('Modifer',style: TextStyle(color: Colors.white),),)
                      ],
                    ),
                  ),
                ),
                )
              ],),
            ),
          ),)
         

          ],
        ),
      ),
    );
  }
}