import 'dart:async';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/LoginModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/commons/narrow_app_bar.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart'; 
import 'package:fluttertoast/fluttertoast.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

int _value = 0;

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController utilisateur_ctl = TextEditingController();
  TextEditingController password_ctr = TextEditingController();
  TextEditingController password_ctr2 = TextEditingController();

  TextEditingController search = TextEditingController();

  ScrollController _scrollController = ScrollController();

  @override
  Future<List<LoginModel>> LoadLogin() async {
    // List<CategorieModel> project =await DBProvider_new.db.getAllCategorie();
    var data = await DBProvider_new.db.getLogin();
    return data;
  }

  @override
  void initState() {
    super.initState();
    //dispose();
  }

  startTimer() async {
    var dur = Duration(seconds: 2);
    return Timer(dur, route);
  }

  route() {
    Navigator.of(context).pop();
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (BuildContext context) => super.widget));
  }

  List<LoginModel> list = List<LoginModel>();
  List<LoginModel> filteredList = List<LoginModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) =>
              text.username.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }

  Verrifier_email(String email) async {
    int a = await DBProvider_new.db.verifier_email_client(email);
    setState(() {
        return cmd_log= a.toString();
    });
  }

   startTimerVerifierEmail() async {
    var dur = Duration(seconds: 1);
    return Timer(dur, routeEmail);
  }

routeEmail(){

  if(cmd_log=="0"){
     LoginModel lm = LoginModel(
                          username: utilisateur_ctl.text.toString(),
                          password: password_ctr2.text.toString(),
                          level: _value.toString());
                      DBProvider_new.db.newLogin(lm);

                      utilisateur_ctl.clear();
                      password_ctr2.clear();
                      password_ctr.clear();
                      setState(() {
                        LoadLogin();
                        Navigator.of(context).pop();
                        startTimer();
                        _showDialogLoad(context);
                      });

     Navigator.of(context).pop();

   
  }else{
       Fluttertoast.showToast(
          msg: "L'adresse email existe déjà ! ",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 3,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0
      );

  }

}
Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.blue,
                          size: 40.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }

  Widget build(BuildContext context) {
    
    Future _showDialogTest(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        TextField(
                          controller: utilisateur_ctl,
                          decoration: new InputDecoration(
                              labelText: "Addresse email",
                              icon: Icon(
                                Icons.mail,
                                size: 15,
                              )),
                        ),
                        TextField(
                          controller: password_ctr,
                          obscureText: true,
                          obscuringCharacter: "*",
                          decoration: InputDecoration(
                            hintText: "Mot de passe",
                            icon: Icon(
                              Icons.lock,
                              size: 15,
                            ),
                          ),
                        ),
                        TextField(
                          controller: password_ctr2,
                          obscureText: true,
                          obscuringCharacter: "*",
                          decoration: InputDecoration(
                            hintText: "Repeter mot de passe",
                            icon: Icon(
                              Icons.lock,
                              size: 15,
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            Text(
                              'Niveau d\'accès',
                              style: TextStyle(color: Colors.grey),
                            ),
                            //SizedBox(width: 12,),
                            Spacer(),
                            DropdownButton(
                                value: _value,
                                items: [
                                  /*DropdownMenuItem(
                                child: Text("Niveau d'acccès"),
                                value: 0,
                              ),*/
                                  DropdownMenuItem(
                                    child: Text("Admin"),
                                    value: 0,
                                  ),
                                  DropdownMenuItem(
                                      child: Text("Caissier"), value: 1),
                                ],
                                onChanged: (value) {
                                  setState(() {
                                    _value = value;
                                  });
                                }),
                          ],
                        ),

                        //your code dropdown button here
                      ]),
                );
              },
            ),
            actions: [
              FlatButton(
                onPressed: () {
                  setState(() {

                   

                    String email = utilisateur_ctl.text.toString();
                    final bool isValid = EmailValidator.validate(email);

                    if (isValid == false) {
                      MessageToast m = MessageToast("Adresse email non valide ");
                      m.ShowMessage();
                    } else if (utilisateur_ctl.text.toString().isEmpty) {
                      MessageToast m = MessageToast("Saisir l'adresse email  svp ! ");
                      m.ShowMessage();
                    } else if (password_ctr.text.toString().isEmpty) {
                      MessageToast m = MessageToast('Mot de passe vide !');
                      m.ShowMessage();
                    } else if (password_ctr2.text.toString().isEmpty) {
                      MessageToast m =
                          MessageToast('Veuillez repeter le mot de passe SVP !');
                      m.ShowMessage();
                    } else if (password_ctr.text.toString() ==
                        password_ctr2.text.toString()) {
                          Verrifier_email(email);
                           startTimerVerifierEmail();
                     

                      // utilisateur_ctl.clear();
                      //password_ctr.text="";
                      //pass  word_ctr2.clear();

                    }else{
                      Fluttertoast.showToast(
                  msg: "Mot de passe non identique",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.CENTER,
                  timeInSecForIosWeb: 3,
                  backgroundColor: Colors.red,
                  textColor: Colors.white,
                  fontSize: 16.0
      );
                    }
                  });
                },
                child: Text(
                  'Créer',
                  style: TextStyle(color: Colors.white),
                ),
                color: Colors.blue,
              )
            ],
          );
        },
      );
    }

    var now = DateTime.now();
    String d = DateFormat().format(now);

    return Scaffold(
      body: Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
          image: new AssetImage("assets/images/bg3.png"),
          fit: BoxFit.cover,
        )),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 70,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      '$d',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Compte utilisateur',
                      style: TextStyle(color: Colors.white, fontSize: 17),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 19),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              height: 60,
              color: Colors.white.withOpacity(0.5),
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: TextField(
                    controller: search,
                    onChanged: (value) {
                      _filterList(value);
                    },
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.search),
                        hintText: "Recherche",
                        hintStyle: whiteSubHeadingTextStyle.copyWith(
                            color: hintTextColor)),
                  ),
                ),
              ),
              //color: Colors.black12.withOpacity(0.5),
            ),
            Expanded(
              child: Container(
                color: Colors.white.withOpacity(0.5),
                child: FutureBuilder<List<LoginModel>>(
                    future: DBProvider_new.db.getLogin(),
                    builder: (BuildContext context,
                        AsyncSnapshot<List<LoginModel>> snapshot) {
                      if (snapshot.hasData) {
                        if (!doItJustOnce) {
                          //You should define a bool like (bool doItJustOnce = false;) on your state.
                          list = snapshot.data;
                          filteredList = list;
                          doItJustOnce =
                              !doItJustOnce; //this line helps to do just once.
                        }

                        set_Type(String level) {
                          String st = "";
                          if (level == "0") {
                            st = "Admin";
                          } else if (level == "1") {
                            st = "Caissier";
                          }
                          return st;
                        }

                        return ListView.builder(
                          physics: const AlwaysScrollableScrollPhysics(),
                          shrinkWrap: true,
                          reverse: false,
                          controller: _scrollController,
                          itemCount: filteredList.length,
                          itemBuilder: (BuildContext context, int index) {
                            return Dismissible(
                                key: UniqueKey(),
                                background: Card(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10)),
                                  margin: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 12),
                                  color: Colors.grey[400],
                                  child: Center(
                                      child: Icon(
                                    Icons.delete,
                                    color: Colors.white,
                                  )),
                                ),
                                onDismissed: (direction) {
                                  DBProvider_new.db.deleteLogin(
                                      filteredList[index].username);
                                },
                                child: GestureDetector(
                                  child: AnimationConfiguration.staggeredList(
                                    position: index,
                                    duration: const Duration(milliseconds: 300),
                                    child: SlideAnimation(
                                      verticalOffset: 50.0,
                                      child: FadeInAnimation(
                                          child: Card(
                                        elevation: 2,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        margin: const EdgeInsets.symmetric(
                                            horizontal: 16, vertical: 12),
                                        child: ListTile(
                                          title: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                filteredList[index].username,
                                                style: TextStyle(),
                                              ),
                                              /*Row(
                                                children: [
                                                  Icon(
                                                    Icons.lock,
                                                    size: 12,
                                                    color: Colors.grey,
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  /*Text(
                                                    filteredList[index]
                                                        .password,
                                                    style: TextStyle(
                                                        color:
                                                            Colors.grey[400]),
                                                  ),*/
                                                ],
                                              ),*/
                                            ],
                                          ),
                                          leading: Icon(
                                              Icons.account_circle_rounded),
                                          trailing: Text(
                                            '' +
                                                set_Type(
                                                    filteredList[index].level),
                                            style:
                                                TextStyle(color: Colors.blue),
                                          ),
                                        ),
                                      )

                                          /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                          ),
                                    ),
                                  ),
                                ));
                          },
                        );
                      }
                      return Center(child: CircularProgressIndicator());
                    }),
              ),  
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            LoadLogin();
          });

          ///AddCategorieDialog(context);
          ///
          _showDialogTest(context);
        },
        backgroundColor: Colors.blue[700],
        child: Icon(
          Icons.person_add,
          color: Colors.white,
        ),
      ),
    );
  }
}
