import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/commons/my_info.dart';
import 'package:smartpos/commons/profile_info_big_card.dart';
import 'package:smartpos/commons/profile_info_card.dart';
import 'package:smartpos/pages/CommandePage.dart';
import 'package:smartpos/pages/TestWebListData.dart';
import 'package:smartpos/pages/achat_pos.dart';
import 'package:smartpos/pages/paiementPage.dart';
import 'package:smartpos/pages/HistoryPage.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/StatistiquePage.dart';
import 'package:smartpos/pages/categorie_page.dart';
import 'package:smartpos/pages/client_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/pages/produit_page.dart';
import 'package:smartpos/pages/statistique_page.dart';

import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/widgets/opaque_image.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  int number = 0;
  int number_produit = 0;
  int number_client = 0;
  String profile_name;
  String id;

  void countPeople() async {
    int count = await DBProvider_new.db.queryRowCount();
    setState(() => number = count);
  }

  void countProduit() async {
    int count = await DBProvider_new.db.getCountProduit();
    setState(() => number = count);
  }

  void getProfile() async {
    String profile = await DBProvider_new.db.getNom_Profile();
    setState(() => profile_name = profile);
  }

  void countClient() async {
    int count = await DBProvider_new.db.getCountClient();
    setState(() => number_client = count);
  }

  void meka() async {
    int count = await DBProvider_new.db.Ver_if();
    setState(() {
      id = count.toString();
      print('id is ' + id.toString());
    });
    //setState(() => );
  }

  @override
  void initState() {
    super.initState();
    setState(() {
      /*  getProfile();
      countPeople();
      countProduit();
      countClient();*/
    });
  }
  Future<bool> _onWillPop() async {
    return (await showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        title: new Text("Est-vous sure ?"),
        content: new Text("Voulez-vous quitter l'\application "),
        actions: <Widget>[
          new FlatButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: new Text('Non'),
          ),
          new FlatButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: new Text('Oui'),
          ),
        ],
      ),
    )) ?? false;
  }

  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;


    // DateTime now = DateTime.now();
    //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
    // String formattedDate = DateFormat('d:M:y h:m:s').format(now);

    //  var date = DateTime.fromMicrosecondsSinceEpoch(miliseconds * 1000);
    // String formattedDate= DateFormat(DateFormat.YEAR_MONTH_DAY, 'pt_Br').format(now);

    var now = DateTime.now();
    String d = DateFormat().format(now);

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
          body: Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
                  image: new AssetImage("assets/images/bg3.png"),
                  fit: BoxFit.cover,
                )),
            child: Column(
              children: [
                Container(
                  color: Colors.black12.withOpacity(0.5),
                  height: 70,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 12.0, left: 5),
                        child: Text(
                          '$d',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      Spacer(),
                      InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => Parametre(),
                            ),
                          );
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(top: 15.0, right: 10.0),
                          child: Icon(
                            Icons.settings,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.pushReplacement(context,
                              MaterialPageRoute(builder: (context) => LoginPage()));
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(top: 15.0, right: 8.0),
                          child: Icon(
                            Icons.logout,
                            color: Colors.white,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 50,
                  color: Colors.grey.withOpacity(0.5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 5.0,
                      ),

                      Row(
                        children: [
                          Icon(
                            Icons.home,
                            color: Colors.white,
                            size: 27,
                          ),
                          Text(
                            'Accueil',
                            style: TextStyle(color: Colors.white, fontSize: 22),
                          ),
                        ],
                      ),
                      // Spacer(),
                    ],
                  ),
                ),
                Expanded(
                    child: ListView(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => CategoriePage(),
                                  ),
                                );
                              },
                              child: Container(
                                  width: 150,
                                  //height: double.infinity,

                                  child: Stack(
                                    children: [
                                      Container(

                                        // semanticContainer: true,
                                        // clipBehavior: Clip.antiAliasWithSaveLayer,
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 28.0),
                                              child: Image(
                                                image: AssetImage(
                                                  'assets/menu/categories.png',
                                                ),
                                                width: 90,
                                              ),
                                            ),
                                          )
                                        /*shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              elevation: 5,*/
                                        // margin: EdgeInsets.all(10),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          //   color: Colors.blueGrey[900].withOpacity(0.5),
                                          child: Center(
                                              child: Text(
                                                'Categories'.toUpperCase(),
                                                style: TextStyle(
                                                    color: Colors.white, fontSize: 15),
                                              )),
                                          decoration: BoxDecoration(
                                            //color: Colors.white,
                                            color: Colors.blueGrey[900].withOpacity(0.5),
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(15),
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  )),
                            ),

                           InkWell(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => ProduitPage(),
                                  ),
                                );
                              },
                              child: Container(
                                  width: 150,
                                  //height: double.infinity,

                                  child: Stack(
                                    children: [
                                      Container(

                                        // semanticContainer: true,
                                        // clipBehavior: Clip.antiAliasWithSaveLayer,
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 28.0),
                                              child: Image(
                                                image: AssetImage(
                                                  'assets/menu/produits.png',
                                                ),
                                                width: 90,
                                              ),
                                            ),
                                          )
                                        /*shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              elevation: 5,*/
                                        // margin: EdgeInsets.all(10),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          //   color: Colors.blueGrey[900].withOpacity(0.5),
                                          child: Center(
                                              child: Text(
                                                'Produits'.toUpperCase(),
                                                style: TextStyle(
                                                    color: Colors.white, fontSize: 15),
                                              )),
                                          decoration: BoxDecoration(
                                            //color: Colors.white,
                                            color: Colors.blueGrey[900].withOpacity(0.5),
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(15),
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  )),
                            ),

                            //client
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => ClientPage(),
                                  ),
                                );
                              },
                              child: Container(
                                  width: 150,
                                  //height: double.infinity,

                                  child: Stack(
                                    children: [
                                      Container( 
                                        // semanticContainer: true,
                                        // clipBehavior: Clip.antiAliasWithSaveLayer,
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 28.0),
                                              child: Image(
                                                image: AssetImage(
                                                  'assets/menu/clients.png',
                                                ),
                                                width: 90,
                                              ),
                                            ),
                                          )
                                        /*shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              elevation: 5,*/
                                        // margin: EdgeInsets.all(10),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          //   color: Colors.blueGrey[900].withOpacity(0.5),
                                          child: Center(
                                              child: Text(
                                                'Clients'.toUpperCase(),
                                                style: TextStyle(
                                                    color: Colors.white, fontSize: 16),
                                              )),
                                          decoration: BoxDecoration(
                                            //color: Colors.white,
                                            color: Colors.blueGrey[900].withOpacity(0.5),
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(15),
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  )),
                            ),

//Historique_page
                            InkWell(
                              onTap: () {
                                DBProvider_new.db.deleteAllPanier();

                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => AchatPOS(),
                                  ),
                                );

                              },
                              child: Container(
                                  width: 150,
                                  //height: double.infinity,

                                  child: Stack(
                                    children: [
                                      Container(

                                        // semanticContainer: true,
                                        // clipBehavior: Clip.antiAliasWithSaveLayer,
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 28.0),
                                              child: Image(
                                                image: AssetImage(
                                                  'assets/menu/paiements.png',
                                                ),
                                                width: 90,
                                              ),
                                            ),
                                          )
                                        /*shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              elevation: 5,*/
                                        // margin: EdgeInsets.all(10),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          //   color: Colors.blueGrey[900].withOpacity(0.5),
                                          child: Center(
                                              child: Text(
                                                'Mon panier'.toUpperCase(),
                                                style: TextStyle(
                                                    color: Colors.white, fontSize: 15),
                                              )),
                                          decoration: BoxDecoration(
                                            //color: Colors.white,
                                            color: Colors.blueGrey[900].withOpacity(0.5),
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(15),
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  )),
                            ),

                            //client
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
 
                             InkWell(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => CommandePage(),
                                  ),
                                );
                              },
                              //histoirique()
                              child: Container(
                                  width: 150,
                                  //height: double.infinity,

                                  child: Stack(
                                    children: [
                                      Container(

                                        // semanticContainer: true,
                                        // clipBehavior: Clip.antiAliasWithSaveLayer,
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 28.0),
                                              child: Image(
                                                image: AssetImage(
                                                  'assets/menu/historiques.png',
                                                ),
                                                width: 90,
                                              ),
                                            ),
                                          )
                                        /*shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              elevation: 5,*/
                                        // margin: EdgeInsets.all(10),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          //   color: Colors.blueGrey[900].withOpacity(0.5),
                                          child: Center(
                                              child: Text(
                                                'COMMANDES'.toUpperCase(),
                                                style: TextStyle(
                                                    color: Colors.white, fontSize: 15),
                                              )),
                                          decoration: BoxDecoration(
                                            //color: Colors.white,
                                            color: Colors.blueGrey[900].withOpacity(0.5),
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(15),
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  )),
                            ),
                            

                            InkWell(
                              onTap: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (context) => StatistiquePage(),
                                    //MobilePage
                                  ),
                                );
                              },
                              child: Container(
                                  width: 150,
                                  //height: double.infinity,

                                  child: Stack(
                                    children: [
                                      Container(

                                        // semanticContainer: true,
                                        // clipBehavior: Clip.antiAliasWithSaveLayer,
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 28.0),
                                              child: Image(
                                                image: AssetImage(
                                                  'assets/menu/statistiques.png',
                                                ),
                                                width: 90,
                                              ),
                                            ),
                                          )
                                        /*shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              elevation: 5,*/
                                        // margin: EdgeInsets.all(10),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Container(
                                          width: 140,
                                          height: 140,
                                          //   color: Colors.blueGrey[900].withOpacity(0.5),
                                          child: Center(
                                              child: Text(
                                                'Statistiques'.toUpperCase(),
                                                style: TextStyle(
                                                    color: Colors.white, fontSize: 15),
                                              )),
                                          decoration: BoxDecoration(
                                            //color: Colors.white,
                                            color: Colors.blueGrey[900].withOpacity(0.5),
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(15),
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  )),
                            )

                            //client
                          ],
                        ),
                      ],
                    ))
              ],
            ),
          )),
    );
  }
}
