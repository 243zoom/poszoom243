import 'package:flutter/material.dart';
import 'package:smartpos/utils/Database.dart';
String nbr="";
String produit1="";
String prix="";
int total=0;
class Appercu extends StatefulWidget {
  Appercu(String nbr1,produit2,String prix1){
    nbr=nbr1;
    produit1=produit2;
    prix=prix1;

  }
  @override
  _AppercuState createState() => _AppercuState();
}

class _AppercuState extends State<Appercu> {


  int  p=int.parse(prix.toString());
  int n=int.parse(nbr.toString());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {

       total=p*n;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Appercu'),
        leading: Icon(Icons.remove_red_eye),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                color: Colors.grey[700],
                child:Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('$produit1 ',style: TextStyle(color: Colors.white),),
                    ],
                  ),
                ),
              ),
            ),
            //SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                color: Colors.blueAccent,
                child:Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('Prix produit : $prix',style: TextStyle(color: Colors.white),),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                color: Colors.blueAccent,
                child:Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('Quantité : $nbr',style: TextStyle(color: Colors.white),),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                color: Colors.blueAccent,
                child:Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('Montant total  : $total',style: TextStyle(color: Colors.white),),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: FlatButton(onPressed: (){

              },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18.0),
                      side: BorderSide(color: Colors.blueAccent)
                  ),
                  color: Colors.grey[800],
                  child: Text("PDF",style: TextStyle(color: Colors.white),) ),
            )
          ],
        )
        ,
      ),
    );
  }
}
