import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_mac/get_mac.dart';
import 'dart:async';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:fluttertoast/fluttertoast.dart';
class Activation extends StatefulWidget {
  @override
  _ActivationState createState() => _ActivationState();
}


class _ActivationState extends State<Activation> {
  String _platformID;
  TextEditingController controller=TextEditingController();
  TextEditingController client_ctrl=TextEditingController();
  TextEditingController contact_ctrl=TextEditingController();
  String _dropDownValue;

  Future<void> initPlatformState() async {
    String platformVersion;
    try {
      platformVersion = await GetMac.macAddress;
    } on PlatformException {
      platformVersion = 'Failed to get Device MAC Address.';
    }
    print("MAC-: " + platformVersion);

    if (!mounted) return;
    setState(() {

      _platformID = platformVersion;
      controller.text=platformVersion.toString();
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initPlatformState();
  }

  Future senddata(String client,String contact,String mac,String delais) async {
   /* final response = await http.post("https://posapi.visionpourtousrdcongo.com/demande.php", body: {
      "client": client,
      "contact": contact,
      "adresse_mac":mac,
      "periode":delais,

    });
*/
    var url = 'http://apirobipos.zoom243.com/demande.php';
    var data = {'client': client,"contact":contact,"adresse_mac":mac,"periode":delais};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));
    //var datauser = json.decode(response.body);
    print('sucess');
    Fluttertoast.showToast(
        msg: "Demande sousmise avec success",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.blue,
        textColor: Colors.white,
        fontSize: 16.0
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Center(child: Icon(Icons.add_alert,color: Colors.amber,size: 50,)),
          Container(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text("Votre application n'est pas activer ou expirée veuillez Cliquez sur passer à l'activation pour soumettre votre demande",style: TextStyle(color: Colors.blue),textAlign:TextAlign.justify,),
            ),
          ),
           Container(
              padding: EdgeInsets.only(left: 10,right: 10),

              child: Center(
                child: TextField(
                  decoration: InputDecoration(
                    //border: InputBorder.none,
                    labelText: "Votre adresse mac",labelStyle: TextStyle(color: Colors.grey)
                  ),
                  controller: controller,
                ),
              ),
            ),

          Container(
            padding: EdgeInsets.only(left: 10,right: 10),
            child: Center(
              child: TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.person,size: 16,),

                    labelText: "Votre nom",labelStyle: TextStyle(color: Colors.grey)
                ),

                controller: client_ctrl,

                //controller: controller,
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 10,right: 10),

            child: Center(
              child: TextField(
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.phone,size: 16,),
                    //border: InputBorder.none,
                    labelText: "Telephone",labelStyle: TextStyle(color: Colors.grey)
                ),
                controller: contact_ctrl,

                //controller: controller,
              ),
            ),
          ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: DropdownButton(
                hint: _dropDownValue == null
                ? Text('Durée de la licence')
                    : Text(
                _dropDownValue,
                style: TextStyle(color: Colors.blue),
                ),
                isExpanded: true,
                iconSize: 30.0,
                style: TextStyle(color: Colors.blue),
                items: ['3 mois', '6 mois', '12 mois'].map(
                (val) {
                return DropdownMenuItem<String>(
                value: val,
                child: Text(val),
                );
                },
                ).toList(),
                onChanged: (val) {
                setState(
                () {
                _dropDownValue = val;
                },
                );
                },
          ),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                FlatButton(onPressed: (){

                  if (Navigator.canPop(context)) {
                    Navigator.pop(context);
                  } else {
                    SystemNavigator.pop();
                  }

                },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.black12)
                    ),
                    color: Colors.white,
                    child: Text("Fermer",style: TextStyle(color: Colors.grey),) ),

                Spacer(),
                FlatButton( onPressed: (){
                      senddata(client_ctrl.text,contact_ctrl.text,_platformID.toString(),_dropDownValue.toString());
                  print('sucess '+client_ctrl.text);
                      },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)
                    ),
                    color: Colors.amber,
                    child: Text("Passer à l'activation",style: TextStyle(color: Colors.white),) ),
              ],
            ),
          ),


        ],
      ),
    );
  }
}
