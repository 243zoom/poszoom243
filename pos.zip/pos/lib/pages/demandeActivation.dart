import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:smartpos/class_dart/ActivationModel.dart';
import 'package:smartpos/pages/DemandeAct_Page.dart';
import 'package:smartpos/pages/Profile_page.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:intl/intl.dart';

class DemandeActiviation extends StatefulWidget {
  @override
  _DemandeActiviationState createState() => _DemandeActiviationState();
}

class _DemandeActiviationState extends State<DemandeActiviation> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }
  startTimer()async{

    var dur=Duration(seconds: 2);
    return Timer(dur,route);
  }

  route(){
    Navigator.of(context).pop();
    Navigator.pushReplacement(context, MaterialPageRoute(

        builder:(context)=> Profile_UI()

    )
    );
  }

  @override
  Widget build(BuildContext context) {

    Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[

                        SpinKitCircle(
                          color: Colors.grey[400],
                          size: 30.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }


    return Scaffold(

      backgroundColor: Colors.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

        Center(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(child: Text("Application non activée ! ",style: TextStyle(fontSize: 20),)),
          ),
        ),

          Center(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FlatButton(onPressed: (){

                  //trial version
                   String delais="7";
                   DateTime now = DateTime.now();
                   //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
                   String formattedDate = DateFormat('yyyy-M-d').format(now); // yyyy:d:m
                   ActivationModel activationModel=ActivationModel(delais: delais,date: formattedDate);
                   DBProvider_new.db.newActivation(activationModel);
                  //load and acces page user
                   _showDialogLoad(context);
                   startTimer();

                  print('active success'+formattedDate);

                  },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                          side: BorderSide(color: Colors.amber)
                      ),
                      color: Colors.amber,
                      child: Text("Passer à l'essaie de 7 jours",style: TextStyle(color: Colors.white),) ),
                ),


                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FlatButton(onPressed: (){
                    Navigator.pushReplacement(context, MaterialPageRoute(

                        builder:(context)=> Activation()

                    )
                    );
                  },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                          side: BorderSide(color: Colors.blue)
                      ),
                      color: Colors.blue,
                      child: Text("Activer l'application",style: TextStyle(color: Colors.white),) ),
                ),

              ],
            ),
          ),


        ],
      ),
    );
  }
}
