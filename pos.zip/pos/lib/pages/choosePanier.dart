 
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/PanierModel.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/achat_pos.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
String client="";
class ChoosePanier extends StatefulWidget {
ChoosePanier(String c){
client=c;
}
  @override
  _ChoosePanierState createState() => _ChoosePanierState();
}

class _ChoosePanierState extends State<ChoosePanier> {
  @override

 TextEditingController sarch_ctrl=TextEditingController();
 ScrollController _scrollController =ScrollController(); 

 List<ProduitModel> list = List<ProduitModel>();
  List<ProduitModel> filteredList = List<ProduitModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.Produit.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }

  Widget build(BuildContext context) {

    var now1 = DateTime.now();
    String d= DateFormat().format(now1);

    return  Scaffold(
      body: Container( 
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),

        child: Column(
          
          children: [
           Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Liste',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),

        Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

           Container(
                height: 60,
               color: Colors.white.withOpacity(0.5),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        Flexible(
                          child: TextField(
                          controller: sarch_ctrl,
                          onChanged: (value) {
                            _filterList(value);
                          },
                          decoration: InputDecoration(
                              border: InputBorder.none,

                              prefixIcon: Icon(Icons.search),
                              hintText: "Recherche",
                              hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                        ),
                        
                        ),

                        /*Flexible(
                          child: 
                           Row(
                             children: [
                               Icon(Icons.qr_code_rounded,size: 30,),
                                Icon(Icons.code)
                             ],
                           ),
                          ),*/

                      ],
                    ),
                  ),
                ),
                //color: Colors.black12.withOpacity(0.5),
              ),
        /*Container(
          height: 60,
          color: Colors.white.withOpacity(0.5),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              Icon(Icons.qr_code_rounded,size: 30,),
              SizedBox(width: 15.0,),
              Icon(Icons.code)
            ],),
          ),

        ),*/

      Expanded(
                child: Container(
                  color: Colors.white.withOpacity(0.5), 
                  child: FutureBuilder<List<ProduitModel>>( 
                     future: DBProvider_new.db.getAllProduit(),
                      builder: (BuildContext context, AsyncSnapshot<List<ProduitModel>> snapshot) {
                        
                         
                        if (snapshot.hasData) {
                          if (!doItJustOnce) {
                            //You should define a bool like (bool doItJustOnce = false;) on your state.
                            list = snapshot.data;
                            filteredList = list;
                            doItJustOnce = !doItJustOnce; //this line helps to do just once.
                          } 

                          return ListView.builder( 
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              reverse: false,
                              controller: _scrollController,
                              itemCount: filteredList.length, 
                              itemBuilder: (BuildContext ctx, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 300),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                        child: GestureDetector( 
                                          onTap: (){

                                              DateTime now = DateTime.now();
                                              //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
                                              String formattedDate = DateFormat('d:m:y h:m:s').format(now);

                                            PanierModel panierModel=PanierModel(client:client,prix: filteredList[index].prix.toString(),devise:filteredList[index].devise.toString(),date: formattedDate,produit:filteredList[index].Produit.toString() );
                                             DBProvider_new.db.newPanier(panierModel); 
                                             print('suc');
                                            
                                            Navigator.of(context).pop();

                                             Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (context) => AchatPOS(),
                                              ),
                                            );

                                          }, 
                                          child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Container(
                                                color: Colors.white,
                                                width: 150,
                                                height: 50,
                                                child: Padding(
                                                  padding: const EdgeInsets.only(left:8.0,top: 1.0),
                                                  child: Row(
                                                    children: [
                                                      Text(filteredList[index].Produit.toString()),
                                                      Spacer(), 
                                                    ],
                                                  ),
                                                ),
                                                

                                          ),
                                        ),
                                          )
                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                    ),
                                  ),
                                );
                              });

                        }
                        return Center(child: CircularProgressIndicator());
                      }),
                ) 
            ),

      
       /* Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
            padding: const EdgeInsets.all(10.0),
            child: FlatButton(
            onPressed: () {

            },
           shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.circular(18.0),
           side: BorderSide(color: Colors.blue[700])),
           color: Colors.blue[700],
           child: Text(
          "Terminer la selection",
         style: TextStyle(color: Colors.white),
         )),
          ),
          ],
        )*/

        
        ],
        
        
        ),
        

        

      )
      
    );
  }
}