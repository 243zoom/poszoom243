import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/class_dart/Vente_model.dart';
import 'package:smartpos/pages/Commande_client_page.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/pages/Printing.dart';
import 'package:url_launcher/url_launcher.dart';
int client;
String statut;
String client_name="";
String pr;
 
class List_Commande extends StatefulWidget {
  List_Commande(int client_par,String st1){
    client=client_par;
    statut=st1;
  }
  @override
  _List_CommandeState createState() => _List_CommandeState();
}

class _List_CommandeState extends State<List_Commande> {

  void Paiement(int client,St)async{
     var d=await DBProvider_new.db.Paye_commande(client, St);
     return d;
  }
   Set_Statut()async{
    var a=await DBProvider_new.db.get_statut_by_client(client);
    setState(() {
      return statut=a;
    });



  }
    void View_name_Client(int id_client)async{
    String client=await DBProvider_new.db.getViewNameClientByID(id_client);

    setState(() {
    //  return client;
     client_name=client;
     print('sys'+ client_name);
    });
  }
  //if for btn
  Set_statut_btn(String s){
    var set_it="";
    if(s=="0"){
      return set_it="Facturer";
    }
    else if(s=="1"){
      return set_it="Payer";
    }else if(s=="2"){
      return set_it="Imprimer";
    }

    return set_it;
  }


  @override
  void initState() {
   // Set_Statut();
    View_name_Client(client);
    Set_statut_btn(statut);

    print('lis tid client is '+client.toString());
    // TODO: implement initState
    super.initState();


    setState(() {

      print(statut);

      print('client ud '+client.toString());



    });
  }

    Future<String>Name_produitById(String  id_parse)async{
    String name=await DBProvider_new.db.getViewProduitNameByID(id_parse);
    return name;
  }

  List<CommandeModel> list = List<CommandeModel>();
  List<CommandeModel> filteredList = List<CommandeModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.Client_id.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }

  @override
  Widget build(BuildContext context) {
    Future _showDialogLoad(context) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        Text('Voulez-vous confirmer ce paiement ?',style: TextStyle(color: Colors.black),),
                        SizedBox(height: 11,),
                        Row(
                          children: [
                            InkWell(
                              onTap: (){
                                Paiement(client,"2");

                                Navigator.of(context).pop();
                                print('payer');

                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));


                                setState(() {


                                  statut="2";


                                });
                              },
                              child: Text('Oui',style: TextStyle(color: Colors.blue),),
                            ),
                            Spacer(),
                            InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                              },
                              child: Text('Non',style: TextStyle(color: Colors.red),),
                            )
                          ],
                        )
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }
    //



    Future _showDialogDelete(context,int id) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        Text('Voulez-vous confirmer la suppression ?',style: TextStyle(color: Colors.black),),
                        SizedBox(height: 11,),
                        Row(
                          children: [
                            InkWell(
                              onTap: (){


                                Navigator.of(context).pop();
                                DBProvider_new.db.deleteCommande(id);
                                /* Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));*/


                                setState(() {



                                });
                              },
                              child: Text('Oui',style: TextStyle(color: Colors.blue),),
                            ),
                            Spacer(),
                            InkWell(
                              onTap: (){
                                Navigator.of(context).pop();
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));
                              },
                              child: Text('Non',style: TextStyle(color: Colors.red),),
                            )
                          ],
                        )
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url, forceWebView: true);
    } else {
      throw 'Could not launch $url';
    }
 }
    //choice paiment

    Future _showChoicePaiement(context) async {

      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          onTap: (){
                            Navigator.of(context).pop();
                            _showDialogLoad(context);
                          },
                          child: Text('Paiement cash'),
                        ),
                        Divider(),
                       InkWell(
                         onTap: (){
                            
                          const url = 'https://api-testbed.maxicashapp.com/payentry?data={PayType:"MaxiCash",Amount:"1000",Currency:"maxiDollar",Telephone:"00243977081930",MerchantID:"bb61d2ccbfff48429f9f4097621e7b63",MerchantPassword:"8ff43c7c7da54d56a4627eed9ec9e00a",Language:"fr",Reference:"ROBI-POS",Accepturl:"zoom243.com",Cancelurl:"zoom243.com",Declineurl:"zoom243.com",NotifyURL:"zoom243.com"}';
                            launchURL(url);
                         },
                         child: Text('Maxicash paiement'),                         
                       ),
                       Divider(),
                        InkWell(
                         onTap: (){

                         },
                         child: Text('PayPal'),                         
                       ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }

var now = DateTime.now();
    String d = DateFormat().format(now);


    return Scaffold(


        body:
        Container(
          decoration: new BoxDecoration(
              image: new DecorationImage(
                image: new AssetImage("assets/images/bg3.png"),
                fit: BoxFit.cover,

              )
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
                Container(
            color: Colors.black12.withOpacity(0.5),
            height: 80,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    '$d',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(Icons.shopping_cart,color: Colors.white,)
                ),
                
              ],
            ),
          ),

     Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 19),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  ),
 
                ],
              ),
            ),

              


              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),

              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.person,color: Colors.grey[700],),
                      ),
                      SizedBox(width: 5,),

                      Text(client_name.toString()),
                    Spacer(),
                     /* Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: FlatButton(onPressed: (){

                        },
                          color: Colors.blueAccent,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                              side: BorderSide(color: Colors.blueAccent)
                          ),

                          child: Text('Facturer',style: TextStyle(color: Colors.white),),

                        ),
                      ),*/
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: FlatButton(onPressed: (){
                          //

                          if(statut=="0"){
                            print("Printing facture");
                            //facture
                            //prirint
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => PrintingPage('Report POS',client,"NON PAYEE"),

                              ),
                            );

                            Paiement(client,"1");


                          }else if(statut=="1"){
                            //confirme first to valide

                            print("payé");
                            _showChoicePaiement(context);
                           // _showDialogLoad(context);

                            //Paiement(client,"2");
                          }else{
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => PrintingPage('Report POS',client,"PAYEE"),

                              ),
                            );
                          }


                          setState(() {
                            Set_Statut();
                            DBProvider_new.db.getAllCommandeByClient(client);
                          });
                          print("sucess");

                        },
                          color: Colors.blueAccent,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                              side: BorderSide(color: Colors.blueAccent)
                          ),

                          child: Text(Set_statut_btn(statut).toString(),style: TextStyle(color: Colors.white),),

                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                  child: FutureBuilder<List<CommandeModel>>(
                    //  future: DBProvider_new.db.getAllProduit(),
                    future:DBProvider_new.db.getAllCommandeByClient(client),
                    builder: (BuildContext context, AsyncSnapshot<List<CommandeModel>> snapshot) {
                      if (snapshot.hasData) {

                        Set_statut(String s){

                          var set_it="";
                          if(s=="0"){
                            return set_it="Attente";
                          }
                          else if(s=="1"){
                            return set_it="Facturé";
                          }else if(s=="2"){
                            return set_it="Payé";
                          }
                          return set_it;
                        }



                        return ListView.builder(
                          itemCount: snapshot.data.length,
                          itemBuilder: (BuildContext context, int index)  {

                            CommandeModel item =   snapshot.data[index];

                            // Uint8List  _bytesImage2 = Base64Decoder().convert(item.image);

                            return Dismissible(
                              key: UniqueKey(),
                              background: Card(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                                margin: const EdgeInsets.symmetric(horizontal: 1, vertical: 12),
                                color: Colors.white,child: Center(child: Icon(Icons.delete,color: Colors.grey[400],)),
                              ),
                              onDismissed: (direction) {
                                _showDialogDelete(context, item.id);
                              },
                              child:  Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Card(
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                                  margin: const EdgeInsets.symmetric(horizontal: 1, vertical: 12),

                                  child: ListTile(
                                    title:Text(item.view_produit),/*FutureBuilder<String>(
                                      future: Name_produitById(item.produit_id),
                                      builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
                                        if(snapshot.hasData){
                                          return Text('${snapshot.data}');
                                        }
                                        return Container();
                                      },
                                    ),*/
                                    /*Text(
                                      DBProvider_new.db.loadSampleData2(item.produit_id).toString()+' '+item.quantite,
                                      style: TextStyle(fontSize: 16.0),
                                    ),*/
                                    subtitle: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: <Widget>[
                                        Text(
                                          item.date_commande.toString(),
                                          style: TextStyle(fontSize: 14.0),
                                        ),
                                      ],
                                    ),
                                    trailing: Text(Set_statut(item.statuts).toString()),
                                    /*leading: ClipOval(
                                          child:item.image == null

                                              ? new Text('No image value.')
                                              :  Image.memory(_image)
                                      ),*/

                                  ),

                                ),
                              ),

                            );

                          },
                        );
                      } else {
                        return Center(child: CircularProgressIndicator());
                      }
                    },
                  ),

              ),
            ],
          ),
        ),
 backgroundColor: Colors.white,
    );
  }
}
