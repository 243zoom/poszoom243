 import 'dart:convert';

import 'package:flutter/material.dart'; 
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';

class MobilePage extends StatefulWidget {
  @override
  _MobilePageState createState() => _MobilePageState();
}

class TrackingData {
  int id;
  int Mobile1;
  String date_tracking1;

  TrackingData({
    this.id,
    this.Mobile1,
    this.date_tracking1
  });

  factory TrackingData.fromJson(Map<String, dynamic> json) {
    return TrackingData(
        id: json['id'],
        Mobile1: json['number'],
        date_tracking1: json['date_tracking']
    );
  }
}

class _MobilePageState extends State<MobilePage> {
  TextEditingController mobile_tracker=TextEditingController();


  @override

  void initState(){
    super.initState();
  
  }

  Future<List<TrackingData>> fetchStudents() async {
    final String apiURL = 'http://gpstest.zoom243.com/get_tracking_request.php';

   var response = await http.post(apiURL);
  //  var response = await http.post(apiURL, body: json.encode(data));
    if (response.statusCode == 200) {

      final items = json.decode(response.body).cast<Map<String, dynamic>>();
      List<TrackingData> studentList = items.map<TrackingData>((json) {
        return TrackingData.fromJson(json);
      }).toList();
      print('a get data successfully');
      return studentList;
    }
    else {
      print('failed');
      throw Exception('Failed to load data from Server.');
    }
  }

  Future sendData(String mobile) async {

    var url = 'https://gpstest.zoom243.com/tracking_mobile.php';
    var data = {'mobile': mobile};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));
    //var datauser = json.decode(response.body);
    print('sucess');
    Fluttertoast.showToast(
        msg: "Success",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.blue,
        textColor: Colors.white,
        fontSize: 16.0
    );
  }


  Widget build(BuildContext context) {

    Future _showDialogNewTracker(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: mobile_tracker,
                                  decoration: new InputDecoration(labelText: "Telephon with +243",
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          // color: Colors.red,
                                            width: 5.0),
                                      )

                                  ),
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: FlatButton(onPressed: (){
                                      sendData(mobile_tracker.text);
                                      mobile_tracker.clear();
                                      Navigator.of(context).pop();

                                    },
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(18.0),
                                            side: BorderSide(color: Colors.blue[700])
                                        ),
                                        color: Colors.blue[700],
                                        child: Text("Confirm",style: TextStyle(color: Colors.white),) ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }




    return Scaffold(

    body:  FutureBuilder<List<TrackingData>>(
          future: fetchStudents(),
          builder: (context, snapshot) {

            if (!snapshot.hasData) return Center(
                child: CircularProgressIndicator()
            );

            return ListView(
              children: snapshot.data
                  .map((data) => Column(children: <Widget>[
                GestureDetector(
                  onTap: (){
                    print(data.Mobile1);},
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                            padding: EdgeInsets.fromLTRB(0, 20, 0, 10),
                            child: Text('ID = ' + data.id.toString(),
                                style: TextStyle(fontSize: 21))),
                        Padding(
                            padding: EdgeInsets.fromLTRB(0, 0, 0, 10),
                            child: Text('Name = ' + data.Mobile1.toString(),
                                style: TextStyle(fontSize: 21))),

                      ]),)
              ],))
                  .toList(),
            );
          },
        )
    );
  }
}
