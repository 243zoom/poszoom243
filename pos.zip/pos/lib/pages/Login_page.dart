import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smartpos/class_dart/ActivationModel.dart';
import 'package:smartpos/class_dart/LoginModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/commons/radial_progress.dart';
import 'package:smartpos/pages/ExpiredPage.dart';
import 'package:smartpos/pages/Profile_page.dart';
import 'package:smartpos/pages/UI.dart';
import 'package:smartpos/pages/UI_Caisse.dart';
import 'package:smartpos/pages/register_page.php.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:jiffy/jiffy.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart'; 

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:get_mac/get_mac.dart';
 
class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

File imageFile;
String usename_text, password_text;
Uint8List _bytesImage;
File _image;
String base64Image;
Image img;
String pathing;
Image img2 = Image(
  image: AssetImage('assets/images/client.png'),
);
String profile_name = "";
String reponseLogin;
String cmd_log;

TextEditingController email_ctr = TextEditingController();

class _LoginPageState extends State<LoginPage> {
  List<ActivationModel> items = new List();
  String date_from_db = "";

  TextEditingController utilisateur_ctl = TextEditingController();
  TextEditingController password_ctr = TextEditingController();
  TextEditingController password_ctr2 = TextEditingController();
  TextEditingController password = TextEditingController();

  List<ProfileModel> profile_items = new List();

  Send_mail()async{
     String username = 'ruessimusafiri7@gmail.com';
  String password = '0821956665';

  final smtpServer = gmail(username, password);
  // Use the SmtpServer class to configure an SMTP server:
  // final smtpServer = SmtpServer('smtp.domain.com');
  // See the named arguments of SmtpServer for further configuration
  // options.  
  
  // Create our message.
  final message = Message()
    ..from = Address(username, 'Your name')
    ..recipients.add('pathylwalaba@gmail.com')
    //..ccRecipients.addAll(['destCc1@example.com', 'destCc2@example.com'])
    //..bccRecipients.add(Address('bccAddress@example.com'))
    ..subject = 'Test Dart Mailer library :: 😀 :: ${DateTime.now()}'
    ..text = 'This is the plain text.\nThis is line 2 of the text part.'
    ..html = "<h1>Test</h1>\n<p>Hey! Here's some HTML content</p>";
    print('going');
  try {
    final sendReport = await send(message, smtpServer);
    print('Message sent: ' + sendReport.toString());
  } on MailerException catch (e) {
    print('Message not sent.');
    for (var p in e.problems) {
      print('Problem: ${p.code}: ${p.msg}');
    }
  }
  }

  Future<void> _showSelectionDialog(BuildContext context) {




    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text("From where do you want to take the photo?"),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    GestureDetector(
                      child: Text("Gallery"),
                      onTap: () {
                        _openGallery(context);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text("Camera"),
                      onTap: () {
                        // _openCamera(context);
                        getImageFromCamera();
                      },
                    )
                  ],
                ),
              ));
        });
  }

  

  Future getImageFromCamera() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    List<int> imageBytes = image.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    img = Image.memory(base64Decode(base64Image));
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + image.path);
    _bytesImage = Base64Decoder().convert(base64Image);
    // img= Image.memory(base64Decode(base64Image));
    setState(() {
      imageFile = image;
      Navigator.of(context).pop();
      DBProvider_new.db.getAllCategorie();
    });
  }

  void GetDateFromDb() async {
    String date = await DBProvider_new.db.ActivationDate();
    setState(() {
      date_from_db = date.toString();
      print('her eis ' + date.toString());

      // final birthdayDate = DateTime(date.toString(),,);
      var a = Jiffy(date).year;
      var d = Jiffy(date).dateTime.day;
      var m = Jiffy(date).month;

      final date1 = DateTime(a, m, d); //yyyy:m:d
      //final d= DateTime(2020,12, 28);
      final toDayDate = DateTime.now();
      var different = toDayDate.difference(date1).inDays;
      //   final difference = date2.difference(date1).inDays;
      int day = int.parse(different.toString());

      if (day <= 7) {
        print('votre périod est valide  $different');

        // 19362
      } else {
        print('Application expirée');
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => ExpiredPage()));
        /*if (Navigator.canPop(context)) {
          Navigator.pop(context);
        } else {
          SystemNavigator.pop();
        }*/

      }
    });
  }

  @override
  void initState() {
    DBProvider_new.db.getInfos().then((notes) {
      setState(() {
        notes.forEach((note) {
          profile_items.add(ProfileModel.fromMap(note));
        });
      });
    });
    GetDateFromDb();
    getPhoto();
    getProfile();
    setState(() {});
    // TODO: implement initState
    super.initState();
  }

  void _openGallery(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.gallery);
    this.setState(() {
      imageFile = picture;
      Navigator.of(context).pop();
    });
    // Navigator.of(context).pop();
  }

  _setImageView() {
    if (imageFile != null) {
      return Image.file(imageFile);
    } else {
      // return Text("Please select an image");

      return Icon(
        Icons.person,
        size: 80,
      );
    }
  }

  LoginRequest(String a, String p) async {
    String level_request = await DBProvider_new.db.Login(a, p);

    setState(() {
      reponseLogin = level_request;
    });
  }

  getPhoto() async {
    String photo = await DBProvider_new.db.getPhoto();

    setState(() {
      pathing = photo;
    });
    //setState(() =>  img2=Image.memory(base64Decode(photo)));
  }

  startTimer() async {
    var dur = Duration(seconds: 4);
    return Timer(dur, route);
  }

  route() {
    if (reponseLogin == "0") {
      print("admin");
      email_ctr.clear();
      password_ctrl.clear();
      Navigator.pop(context);

      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => ProfilePage()));
    } else if (reponseLogin == "1") {
      print('Caissier');
      email_ctr.clear();
      password_ctrl.clear();
      Navigator.pop(context);
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => CaissePage()));
    } else {
      print("Echec");
      Navigator.pop(context);
      MessageToast m = MessageToast("Echec d'authentification");
      m.ShowMessage();
    }
  }

  //verifier l'email si existant
 SendNotificationEmail(String email)async{
     var url = 'http://pos.zoom243.com/send_notification_mail.php';

    // Store all data with Param Name.
    var data = {'email': email};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.

    if (response.statusCode == 200) {
      // If the call to the server was successful, parse the JSON
     // List<dynamic> values=new List<dynamic>();
     // values = json.decode(response.body); 
      Map<String, dynamic> data = json.decode(response.body);
      String  req = data["message"].toString(); 



    } else {
      // If that call was not successful, throw an error. 
      
      throw Exception('Failed to load post verifier votre connexion');
    }


  }
 
  startTimerVerifierEmail() async {
    var dur = Duration(seconds: 1);
    return Timer(dur, routeEmail);
  }

routeEmail(){

  if(cmd_log=="0"){


                                          LoginModel lm = LoginModel(
                                        username:
                                            utilisateur_ctl.text.toString(),
                                        password: password_ctr2.text.toString(),
                                        level: "0");
                                    DBProvider_new.db.newLogin(lm);

                                    utilisateur_ctl.clear();
                                    password_ctr2.clear();
                                    password_ctr.clear();

                                    Fluttertoast.showToast(
                                        msg: "Success",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 1,
                                        backgroundColor: Colors.blue,
                                        textColor: Colors.white,
                                        fontSize: 16.0);

     Navigator.of(context).pop();
      //send notification to user 
    SendNotificationEmail(utilisateur_ctl.text);
  }else{
       Fluttertoast.showToast(
          msg: "L'adresse email existe déjà !",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 3,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0
      );

  }

}


  Verrifier_email(String email) async {
    int a = await DBProvider_new.db.verifier_email_client(email);
    setState(() {
        return cmd_log= a.toString();
    });
  }

  void getProfile() async {
    String profile = await DBProvider_new.db.getNom_Profile();
    setState(() => profile_name = profile);
  }

  @override
  Widget build(BuildContext context) {
    Widget _title() {
      return Column(
        // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ///SizedBox(height: 20,),
          ///
          Container(
            decoration: BoxDecoration(
                image: DecorationImage(
              image: AssetImage("assets/images/back2.jpg"),
              fit: BoxFit.cover,
            )),
            //color: Colors.blue[600],
            height: 230,
            child: Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                Text(
                  "Login",
                  style: GoogleFonts.lato(
                      color: Colors.white, letterSpacing: 1.0, fontSize: 23.0),
                ),
                SizedBox(
                  height: 25,
                ),
                Stack(
                  children: [
                    Align(
                      child: RadialProgress(
                          width: 4,
                          goalCompleted: 0.9,
                          child: Container(
                            width: 80.0,
                            height: 80.0,
                            child: ClipOval(
                              child: pathing == null
                                  ? new Text('No image.')
                                  : Image.file(
                                      File(pathing),
                                      fit: BoxFit.contain,
                                    ),
                            ),
                          )),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  '$profile_name',
                  style: GoogleFonts.lato(
                      color: Colors.white, letterSpacing: 1.0, fontSize: 15.0),
                ),
              ],
            ),
          ),
        ],
      );
    }

    Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.blue,
                          size: 30.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }

    Future _showDialogCreerCompte(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        TextField(
                          controller: utilisateur_ctl,
                          decoration: new InputDecoration(
                              labelText: "Email",
                              icon: Icon(
                                Icons.mail,
                                size: 15,
                              )),
                        ),
                        TextField(
                          controller: password_ctr,
                          obscureText: true,
                          obscuringCharacter: "*",
                          decoration: InputDecoration(
                            hintText: "Mot de passe",
                            icon: Icon(
                              Icons.lock,
                              size: 15,
                            ),
                          ),
                        ),
                        TextField(
                          controller: password_ctr2,
                          obscureText: true,
                          obscuringCharacter: "*",
                          decoration: InputDecoration(
                            hintText: "Répéter",
                            icon: Icon(
                              Icons.lock,
                              size: 15,
                            ),
                          ),
                        ),

                        SizedBox(
                          height: 10,
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            FlatButton(
                              onPressed: () {
                                setState(() {
                                  String email =
                                      utilisateur_ctl.text.toString();
                                  final bool isValid =
                                      EmailValidator.validate(email);

                                  if (isValid == false) {
                                    MessageToast m =
                                        MessageToast("Adresse email non valide ");
                                    m.ShowMessage();
                                  } else if (utilisateur_ctl.text
                                      .toString()
                                      .isEmpty) {
                                    MessageToast m = MessageToast(
                                        "Saisir l'adresse email  svp ! ");
                                    m.ShowMessage();
                                  } else if (password_ctr.text
                                      .toString()
                                      .isEmpty) {
                                    MessageToast m = MessageToast('Mot de passe vide !');
                                    m.ShowMessage();
                                  } else if (password_ctr2.text
                                      .toString()
                                      .isEmpty) {
                                    MessageToast m = MessageToast(
                                        'Veuillez repeter le mot de passe SVP !');
                                    m.ShowMessage();
                                  } else if (password_ctr.text.toString() ==
                                      password_ctr2.text.toString()) {

                                        
                                        Verrifier_email(email);
                                        startTimerVerifierEmail();

                                    
                                   /* setState(() {
                                      //Navigator.of(context).pop();
                                      //_showDialogLoad(context);
                                    });*/

                                    // utilisateur_ctl.clear();
                                    //password_ctr.text="";
                                    //pass  word_ctr2.clear();

                                  }else{
                                    //email
                                Fluttertoast.showToast(
                                            msg: "Mot de passe nom identique",
                                            toastLength: Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.CENTER,
                                            timeInSecForIosWeb: 1,
                                            backgroundColor: Colors.blue,
                                            textColor: Colors.white,
                                            fontSize: 16.0);

                                      }
                                });
                              },
                              child: Text(
                                'Confirmer',
                                style: TextStyle(color: Colors.white),
                              ),
                              color: Colors.blue,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18.0),
                                  side: BorderSide(color: Colors.blueAccent)),
                            ),
                          ],
                        )

                        //your code dropdown button here
                      ]),
                );
              },
            ),
            actions: [],
          );
        },
      );
    }

    return SafeArea(
        child: Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
              image: new AssetImage("assets/images/walpaper.jpg"),
              fit: BoxFit.cover,
            )),
          ),
          Container(
            color: Colors.grey.withOpacity(0.6),
          ),
          Column(
            children: [
              Container(
                color: Colors.black.withOpacity(0.7),
                height: 50,
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Robi-POS',
                        style: TextStyle(color: Colors.white, fontSize: 19),
                      ),
                    ),
                    Spacer(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          //Text('Connexion',style: TextStyle(color: Colors.white,fontSize: 18),),
                          //Icon(Icons.person_pin,color: Colors.white,size: 19,)
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Align(
            alignment: Alignment(0.0, 0.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Icon(
                      Icons.circle,
                      color: Colors.white,
                      size: 100,
                    ),
                    Text(
                      profile_items[0].business_name,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    )
                  ],
                ),

                SizedBox(
                  height: 20,
                ),

                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Adresse email',
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Container(
                    decoration: new BoxDecoration(
                        color:
                            Colors.white, //new Color.fromRGBO(255, 0, 0, 0.0),
                        borderRadius: new BorderRadius.all(
                          Radius.circular(5.0),
                        )),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: TextField(
                        // maxLength: 10,
                        controller: email_ctr,
                        textAlign: TextAlign.start,
                        autocorrect: true,
                        style: GoogleFonts.lato(color: Colors.grey[700]),
                        textInputAction: TextInputAction.done,
                        decoration: new InputDecoration(
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            errorBorder: InputBorder.none,
                            disabledBorder: InputBorder.none,
                            contentPadding: EdgeInsets.only(
                                left: 10, bottom: 11, top: 11, right: 15),
                            hintText: "ex : exemple@gmail.com"),
                        onChanged: (v) {
                          setState(() {
                            usename_text = v;
                            reponseLogin = "";
                            //LoginRequest(usename_text,password_text);
                          });
                        },
                      ),
                    ),
                  ),
                ),

                //
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Mot de passe',
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Container(
                    decoration: new BoxDecoration(
                        color:
                            Colors.white, //new Color.fromRGBO(255, 0, 0, 0.0),
                        borderRadius: new BorderRadius.all(
                          Radius.circular(5.0),
                        )),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: TextField(
                        textAlign: TextAlign.start,
                        autocorrect: true,
                        controller: password,
                        style: GoogleFonts.lato(color: Colors.grey[700]),
                        textInputAction: TextInputAction.done,
                        obscureText: true,
                        obscuringCharacter: "*",
                        decoration: new InputDecoration(
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            errorBorder: InputBorder.none,
                            disabledBorder: InputBorder.none,
                            contentPadding: EdgeInsets.only(
                                left: 10, bottom: 11, top: 11, right: 15),
                            hintText: "Votre mot de passe"),
                      ),
                    ),
                  ),
                ),

                InkWell(
                  onTap: () {
                    String email = email_ctr.text;
                    final bool isValid = EmailValidator.validate(email);

                    if (isValid == false) {
                      print('Email is valid? ' + (isValid ? 'yes' : 'no'));
                      MessageToast m = MessageToast("Adresse email non valide !");
                      m.ShowMessage();
                    } else if (email.isEmpty) {
                      MessageToast m = MessageToast("Adresse email vide !");
                      m.ShowMessage();
                    } else if (password.text.isEmpty) {
                      MessageToast m = MessageToast("Mot de passe vide !");
                      m.ShowMessage();
                    } else {
                      setState(() {
                        LoginRequest(email_ctr.text, password.text);
                        _showDialogLoad(context);
                        startTimer();
                      });
                    }
                  },
                  child: Padding(
                    padding:
                        const EdgeInsets.only(left: 8.0, right: 8.0, top: 20.0),
                    child: Container(
                      decoration: new BoxDecoration(
                          color: Colors.blueGrey[
                              700], //new Color.fromRGBO(255, 0, 0, 0.0),
                          borderRadius: new BorderRadius.all(
                            Radius.circular(5.0),
                          )),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              'SE CONNECTER',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

               /* Padding(
                    padding: const EdgeInsets.only(top: 15.0),
                    child: InkWell(
                      onTap: () {
                        //Send_mail();
                        _showDialogCreerCompte(context);
                      },
                      child: Text(
                        'Créer compte',
                        style: TextStyle(color: Colors.white, fontSize: 15),
                      ),
                    )),*/
              ],
            ),
          ),

          /*Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [



              Padding(
                padding: const EdgeInsets.all(8.0),
                 
                  child: Container(
                    height: 250,

                    decoration: new BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: new BorderRadius.all(
                            Radius.circular(30.0),
                            )
                    ),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextField(
                            // maxLength: 10,
                            controller: email_ctr,
                            textAlign: TextAlign.start,
                            autocorrect: true,
                            style: GoogleFonts.lato(color: Colors.white),
                               textInputAction: TextInputAction.done,
                            decoration: InputDecoration(
                              //border: OutlineInputBorder(),
                              prefixIcon: Icon(Icons.email,color: Colors.blue,),
                              hintText: "Adresse email",
                              hintStyle: TextStyle(color: Colors.blue),
                              labelStyle: TextStyle(
                                color: Colors.grey,
                              ),
                              // prefixText: "Saisissez votre nom"
                            ),
                            onChanged: (v){
                              setState(() {
                                usename_text=v;
                                reponseLogin="";
                                //LoginRequest(usename_text,password_text);

                              });
                            },
                          ),
                        ),

                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextField(
                            // maxLength: 10,
                            textAlign: TextAlign.start,
                            autocorrect: true,
                            controller: password_ctrl,
                            style: GoogleFonts.lato(color: Colors.white),
                            textInputAction: TextInputAction.done,
                            obscureText: true,
                            obscuringCharacter: "*",
                            decoration: InputDecoration(
                              // border: OutlineInputBorder(),
                              // prefixIcon: Icon(Icons.lock),
                              prefixIcon: Icon(Icons.lock,color: Colors.blue,),

                              hintText: "Mot de passe",
                              hintStyle: TextStyle(color:Colors.blue),
                              labelStyle: TextStyle(
                                color: Colors.white,
                              ),
                              // prefixText: "Saisissez votre nom"
                            ),
                            onChanged: (v){
                              setState(() {
                                password_text=v;
                                reponseLogin="";
                              });
                            },
                          ),
                        ),

                        Center(
                          child:
                              Padding(
                                padding: const EdgeInsets.only(top:0.0),
                                child: FlatButton(onPressed: (){

                                  String email = usename_text;
                                  final bool isValid = EmailValidator.validate(email);

                                  if(isValid==false){
                                    print('Email is valid? ' + (isValid ? 'yes' : 'no'));
                                    Message m=Message("Adresse email non valide");
                                    m.ShowMessage();
                                  }
                                  else if(usename_text.isEmpty){
                                    Message m=Message("Utilisateur vide !");
                                    m.ShowMessage();
                                  }  if(password_text.isEmpty){
                                    Message m=Message("Mot de passe vide !");
                                    m.ShowMessage();
                                  }else{
                                    setState(() {
                                      LoginRequest(usename_text,password_text);
                                      _showDialogLoad(context);
                                      startTimer();
                                    });

                                  }
                                },
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(18.0),
                                        side: BorderSide(color: Colors.amber)
                                    ),
                                    color: Colors.amber,
                                    child: Text("Se Connecter",style: TextStyle(color: Colors.white),) ),

                              ),

                        ),

                        Center(
                          child: Padding(
                            padding: const EdgeInsets.only(top:0.0),
                            child: FlatButton(onPressed: (){
                              _showDialogCreerCompte(context);
                            },
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(18.0),
                                    side: BorderSide(color: Colors.blue)
                                ),
                                color: Colors.blue,
                                child: Text("Créer compte",style: TextStyle(color: Colors.white),) ),
                          ),
                        ),
                      ],
                    ),
                  ),

              ),
            ],
          )*/
        ],
      ),
      /*ListView(
        children: [
          _title(),
          Text_field()
        ],
      ) ,*/
    ));
  }
}
