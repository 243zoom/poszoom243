
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smartpos/class_dart/ClientFromServer.dart';
import 'package:smartpos/class_dart/ClientModel.dart';
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/class_dart/ReceveCommandeModel.dart';
import 'package:smartpos/class_dart/categorieModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/commons/narrow_app_bar.dart';
import 'package:smartpos/pages/Commande_client_page.dart';
import 'package:smartpos/pages/Liste_commande_page.dart';
import 'package:smartpos/pages/add_Client.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:intl/intl.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ClientPage extends StatefulWidget {
  @override
  _ClientPageState createState() => _ClientPageState();
}
class _ClientPageState extends State<ClientPage> {

  TextEditingController _client_controller=TextEditingController();
  TextEditingController sarch_ctrl=TextEditingController();
  ScrollController _scrollController =ScrollController();
    List<ProfileModel> profile_items = new List();
  String vvv;
  int  current_client;
  String _current_client_cmd;
  int   _current_id_cmd;
  @override
  String searchDialogSource;

  Color _c = Colors.redAccent;
  List _device = [
    "Choisir devise",
    "CDF",
    "USD"
  ];

  String statut_st="0";
  String cmd_log;
  String cmd_log2;

  final duplicateItems = List<ClientModel>.generate(10000, (i) =>ClientModel());
  var items = List<ClientModel>();


  List<DropdownMenuItem<String>> _dropDownMenuItems;
  String _currentDevice;
  List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = new List();
    for (String city in _device) {
      items.add(new DropdownMenuItem(value: city, child: new Text(city)));
    }
    return items;
  }
  void changedDropDownItem(String selectedCity) {
    setState(() {
      _currentDevice = selectedCity;
    });
  }
  void filterSearchResults(String query) {
    List<ClientModel> dummySearchList = List<ClientModel>();
    dummySearchList.addAll(duplicateItems);
    if(query.isNotEmpty) {
      List<ClientModel> dummyListData = List<ClientModel>();
      dummySearchList.forEach((item) {
        /*if(item.Client(query)) {
          dummyListData.add(item);
        }*/
      });
      setState(() {
        items.clear();
        items.addAll(dummyListData);
      });
      return;
    } else {
      setState(() {
        items.clear();
        items.addAll(duplicateItems);
      });
    }

  }
  /*
  void countPeople() async {
    int count = await DBProvider_new.db.getCountClient();
    setState(() => number = count);
  }
   */

  @override
  void initState() {
    _dropDownMenuItems = getDropDownMenuItems();
    _currentDevice = _dropDownMenuItems[0].value;
    //Load_Client();
    // TODO: implement initState
    super.initState();
   Load_Client();

   DBProvider_new.db.getInfos().then((notes) {
      setState(() {
        notes.forEach((note) {
          profile_items.add(ProfileModel.fromMap(note));
        });

      });
    });

  }
  //DBProvider_new.db.getAllClient()
  Future<List<ClientModel>> Load_Client() async {
    var data= await DBProvider_new.db.getAllClient();
    return data;
  }

  Set_Statut(int cl)async{
    var a=await DBProvider_new.db.get_statut_by_client(cl);
    setState(() {
      return statut_st=a;
    });
  }

  Verrifier_cmd(String client_pr)async{
    int  a=await DBProvider_new.db.Verifier_commande_by_Client(client_pr);
    setState(() {
      return cmd_log= a.toString();
    });
  }
  Verrifier_cmd2(String client_pr)async{
    int  a=await DBProvider_new.db.Verifier_commande_by_Client(client_pr);
    setState(() {
      return cmd_log2= a.toString();
    });
  }
  AddClienteDialog(BuildContext context) {
    DateTime now = DateTime.now();
    //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
    String formattedDate = DateFormat('d/m/y h:m:s').format(now);
    // set up the buttons
    Widget remindButton = FlatButton(
      child: Text("Remind me later"),
      onPressed:  () {},
    );
    Widget cancelButton = FlatButton(
      child: Text("Cancel"),
      onPressed:  () {},
    );
    Widget launchButton = FlatButton(
      child: Text("Ajouter"),
      onPressed:  () {
        String date_client="";
        if(_client_controller.text.toString().isEmpty){
          MessageToast message=MessageToast("Champ client vide !");
          message.ShowMessage();
          //print('empy value ');

        }else{
          ClientModel client=ClientModel(Client: _client_controller.text.toString(),date_client:formattedDate);
          DBProvider_new.db.newClient(client);

          setState(() {
            Load_Client();
           // countPeople();
            _client_controller.clear();
            Navigator.of(context).pop();

          });
        }


      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Nouveau client",style: TextStyle(
      ),),
      content: Container(
        child: TextFormField(
          controller: _client_controller,
          decoration: new InputDecoration(labelText: "Client",
             prefixIcon: Icon(Icons.person_add_alt_1,size: 17,)
          ),
        ),
      ),
      actions: [

        launchButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
  startTimer()async{

    var dur=Duration(seconds: 1);
    return Timer(dur,route);
  }

  route(){
    Navigator.of(context).pop();
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) => super.widget));
  }

  startTimerCmnd()async{

    var dur=Duration(seconds: 3);
    return Timer(dur,routeCmd);
  }

  routeCmd(){
     
    //Navigator.of(context).pop();
    if(cmd_log=="0"){

      Navigator.of(context).pop();
      MessageToast m=MessageToast("Aucune commande trouvée");
      m.ShowMessage();

    }else{
      // syncronisation de commande depuis le sever online

      Navigator.of(context).pop();
      print('comd '+cmd_log);
      Navigator.push( context, MaterialPageRoute( builder: (context) => List_Commande(current_client,statut_st)), ).then((value) => setState(() {

        // Load_Produit();
      }));
    }
  }
  //si la commande existe deja
  startTimerSiComd()async{

    var dur=Duration(seconds: 1);
    return Timer(dur,routeSiComd);
  }

  routeSiComd(){
    //Navigator.of(context).pop();
    if(cmd_log2=="0"){
      
      Navigator.of(context).pop();
      /*Message m=Message("Aucune commande trouvée on new comande" +cmd_log2);
      m.ShowMessage();*/
      /*Navigator.of(context).push(
          MaterialPageRoute(
              builder: (context)=>new_Commande(_current_client_cmd, _current_id_cmd)
          )
      );*/
 Navigator.pushReplacement(
                             context, MaterialPageRoute(builder: (context) => new_Commande(_current_client_cmd, _current_id_cmd)));

    }else{
      Navigator.of(context).pop();
      print('comd '+cmd_log2);
      /*Message m=Message("Commande deja effectuée,Veuillez inserer à nouveau le client" +cmd_log2);
      m.ShowMessage();
*/
      Fluttertoast.showToast(
          msg: "Commande $_current_client_cmd Terminé,Veuillez inserer à nouveau le client",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 3,
          backgroundColor: Colors.blue,
          textColor: Colors.white,
          fontSize: 16.0
      );

    }
  }
  List<ClientModel> list = List<ClientModel>();
  List<ClientModel> filteredList = List<ClientModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) => text.Client.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }



  Future _showDialogLoad(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      SpinKitCircle(
                        color: Colors.blue,
                        size: 40.0,
                      ),
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }

  Future _showDialogLoadCommande(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[

                      SpinKitCircle(
                        color: Colors.grey,
                        size: 20.0,
                      ),
                      SizedBox(width: 5,),
                      Text('Recherche commande',style: TextStyle(color: Colors.grey),)
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }

  Future _showDialogLoadVerification(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,

                    children: <Widget>[

                      SpinKitCircle(
                        color: Colors.grey,
                        size: 20.0,
                      ),
                      SizedBox(width: 5,),
                      Text('Verification',style: TextStyle(color: Colors.grey),)
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }
    Widget build(BuildContext context) {
      DateTime now = DateTime.now();
      //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
      String formattedDate = DateFormat('d/M/y h:m:s').format(now);

      Future _showDialogAddClient(context) async {

        return await showDialog<void>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SingleChildScrollView(
                            child: Column(

                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: client_ctr,
                                    decoration: new InputDecoration(labelText: "Client",
                                        border: OutlineInputBorder(
                                          borderSide: BorderSide(
                                            // color: Colors.red,
                                              width: 5.0),
                                        )

                                    ),
                                  ),
                                ),

                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: FlatButton(onPressed: (){

                                        setState(() {
                                          if(client_ctr.text.toString().isEmpty){
                                            MessageToast m=MessageToast('Veuillez saisir le client !');
                                            m.ShowMessage();
                                          }else{
                                            ClientModel client=ClientModel(Client: client_ctr.text.toString(),date_client:formattedDate);
                                            DBProvider_new.db.newClient(client);
                                            Navigator.of(context).pop();
                                            client_ctr.clear();
                                            Load_Client();
                                            startTimer();
                                            _showDialogLoad(context);

                                          }

                                        });


                                      },
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(18.0),
                                              side: BorderSide(color: Colors.blue[700])
                                          ),
                                          color: Colors.blue[700],
                                          child: Text("Ajouter client",style: TextStyle(color: Colors.white),) ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          //your code dropdown button here
                        ]),
                  );
                },
              ),

            );

          },
        );

      }


      Future _showDialogEditClient(context,String item,int id) async {

        return await showDialog<void>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SingleChildScrollView(
                            child: Column(

                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: client_ctr,
                                    decoration: new InputDecoration(labelText:item,
                                        border: OutlineInputBorder(
                                          borderSide: BorderSide(
                                            // color: Colors.red,
                                              width: 5.0),
                                        )

                                    ),
                                  ),
                                ),

                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: FlatButton(onPressed: (){
                                        setState(() {
                                          if(client_ctr.text.toString().isEmpty){
                                            MessageToast m=MessageToast('Veuillez saisir le client !');
                                            m.ShowMessage();
                                          }else{
                                            DBProvider_new.db.EditClient(client_ctr.text,id);
                                            Navigator.of(context).pop();
                                            client_ctr.clear();
                                            Load_Client();
                                            startTimer();
                                            _showDialogLoad(context);
                                          }
                                        });
                                      },
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(18.0),
                                              side: BorderSide(color: Colors.blue[700])
                                          ),
                                          color: Colors.blue[700],
                                          child: Text("Modifier client",style: TextStyle(color: Colors.white),) ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          //your code dropdown button here
                        ]),
                  );
                },
              ),

            );

          },
        );

      }




      AlertDialog(
        content: Container(
          color: _c,
          height: 20.0,
          width: 20.0,
          child: DropdownButton(
            value: _currentDevice,
            items: _dropDownMenuItems,
            // style: GoogleFonts.lato(color: Colors.grey[800]),
            onChanged: changedDropDownItem,
            elevation: 2,
          ),
        ),
        actions: <Widget>[
          FlatButton(
              child: Text('Switch'),
              onPressed: () =>
                  setState(() {
                    _c == Colors.redAccent
                        ? _c = Colors.blueAccent
                        : _c = Colors.redAccent;
                  }))
        ],
      );



      Future _showDialogDelete(context,int id) async {

        return await showDialog<void>(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[

                          Text('Voulez-vous confirmer la suppression ?',style: TextStyle(color: Colors.black),),
                          SizedBox(height: 11,),
                          Row(
                            children: [
                              InkWell(
                                onTap: (){ 
                                  Navigator.of(context).pop(); 
                                  DBProvider_new.db.deleteClient(id); 
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) => super.widget));
 
                                  setState(() { 

                                  });
                                },
                                child: Text('Oui',style: TextStyle(color: Colors.blue),),
                              ),
                              Spacer(),
                              InkWell(
                                onTap: (){
                                  Navigator.of(context).pop();
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) => super.widget));
                                },
                                child: Text('Non',style: TextStyle(color: Colors.red),),
                              )
                            ],
                          )
                          //your code dropdown button here
                        ]),
                  );
                },
              ),

            );

          },
        );

      }



      var now1 = DateTime.now();
      String d= DateFormat().format(now1);

      return Scaffold(


        body: Container(
          decoration: new BoxDecoration(
              image: new DecorationImage(
                image: new AssetImage("assets/images/bg3.png"),
                fit: BoxFit.cover,

              )
          ),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                color: Colors.black12.withOpacity(0.5),
                height: 80,

                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('$d',style: TextStyle(color: Colors.white),),
                    ),
                    Spacer(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text('Clients',style: TextStyle(color: Colors.white,fontSize: 16),),
                    ),


                  ],
                ),
              ),
              Container(
                height: 50,
                color: Colors.grey.withOpacity(0.6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 5.0,),
                    InkWell(
                      onTap: (){
                        Navigator.of(context).pop();
                      },
                      child:  Row(
                        children: [
                          Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                          Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                        ],
                      ),
                    ), 
                    Spacer(),
                    InkWell(
                      onTap: (){
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => Parametre(),
                          ),
                        );
                      },
                      child:  Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.settings,color: Colors.white,),
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.pushReplacement(context, MaterialPageRoute( 
                            builder:(context)=> LoginPage() 
                        )
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.logout,color: Colors.white,),
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        fetchStudents();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.restore_rounded,color: Colors.white,),
                      ),
                    )
                  ],
                ),
              ),

              Container(
                height: 60,
               color: Colors.white.withOpacity(0.5),
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: TextField(
                      controller: sarch_ctrl,
                      onChanged: (value) {
                        _filterList(value);
                      },
                      decoration: InputDecoration(
                          border: InputBorder.none,

                          prefixIcon: Icon(Icons.search),
                          hintText: "Recherche",
                          hintStyle: whiteSubHeadingTextStyle.copyWith(color: hintTextColor)),
                    ),
                  ),
                ),
                //color: Colors.black12.withOpacity(0.5),
              ),


              Expanded(

                  child: Container(
                    color: Colors.white.withOpacity(0.5),
                    child: FutureBuilder<List<ClientModel>>(

                        future: DBProvider_new.db.getAllClient(),

                        builder: (BuildContext context, AsyncSnapshot<List<ClientModel>> snapshot) {
                          if (snapshot.hasData) {
                            if (!doItJustOnce) {
                              //You should define a bool like (bool doItJustOnce = false;) on your state.
                              list = snapshot.data;
                              filteredList = list;
                              doItJustOnce = !doItJustOnce; //this line helps to do just once.
                            }

                            return GridView.builder(
                                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                                    maxCrossAxisExtent: 200,
                                    childAspectRatio: 4 / 4,
                                    crossAxisSpacing: 10,
                                    mainAxisSpacing: 2),
                                physics: const AlwaysScrollableScrollPhysics(),
                                shrinkWrap: true,
                                reverse: false,
                                controller: _scrollController,
                                itemCount: filteredList.length,

                                itemBuilder: (BuildContext ctx, index) {
                                  return AnimationConfiguration.staggeredList(
                                    position: index,
                                    duration: const Duration(milliseconds: 300),
                                    child: SlideAnimation(
                                      verticalOffset: 50.0,
                                      child: FadeInAnimation(
                                        child: Center(
                                          child: GestureDetector(
                                            onTap: (){
                                               print('me');
                                                                        Verrifier_cmd2(filteredList[index].id.toString());
                                                                        startTimerSiComd();
                                                                        _showDialogLoadVerification(context);
                                                                       setState(() {
                                                                         _current_client_cmd=filteredList[index].Client;
                                                                         _current_id_cmd=filteredList[index].id;
                                                                       });
                                            },
                                            child: 
                                            Container(
                                                width: 150,
                                                //height: double.infinity,
                                                child: Stack(

                                                  children: [
                                                    Container(
                                                      // semanticContainer: true,
                                                      // clipBehavior: Clip.antiAliasWithSaveLayer,
                                                        child:Center(
                                                          child: Padding(
                                                            padding: const EdgeInsets.only(top:0.0,right: 5.0,bottom: 90),
                                                            child: Icon(Icons.person,color: Colors.grey,size: 80,)
                                                          ),
                                                        )
                                                     // margin: EdgeInsets.all(10),
                                                    ),


                                                    Padding(
                                                      padding: const EdgeInsets.all(8.0),
                                                      child: Container(
                                                        width: 140,
                                                        height: 120,

                                                        //   color: Colors.blueGrey[900].withOpacity(0.5),
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.end,
                                                          children: [
                                                            Align(
                                                              alignment: Alignment(0.0,0.0),
                                                              child: Container(
                                                                height: 20,
                                                                //color: Colors.white,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                  children: [
                                                                   // SizedBox(width: 0,),

                                                                    Text(filteredList[index].Client.toString(),style: TextStyle(color: Colors.white,fontSize: 19)),

                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                            Align(
                                                              alignment: Alignment(0.0,1.4),
                                                              child: Container(
                                                                height: 30,
                                                                color: Colors.white,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                  children: [

                                                                    InkWell(
                                                                      onTap: (){
                                                                        _showDialogEditClient(context,filteredList[index].Client.toString(),filteredList[index].id);
                                                                      },
                                                                      child: Icon(Icons.edit,size: 20,color: Colors.blue,),
                                                                    ),

                                                                    Spacer(),
                                                                    // Text(filteredList[index].Client.toString()),
                                                                    InkWell(
                                                                      onTap: (){
                                                                        _showDialogDelete(context,filteredList[index].id);
                                                                      },
                                                                      child: Icon(Icons.delete,size: 20,color: Colors.deepOrange,),
                                                                    ),
                                                                    Spacer(),
                                                                    InkWell(
                                                                      onTap: (){
                                                                        fetchCommande(filteredList[index].Client,filteredList[index].id.toString());

                                                                        Load_Client();
                                                                        Set_Statut(filteredList[index].id);
                                                                        //Verrifier_cmd(filteredList[index].id.toString());
                                                                        Verrifier_cmd(filteredList[index].id.toString()); 
                                                                       
                                                                        setState(() {
                                                                          startTimerCmnd();
                                                                          _showDialogLoadCommande(context);

                                                                          current_client=filteredList[index].id;
                                                                          
                                                                        });

                                                                        //_showDialogLoadVerification(context,filteredList[index].id.toString(),filteredList[index].id);
                                                                      },
                                                                      child: Icon(Icons.shopping_cart,size: 20,color: Colors.blue[700],),
                                                                    ),
                                                                   // Spacer(),
                                                                    /*InkWell(
                                                                      onTap: (){
                                                                       

                                                                      //  _showDialogDelete(context,filteredList[index].id);
                                                                      },
                                                                      child: Icon(Icons.shopping_cart_rounded,size: 20,color: Colors.deepOrange,),
                                                                    ),*/
                                                                  ],
                                                                ),
                                                              ),
                                                            )
                                                          ],
                                                        ),
                                                        decoration: BoxDecoration(
                                                          //color: Colors.white,
                                                          color: Colors.blueGrey[900].withOpacity(0.5),
                                                          borderRadius: BorderRadius.all(
                                                            Radius.circular(15) ,

                                                          ),
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                )
                                            ),

                                          ),
                                        ),

                                        /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                      ),
                                    ),
                                  );
                                });

                          }
                          return Center(child: CircularProgressIndicator());
                        }),
                  )



              ),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.person_add),
          backgroundColor: Colors.blue[700],
          onPressed: (){
            //AddClienteDialog(context);
            Load_Client();
            _showDialogAddClient(context);
          /* Navigator.push( context, MaterialPageRoute( builder: (context) => New_Client()), ).then((value) => setState(() {
              Load_Client();
            }));
            */

          },
        ),
      );
    }
    // synchronisation de données
    Future<List<ClientFromServer>> fetchStudents() async {
 
    var url = 'http://apirobipos.zoom243.com/select_client.php'; 

    var data = {'resto': profile_items[0].email};

    var response = await http.post(url,body: json.encode(data)); 


    if (response.statusCode == 200) {

      final items = json.decode(response.body).cast<Map<String, dynamic>>();

      items.forEach((note){
        ClientModel clientModel=ClientModel(Client: note['client'],date_client:note['date_add']);
        DBProvider_new.db.newClient(clientModel);

        print('add');
                                            
                                           
      });
       Load_Client();
       startTimer();
       _showDialogLoad(context);

      /*List<ClientFromServer> studentList = items.map<ClientFromServer>((json) {
        return ClientFromServer.fromJson(json);
      }).toList();

      return studentList;
      */
      }
     else {
      throw Exception('Failed to load data from Server.');
    }
  }
   Future<List<ReceveCommandeModel>> fetchCommande(String client,String id_cl) async {
      var url = 'http://apirobipos.zoom243.com/select_commande.php';
 

    var data = {'client': client,'resto':profile_items[0].email};

    var response = await http.post(url,body: json.encode(data)); 
 

    if (response.statusCode == 200) {

      final items = json.decode(response.body).cast<Map<String, dynamic>>();

      items.forEach((note){
        CommandeModel cmd = CommandeModel(
                              Client_id: id_cl,
                              produit_id: note['produit'],
                              montant: note['prix'].toString(),
                              devise: note['devise'],
                              quantite: '1',
                              date_commande: note['date_add'],
                              statuts: "0",
                              view_client: note['client'],
                              view_produit: note['produit'],
                              total: note['prix'].toString(),
                              
                              );
                          DBProvider_new.db.newCommande(cmd);
      });

    /*List<ReceveCommandeModel> studentList = items.map<ReceveCommandeModel>((json) {
        return ReceveCommandeModel.fromJson(json);
      }).toList(); 
      return studentList;
    */
      }
     else {
      throw Exception('Failed to load data from Server.');
    }
  }
}
  