import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class StatistiquePage extends StatefulWidget {
  @override
  _StatistiquePageState createState() => _StatistiquePageState();
}

class _StatistiquePageState extends State<StatistiquePage> {
  
  @override

  int nombre_client;
  int nombre_commande;
  int nombre_vente;
  double doubleClient;
  double doubleCommande;
  double doubleVente;
  int total_cdf;
  int total_usd;
  int vente;
  DateTime currentDate = DateTime.now();
   DateTime currentDate2 = DateTime.now();

  String date_from="Date début";
  String date_to="Date fin";
  //get last day 

  final now = DateTime.now();


  List<charts.Series<Pollution, String>> _seriesData;
  List<charts.Series<Task, String>> _seriesPieData;
  List<charts.Series<Sales, int>> _seriesLineData;

  void nbre_client(String date_1,String date_2) async {
    
    int count = await DBProvider_new.db.Nombre_Client(date_1,date_2);
    int count_cmd = await DBProvider_new.db.Nombre_commande(date_1,date_2);
    int vente = await DBProvider_new.db.Nombre_Vente("2",date_1,date_2);
    int total = await DBProvider_new.db.getTotalCDF(date_1,date_2);
    int total_usd2 = await DBProvider_new.db.getTotalUSD(date_1,date_2);

    nombre_vente = vente;
    setState(() {
      nombre_client = count;
      nombre_commande = count_cmd;
      nombre_vente = vente;
      doubleClient = count.toDouble();
      doubleCommande = count_cmd.toDouble();
      doubleVente = vente.toDouble();
 
      if(nombre_client==null){
        nombre_client=0;
         nombre_client = count;
      }else{
         nombre_client = count;
      }

      if (total_cdf == null) {
        total_cdf = 0;
        total_cdf = total;
      } else {
        total_cdf = total;
      }
      nombre_vente = vente;
      print(' client ' + nombre_client.toString());
      print(' vente ' + nombre_vente.toString());
      print('Total ' + total.toString());

      if (total_usd == null) {
        print('0');
        //total_usd=0;
        total_usd = total_usd2;
        //print(total_usd);
      } else {
        total_usd = total_usd2;
        print('null');
      }

       _seriesData = List<charts.Series<Pollution, String>>();
      _seriesPieData = List<charts.Series<Task, String>>();
      _seriesLineData = List<charts.Series<Sales, int>>();
      _generateData(nombre_client);
    }); 
  }

  

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    final today = DateTime(now.year, now.month, now.day);
    String dateToday = DateFormat('dd/MM/yyyy').format(today);
    final yesterday = DateTime(now.year, now.month, now.day + 1);
    String Dateyesterday = DateFormat('dd/MM/yyyy').format(yesterday);

    setState(() {
      
    //print('tomorow '+Dateyesterday);
      nbre_client(dateToday,Dateyesterday);

      if(nombre_client==null){
        nombre_client=0;
          
      }else{
         nombre_client;
      }
      _seriesData = List<charts.Series<Pollution, String>>();
      _seriesPieData = List<charts.Series<Task, String>>();
      _seriesLineData = List<charts.Series<Sales, int>>();
 
      _generateData(nombre_client);
      print('Clll'+nombre_client.toString());
    });
  }

  List<CommandeModel> list = List<CommandeModel>();
  List<CommandeModel> filteredList = List<CommandeModel>();
  bool doItJustOnce = false;

  void _filterList(value) {
    setState(() {
      filteredList = list
          .where((text) =>
              text.view_client.toLowerCase().contains(value.toLowerCase()))
          .toList(); // I don't understand your Word list.
    });
  }


_generateData(int client) {
    var data1 = [
      new Pollution(2021, 'Client ', client),
      new Pollution(2021, 'Commande ', nombre_commande),
      new Pollution(2021, 'Vente', nombre_vente),
    ];
    /* var data2 = [
      new Pollution(1985, 'Client', 100),
      new Pollution(1980, 'Commande', 150),
      new Pollution(1985, 'Vente', 80),
    ];
    var data3 = [
      new Pollution(1985, 'Client', 200),
      new Pollution(1980, 'Commnande', 300),
      new Pollution(1985, 'Vente', 180),
    ];*/

    //double d=nombre_client.toDouble();
   // int intClient = 5;
   // double doubleClient = nombre_client.toDouble();
    var piedata = [

      new Task('Client', doubleClient, Color(0xff3366cc)),
      new Task('Commande', doubleCommande, Color(0xff990099)),
      new Task('Vente', doubleVente, Color(0xff109618)),
    /*  new Task('TV', 15.6, Color(0xfffdbe19)),
      new Task('Sleep', 19.2, Color(0xffff9900)),
      new Task('Other', 10.3, Color(0xffdc3912)),*/
    ];

    var linesalesdata = [
      new Sales(0, 45),
      new Sales(1, 56),
      new Sales(2, 55),
      new Sales(3, 60),
      new Sales(4, 61),
      new Sales(5, 70),
    ];
    var linesalesdata1 = [
      new Sales(0, 35),
      new Sales(1, 46),
      new Sales(2, 45),
      new Sales(3, 50),
      new Sales(4, 51),
      new Sales(5, 60),
    ];

    var linesalesdata2 = [
      new Sales(0, 20),
      new Sales(1, 24),
      new Sales(2, 25),
      new Sales(3, 40),
      new Sales(4, 45),
      new Sales(5, 60),
    ];

    _seriesData.add(
      charts.Series(
        domainFn: (Pollution pollution, _) => pollution.place,
        measureFn: (Pollution pollution, _) => pollution.quantity,
        id: '2017',
        data: data1,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Pollution pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xffff9900)),
      ),
    );

    /*_seriesData.add(
      charts.Series(
        domainFn: (Pollution pollution, _) => pollution.place,
        measureFn: (Pollution pollution, _) => pollution.quantity,
        id: '2018',
        data: data2,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Pollution pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xff109618)),
      ),
    );

    _seriesData.add(
      charts.Series(
        domainFn: (Pollution pollution, _) => pollution.place,
        measureFn: (Pollution pollution, _) => pollution.quantity,
        id: '2019',
        data: data3,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Pollution pollution, _) =>
            charts.ColorUtil.fromDartColor(Color(0xffff9900)),
      ),
    );*/

    _seriesPieData.add(
      charts.Series(
        domainFn: (Task task, _) => task.task,
        measureFn: (Task task, _) => task.taskvalue,
        colorFn: (Task task, _) =>
            charts.ColorUtil.fromDartColor(task.colorval),
        id: 'Air Pollution',
        data: piedata,
        labelAccessorFn: (Task row, _) => '${row.taskvalue}',
      ),
    );

    _seriesLineData.add(
      charts.Series(
        colorFn: (__, _) => charts.ColorUtil.fromDartColor(Color(0xff990099)),
        id: 'Air Pollution',
        data: linesalesdata,
        domainFn: (Sales sales, _) => sales.yearval,
        measureFn: (Sales sales, _) => sales.salesval,
      ),
    );
    _seriesLineData.add(
      charts.Series(
        colorFn: (__, _) => charts.ColorUtil.fromDartColor(Color(0xff109618)),
        id: 'Air Pollution',
        data: linesalesdata1,
        domainFn: (Sales sales, _) => sales.yearval,
        measureFn: (Sales sales, _) => sales.salesval,
      ),
    );
    _seriesLineData.add(
      charts.Series(
        colorFn: (__, _) => charts.ColorUtil.fromDartColor(Color(0xffff9900)),
        id: 'Air Pollution',
        data: linesalesdata2,
        domainFn: (Sales sales, _) => sales.yearval,
        measureFn: (Sales sales, _) => sales.salesval,
      ),
    );
  }

   Future<void> _selectDate2(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate2,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate2)
      setState(() {
        String formattedDate = DateFormat('dd/MM/yyyy').format(pickedDate);
        currentDate2 = pickedDate; 
        date_to=formattedDate.toString();
      });
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        String formattedDate = DateFormat('dd/MM/yyyy').format(pickedDate);
        currentDate = pickedDate; 
        date_from=formattedDate.toString();
      });
  }

  Widget build(BuildContext context) {
    var now = DateTime.now();
    String d = DateFormat().format(now);

    return Scaffold(
      body: Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
          image: new AssetImage("assets/images/bg3.png"),
          fit: BoxFit.cover,
        )),
        child: Column(
          children: [
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      '$d',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Statistiques',
                      style: TextStyle(color: Colors.white, fontSize: 19),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 19),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  ),
 
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  
                  children: [
                     GestureDetector(
                       onTap: (){
                         _selectDate(context);
                       },
                      
                        child: Row(
                          children: [
                            Icon(Icons.date_range,size: 16,color: Colors.grey[700],),
                            SizedBox(width: 8.0,),
                            Text('$date_from',style: TextStyle(color: Colors.grey[700]),),
                          ],
                        )
                      
                     ),
                      Spacer(), 
                     GestureDetector(
                       onTap: (){
                         _selectDate2(context);
                       }, 
                        child: Row(
                          children: [
                            Icon(Icons.date_range,size: 16,color: Colors.grey[700],),
                            SizedBox(width: 5.0,),
                            Text('$date_to',style: TextStyle(color: Colors.grey[700]),),
                          ],
                        )
                       
                     ),
                     Spacer(), 
                     
                      GestureDetector(
                        onTap:(){
                          //parsing data in parameters 
                          nbre_client(date_from,date_to);
                        },
                        child:Container(
                        
                        decoration: new BoxDecoration(
                           color: Colors.grey, //new Color.fromRGBO(255, 0, 0, 0.0),
                            borderRadius: new BorderRadius.all(
                              Radius.circular(5.0),
                            )),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text('Analyser',style: TextStyle(color: Colors.white,fontSize: 13),),
                        ),
                      ),
                      )
                  ],
                ),
              ),
            ),
          ),
          /*  SizedBox(height: 10.0,),
            InkWell(
              onTap: (){
                
              },
              child: Container(
              
               decoration: new BoxDecoration(
                        color: Colors.grey[400], //new Color.fromRGBO(255, 0, 0, 0.0),
                        borderRadius: new BorderRadius.all(
                          Radius.circular(5.0),
                        )),
              child:  Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Analyser',style: TextStyle(color: Colors.white),),
              ),
            ),
            ),*/
             
            Expanded(
                child: ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left:8.0,right: 8.0),
                  child: Container(
                    height: 120,
                    color: Colors.grey[100].withOpacity(0.5),
                    child: Stack(
                      children: [
                        Container(
                          height: 50,
                          color: Colors.brown[200],
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Evaluations',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 18),
                              )
                            ],
                          ),
                        ),
                        Align(
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Nombre de client',
                                  style: TextStyle(color: Colors.grey[800]),
                                ),
                              ),
                              Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(right: 13.0),
                                child: Text('$nombre_client'),
                              )
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment(0.0, 0.5),
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Montant encaissé CDF',
                                  style: TextStyle(color: Colors.grey[800]),
                                ),
                              ),
                              Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(right: 13.0),
                                child: total_cdf == null
                                   ? new Text('0')
                                 :  Text('$total_cdf'),
                                /*Text(''+total_cdf.toString()),*/
                              ),
                            ],
                          ),
                        ),
                        Align(
                          alignment: Alignment(0.0, 1.0),
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Montant encaissé USD',
                                  style: TextStyle(color: Colors.grey[800]),
                                ),
                              ),
                              Spacer(),
                              Padding(
                                padding: const EdgeInsets.only(right: 13.0),
                                child: total_usd == null
                                   ? new Text('0')
                                 :  Text('$total_usd'),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              Padding(
                  padding:
                      const EdgeInsets.only(left: 8.0, right: 8.0, top: 30.0),
                  child: Container(
                    height: 220,
                    color: Colors.grey[100].withOpacity(0.5),
                    child: Stack(
                      children: [
                        Container(
                          height: 50,
                          color: Colors.brown[200],
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Progressions',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 18),
                              )
                            ],
                          ),
                        ),
                         Padding(
                           padding: const EdgeInsets.only(top:35.0),
                           child: charts.BarChart(

                              _seriesData,
                              animate: true,
                              barGroupingType: charts.BarGroupingType.grouped,
                              //behaviors: [new charts.SeriesLegend()],
                              animationDuration: Duration(seconds: 2),
                            ),
                         ),

                        /*Align(
                            alignment: Alignment(0.0, 0.6),
                            child: Container(
                              height: 150,
                              child: Expanded(
                                child: charts.BarChart(
                                _seriesData,
                                animate: true,
                                barGroupingType: charts.BarGroupingType.grouped,
                                //behaviors: [new charts.SeriesLegend()],
                                animationDuration: Duration(seconds: 2),
                              ),
                              ),
                            )),*/
                      ],
                    ),
                  ),
                ),

                /*Padding(
                  padding:
                      const EdgeInsets.only(left: 8.0, right: 8.0, top: 30.0),
                  child: Container(
                    height: 220,
                    color: Colors.grey[100].withOpacity(0.5),
                    child: Stack(
                      children: [
                        Container(
                          height: 50,
                          color: Colors.brown[200],
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Meilleures ventes',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 18),
                              )
                            ],
                          ),
                        ),
                        /*Align(
                            alignment: Alignment(0.0, 0.6),
                            child: Container(
                              height: 150,
                              child: Expanded(
                                child: FutureBuilder<List<CommandeModel>>(
                                    future: DBProvider_new.db.getAllCommande(),
                                    builder: (BuildContext context,
                                        AsyncSnapshot<List<CommandeModel>>
                                            snapshot) {
                                      if (snapshot.hasData) {
                                        if (!doItJustOnce) {
                                          //You should define a bool like (bool doItJustOnce = false;) on your state.
                                          list = snapshot.data;
                                          filteredList = list;
                                          doItJustOnce =
                                              !doItJustOnce; //this line helps to do just once.
                                        }
                                        return ListView.builder(
                                            physics:
                                                const AlwaysScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            reverse: false,
                                            itemCount: filteredList.length,
                                            itemBuilder:
                                                (BuildContext ctx, index) {
                                              return AnimationConfiguration
                                                  .staggeredList(
                                                position: index,
                                                duration: const Duration(
                                                    milliseconds: 300),
                                                child: SlideAnimation(
                                                  verticalOffset: 50.0,
                                                  child: FadeInAnimation(
                                                      child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 8.0),
                                                          child: Container(
                                                            child: Row(
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets
                                                                          .only(
                                                                      top: 5.0),
                                                                  child: Text(filteredList[
                                                                          index]
                                                                      .view_produit),
                                                                ),
                                                                SizedBox(
                                                                  width: 5,
                                                                ),
                                                                Container(
                                                                  width: 20,
                                                                  height: 20,
                                                                  decoration: BoxDecoration(
                                                                      shape: BoxShape
                                                                          .circle,
                                                                      color: Colors
                                                                          .grey),
                                                                  child: Center(
                                                                    child: Text(
                                                                      filteredList[
                                                                              index]
                                                                          .quantite,
                                                                      style:
                                                                          whiteSubHeadingTextStyle,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ))
                                                      /*listChild(filteredList[index].Categorie, filteredList[index].ger),*/
                                                      ),
                                                ),
                                              );
                                            });
                                      }
                                      return Center(
                                          child: CircularProgressIndicator());
                                    }),
                              ),
                            )),*/
                      ],
                    ),
                  ),
                ),*/


                

                /* Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: new BoxDecoration(
                      color: Colors.blue,
                      //color: Colors.black.withOpacity(0.7),
                      borderRadius: new BorderRadius.all(
                        Radius.circular(10.0),
                      )
                  ),
                  child:Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text('Nombre de client : $nombre_client',style: TextStyle(color: Colors.white),),
                      ],
                    ),
                  ),
                ),
              ),*/
                /* Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: new BoxDecoration(
                      color: Colors.blue,
                      //color: Colors.black.withOpacity(0.7),
                      borderRadius: new BorderRadius.all(
                        Radius.circular(10.0),
                      )
                  ),
                  child:Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text('Montant encaissé CDF : $total_cdf',style: TextStyle(color: Colors.white),),

                      ],
                    ),
                  ),

                ),
              ),*/

                /* Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(

                  decoration: new BoxDecoration(
                      color: Colors.blue,
                      //color: Colors.black.withOpacity(0.7),
                      borderRadius: new BorderRadius.all(
                        Radius.circular(10.0),
                      )
                  ),
                  child:Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text('Montant encaissé USD : $total_usd',style: TextStyle(color: Colors.white),),
                      ],
                    ),
                  ),
                ),
              ),*/
              ],
            )),
          ],
        ),
      ),
    );
  }
}
class Pollution {
  String place;
  int year;
  int quantity;

  Pollution(this.year, this.place, this.quantity);
}

class Task {
  String task;
  double taskvalue;
  Color colorval;

  Task(this.task, this.taskvalue, this.colorval);
}

class Sales {
  int yearval;
  int salesval;

  Sales(this.yearval, this.salesval);
}
class Choice {
  const Choice({this.title, this.icon});

  final String title;
  final IconData icon;
}