import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/pages/LicencePage.dart';
import 'package:smartpos/pages/register_page.php.dart';
import 'package:smartpos/pages/tauxPage.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'infos_entreprisePage.dart';

class Parametre extends StatefulWidget {
  @override
  _ParametreState createState() => _ParametreState();
}

class _ParametreState extends State<Parametre> {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    String d = DateFormat().format(now);

    return Scaffold(
      body: Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
          image: new AssetImage("assets/images/bg3.png"),
          fit: BoxFit.cover,
        )),
        child: Column(
          children: [
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      '$d',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Parametres',
                      style: TextStyle(color: Colors.white, fontSize: 19),
                    ),
                  ),

                  /* Padding(
                    padding: const EdgeInsets.only(right:15.0),
                    child: Container(

                      child: InkWell(
                        onTap: (){
                          Navigator.of(context).pop();
                        },
                        child: Icon(Icons.keyboard_backspace_outlined,color: Colors.white,),
                      ),
                      decoration: BoxDecoration(
                        //color: Colors.white,
                        color: Colors.blueGrey[900].withOpacity(0.5),
                        borderRadius: BorderRadius.all(
                          Radius.circular(15) ,

                        ),
                      ),
                    ),
                  )*/
                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.7),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 19),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  )
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                
                decoration: new BoxDecoration(
                  color: Colors.white.withOpacity(0.5), //new Color.fromRGBO(255, 0, 0, 0.0),
                    borderRadius: new BorderRadius.all(
                       Radius.circular(5.0),
                       )
                  ),
                child: Column(children: [
                  InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => InfosPage(),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(
                      top: 2,
                      right: 16,
                      left: 16,
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.info_outlined,
                          color: Colors.grey,
                          size: 35,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text('Infos entreprise')
                      ],
                    ),
                  )),

                  Divider(),
            InkWell(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => TauxPage(),
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.only(top: 2, right: 16, left: 16),
                  child: Row(
                    children: [
                      Icon(
                        Icons.monetization_on,
                        color: Colors.grey,
                        size: 35,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text('Taux du jour')
                    ],
                  ),
                )),
            Divider(),
            InkWell(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => LicencePage(),
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.only(top: 2, right: 16, left: 16),
                  child: Row(
                    children: [
                      Icon(
                        Icons.lock,
                        color: Colors.grey,
                        size: 35,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text('Ma licence')
                    ],
                  ),
                )),
            Divider(),
            InkWell(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => RegisterPage(),
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.only(top: 2, right: 16, left: 16),
                  child: Row(
                    children: [
                      Icon(
                        Icons.person_pin,
                        color: Colors.grey,
                        size: 35,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text('Gestionnaire des comptes')
                    ],
                  ),
                )),
            Divider(),
          InkWell(
                onTap: () {
                  /* Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => RegisterPage(),

                    ),
                  );*/
                },
                child: Padding(
                  padding: const EdgeInsets.only(top: 2, right: 16, left: 16),
                  child: Row(
                    children: [
                      Icon(
                        Icons.restore_from_trash_rounded,
                        color: Colors.grey,
                        size: 35,
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text('Corbeille')
                    ],
                  ),
                )),
                ],),
              ),
            ),

            
            
            
            
            
          ],
        ),
      ),
    );
  }
}
