import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:searchable_dropdown/searchable_dropdown.dart';
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/pages/Appercu_facture.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/client_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/utils/Database.dart';
import 'package:intl/intl.dart';

String client;
int id_client;

class new_Commande extends StatefulWidget {
  new_Commande(String client1, int id) {
    client = client1;
    id_client = id;
  }
  @override
  _new_CommandeState createState() => _new_CommandeState();
}

class _new_CommandeState extends State<new_Commande> {
  String reponseLogin;
  String m;
  TextEditingController nombre_produit = TextEditingController();
  String total_set = "";
  String prix;
  String _currentProduit = "Produit";

  int id_produit = 0;
  List<DropdownMenuItem<String>> _dropDownMenuItems;
  String _currentDevice;
  List _device = ["Choisir devise", "CDF", "USD"];
  int stock_produit = 0;

  String devise;

  List<ProduitModel> produit_items = new List();
  ProduitModel produit;
   String id;
  //List<VagasDisponivei> _vagasDisponiveis;

  List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = new List();
    for (String city in _device) {
      items.add(new DropdownMenuItem(value: city, child: new Text(city)));
    }
    return items;
  }

  void changedDropDownItem(String selectedCity) {
    setState(() {
      _currentDevice = selectedCity;
    });
  }

  /*void Prix() async {
    String count =
        await DBProvider_new.db.getPrix_produit(id.toString());
    setState(() => prix = count);
  }*/

  void Set_it_update_produit(id_p, int st) async {
    var a = await DBProvider_new.db.Stock_set(id_p, st);
    return a;
  }

  /*void verification_commande() async{
    int si=await DBProvider_new.db.Verifier_commande();
    setState(() {
      reponseLogin=si.toString();
    });
  }*/

  startTimer() async {
    var dur = Duration(seconds: 3);
    return Timer(dur, route);
  }

  route() {
    print('Sucess ');
    //
    
    //facture
    Navigator.of(context).pop();
    nombre_produit.clear();
     _showDialogCommandeTerminated(context);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    

    DBProvider_new.db.getProduit().then((notes) {
      setState(() {
        notes.forEach((note) {
          produit_items.add(ProduitModel.fromMap(note));
        });
      });
    });

     
  }

  Future _showDialogCommandeTerminated(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                         /*Center(
                           child: Image(
                             image: AssetImage("assets/images/icon.png"),
                             height: 30,
                             width: 30,
                           ),
                         ),
                         SizedBox(height:5.0,),*/
                        Text("Produit ajouté au pagner",style: TextStyle(color: Colors.blue[700],fontSize: 15),),
                            
                        SizedBox(height:5.0,),
                         Text("Voulez-vous continuer ?",style: TextStyle(color: Colors.grey[700],fontSize: 15),),
                        SizedBox(height:5.0,),
                        Divider(),
                         Row(children: [
                           InkWell(
                             onTap: (){
                                Navigator.of(context).pop();
                                   Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (BuildContext context) => super.widget));
                             },
                            child:   Text('Oui',style: TextStyle(color: Colors.blue[700]),),
                                                    ),
                           Spacer(),
                          
                          InkWell(
                            onTap: (){
                              Navigator.of(context).pop();
                              Navigator.pushReplacement(
                             context, MaterialPageRoute(builder: (context) => ClientPage()));
                            },
                            child:Text('Non',style: TextStyle(color: Colors.blue[700]),),
                                                    
                          ),
                               ],)
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }

  @override
  Widget build(BuildContext context) {

    //if commande is terminated

  
    //end if


    Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.blue,
                          size: 35.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }

    var now = DateTime.now();
    String d = DateFormat().format(now);

    return Scaffold(
        body: Container(
      decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),

      child: Column(
        children: [
          Container(
            color: Colors.black12.withOpacity(0.5),
            height: 80,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    '$d',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'Client $client',
                    style: TextStyle(color: Colors.white, fontSize: 15),
                  ),
                ),
               /* Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    child: InkWell(
                      onTap: () {
                        
                        //Navigator.of(context).pop();
                      },
                      child: Icon(
                        Icons.keyboard_backspace_outlined,
                        color: Colors.white,
                      ),
                    ),
                    decoration: BoxDecoration(
                      //color: Colors.white,
                      color: Colors.blueGrey[900].withOpacity(0.5),
                      borderRadius: BorderRadius.all(
                        Radius.circular(15),
                      ),
                    ),
                  ),
                )*/
              ],
            ),
          ),

     Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                     
                      //Navigator.of(context).pop();
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => ClientPage()));
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 19),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  ),
 
                ],
              ),
            ),


          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: []),
              child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SearchableDropdown.single(
                        items: produit_items.map((e) {
                          return DropdownMenuItem<ProduitModel>(
                            child: Text(e.Produit),
                            value: e,
                          );
                        }).toList(),
                        hint: "Selectionner un produit",
                        searchHint: "Selectionner un produit",
                        onChanged: (value) {
                          setState(() {
                            //devise=value.device;
                            // montant=value.prix;
                            produit = value;
                            devise = produit.devise;
                            prix=produit.prix.toString();
                            _currentProduit = produit.Produit;
                            print('device ' + devise);
                            print('Pr ' + produit.prix);
                          });
                        },
                        isExpanded: true,
                      )
                    ],
                  )),
            ),
          ),
          SizedBox(
            height: 9,
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              child: TextField(
                onChanged: (v) {
                 // Prix();
                  // var prix_convert = int.parse(prix);
                  // var  prix_from_nombre=int.parse(nombre_produit.text);
                  
                  setState(() {
                    
                    // int x =prix_convert*prix_from_nombre;
                    //total_set="$x";
                    // print(x);
                    print("prix "+prix.toString());
                    
                  });
                },
                controller: nombre_produit,
                keyboardType: TextInputType.text,
                inputFormatters: <TextInputFormatter>[
                  WhitelistingTextInputFormatter.digitsOnly
                ],
                decoration: new InputDecoration(
                    labelText: "Quantité",
                    border: OutlineInputBorder(
                      borderSide: BorderSide(
                          // color: Colors.red,
                          width: 5.0),
                    )),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: FlatButton(
                    onPressed: () {

                    

                      String n_produit = "";
                      n_produit = nombre_produit.text.toString(); 
                      if (n_produit.isEmpty) {
                        MessageToast m = MessageToast("Saisir la quantité svp");
                        m.ShowMessage();
                      }else if(produit==null){
                                   MessageToast m=MessageToast('Veuillez choisir le produit ');
                                   m.ShowMessage();
                       }
                      
                      if (nombre_produit.text.isEmpty) {
                          MessageToast m = MessageToast("Indiquer la quantité svp");
                          m.ShowMessage();
                        } 
                         else {
                           
                           int nbr = int.parse(n_produit.toString());
                          //  int rest_stock=stock_produit-nbr;
                          int prix_t = int.parse(prix);
                          int prix_gen = prix_t * nbr;

                          DateTime now = DateTime.now();
                          //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
                          String formattedDate =
                              DateFormat('d/M/y h:m:s').format(now);
                          CommandeModel cmd = CommandeModel(
                              Client_id: id_client.toString(),
                              produit_id: produit.id.toString(),
                              montant: prix.toString(),
                              devise: devise,
                              quantite: nombre_produit.text.toString(),
                              date_commande: formattedDate,
                              statuts: "0",
                              view_client: client,
                              view_produit: _currentProduit.toString(),
                              total: prix_gen.toString(),
                              
                              );
                          DBProvider_new.db.newCommande(cmd);
                          //Set_it_update_produit(id_produit,rest_stock);
                          // print('rest is '+rest_stock.toString());
                          print('total is comd ' + prix_gen.toString());
                          _showDialogLoad(context);
                          //verification_commande();
                          startTimer();
                          setState(() {
                            //stock_produit=rest_stock;
                          });
                        }
                      }
                    ,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.blue[700])),
                    color: Colors.blue[700],
                    child: Text(
                      "Passer la commande",
                      style: TextStyle(color: Colors.white),
                    )),
              ),
            ],
          ),
        ],
      ),
    ));
  }
}
