import 'package:flutter/material.dart';
import 'package:smartpos/class_dart/ClientModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/utils/Database.dart';
class New_Client extends StatefulWidget {
  @override
  _New_ClientState createState() => _New_ClientState();
}
TextEditingController client_ctr=TextEditingController();
class _New_ClientState extends State<New_Client> {

  // set up the buttons
  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    //String formattedDate = DateFormat('kk:mm:ss \n EEE d MMM').format(now);
    String formattedDate = DateFormat('d/m/y h:m:s').format(now);
    return Scaffold(
      appBar: AppBar(
        title: Text('Ajout Client'),

      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextFormField(
                controller: client_ctr,
                decoration: new InputDecoration(labelText: "Nom du client",
                    border: OutlineInputBorder(
                      borderSide: BorderSide(
                        // color: Colors.red,
                          width: 5.0),
                    )

                ),
              ),
            ),

            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FlatButton(onPressed: (){

                    if(client_ctr.text.toString().isEmpty){
                      MessageToast m=MessageToast('Veuillez saisir la categorie !');
                      m.ShowMessage();
                    }else{
                      ClientModel client=ClientModel(Client: client_ctr.text.toString(),date_client:formattedDate);
                      DBProvider_new.db.newClient(client);
                      Navigator.of(context).pop();
                      client_ctr.clear();

                      setState(() {
                        DBProvider_new.db.getAllProduit();
                      });

                    }
                  },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                          side: BorderSide(color: Colors.blueAccent)
                      ),
                      color: Colors.blueAccent,
                      child: Text("Ajouter client",style: TextStyle(color: Colors.white),) ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
