import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
 
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart'; 
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:searchable_dropdown/searchable_dropdown.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/class_dart/categorieModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/class_dart/s_categorieModel.dart'; 
import 'package:smartpos/class_dart/tauxModel.dart';
import 'package:smartpos/pages/modifier_produit_page.dart';
import 'package:smartpos/pages/produit_page.dart';  
import 'package:smartpos/utils/Database.dart';

import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'dart:async';
import 'package:barcode_scan/barcode_scan.dart';
 

class Add_produit extends StatefulWidget {
  @override
  _Add_produitState createState() => _Add_produitState();
}





class _Add_produitState extends State<Add_produit> {

  TextEditingController stock_ctr = TextEditingController();
  TextEditingController _produit = TextEditingController();
  TextEditingController _prix = TextEditingController();

  List _device = ["Devise", "CDF", "USD"];
  File imageFile;

  Uint8List _bytesImage;
  String base64Image;
  List<DropdownMenuItem<String>> _dropDownMenuItems;
  String _currentDevice;
  String _currentCategorieModel = "";

  String imagePath = "";
  String barcode = "";
  String qr_code="";

  SubCategorieModel subCategorie; 
  List<SubCategorieModel> sous_items = new List();  
  List<CategorieModel> categorie_items = new List();  
  List<TauxModel> taux_items = new List();
  CategorieModel categorie;
  bool _enabled = false;
  int id_categorie=0; 
  String type_categorie="";
  
  


  @override
  void initState() {
    // _enabled = !_enabled;
    _dropDownMenuItems = getDropDownMenuItems();
    _currentDevice = _dropDownMenuItems[0].value;
    // TODO: implement initState
    super.initState();
    DBProvider_new.db.getTaux().then((notes) {
      setState(() { 
        notes.forEach((note) {
          taux_items.add(TauxModel.fromMap(note));
        });
      });
    });
    DBProvider_new.db.getCategorie().then((notes) {
      setState(() {
        notes.forEach((note) {
          categorie_items.add(CategorieModel.fromMap(note));
        });
      });
    });

    LoadSuCat(0);
     super.initState();
  }
 

  LoadSuCat(int id){
    DBProvider_new.db.getAllSousCategorieByID(id).then((notes) {
      setState(() {
        notes.forEach((note) {
          sous_items.add(SubCategorieModel.fromMap(note.toMap()));
        });
      });
    });
  }

  List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = new List();
    for (String city in _device) {
      items.add(new DropdownMenuItem(value: city, child: new Text(city)));
    }
    return items;
  }

  void changedDropDownItem(String selectedCity) {
    setState(() {
      _currentDevice = selectedCity;
    });
  }

  Future<void> _showSelectionDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text("From where do you want to take the photo?"),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    GestureDetector(
                      child: Text("Gallery"),
                      onTap: () {
                        _openGallery(context);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text("Camera"),
                      onTap: () {
                        // _openCamera(context);
                        getImageFromCamera();
                      },
                    )
                  ],
                ),
              ));
        });
  }

  Future getImageFromCamera() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    List<int> imageBytes = image.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + image.path);
    imagePath = image.path;

    _bytesImage = Base64Decoder().convert(base64Image);
    setState(() {
      imagePath = image.path;
      imageFile = image;
      DBProvider_new.db.getAllCategorie();
      Navigator.of(context).pop();
    });
  }

  void _openGallery(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.gallery);
    List<int> imageBytes = picture.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    //  img= Image.memory(base64Decode(base64Image));
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + picture.path);
    imagePath = picture.path;
    this.setState(() {
      imagePath = picture.path;
      imageFile = picture;
      Navigator.of(context).pop();
    });
    // Navigator.of(context).pop();
  }

  _setImageView() {
    if (imageFile != null) {
      return Image.file(imageFile);
    } else {
      // return Text("Please select an image");

      return Icon(
        Icons.image,
        color: Colors.white,
        size: 30,
      );
    }
  }

  startTimer() async {
    var dur = Duration(seconds: 1);
    return Timer(dur, route);
  }

  route() {
    Navigator.of(context).pop();
    // Navigator.of(context).pop();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => ProduitPage()));
  }

  startTimerSubCategorie() async {
    var dur = Duration(seconds: 1);
    return Timer(dur, Subroute);
  }
  Subroute() {
    Navigator.of(context).pop();
    _onWillPop();
    // Navigator.of(context).pop();

  }
  Future<bool> _onWillPop() async {
    return (await showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        title: new Text("Categorie $categorie"),
        content: new Text("Voulez vous choisir une sous categorie ?"),
        actions: <Widget>[
          new FlatButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: new Text('Non'),
          ),
          new FlatButton(
            onPressed: (){
              Navigator.of(context).pop();
              LoadSuCat(id_categorie);
              _showDialogSubCategorieList(context);
            },

            child: new Text('Oui'),
          ),
        ],
      ),
    )) ?? false;
  }

  Future _showDialogSubCategorieList(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Selectionner une sous categorie',style: TextStyle(fontSize: 15,color: Colors.grey[700]),),
                      Divider(),

                      //your code dropdown button here
                    ]),
              );
            },
          ),
        );
      },
    );
  }
bool isNumericUsingRegularExpression(String string) {
  final numericRegex = 
    RegExp(r'^-?(([0-9]*)|(([0-9]*)\.([0-9]*)))$');

  return numericRegex.hasMatch(string);
}
  @override
  Widget build(BuildContext context) {

    Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.blue,
                          size: 30.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }

    Future _showDialogSubCategorie(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.grey,
                          size: 30.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }


    var now = DateTime.now();
    String d = DateFormat().format(now);

    return Scaffold(
      body: Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
          //crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      '$d',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Ajout produits',
                      style: TextStyle(color: Colors.white, fontSize: 19),
                    ),
                  ),

                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                      //Navigator.of(context).pop();
                       Navigator.pushReplacement(
               context, MaterialPageRoute(builder: (context) => ProduitPage()));
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  )
                ],
              ),
            ),
              Expanded(
                child: ListView(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        
                        decoration: BoxDecoration(
                        //color: Colors.white,
                       color: Colors.white.withOpacity(0.7),
                        borderRadius: BorderRadius.all(
                          Radius.circular(5) ,

                        ),
                        ),
                        child: Column(
                          children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('Taux du jour : 1 USD ' + taux_items[0].usd +' CDF'),
                                  ),
                                /*  Spacer(),
                                  Text('Taux CDF ' + taux_items[0].cdf),*/
                                ],
                              ),
                              Divider(),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: TextFormField(
                                controller: _produit,
                                decoration: new InputDecoration(
                                    labelText: "Produit",
                                    border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          // color: Colors.red,
                                          width: 5.0),
                                    )),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: TextFormField(
                                controller: _prix,
                                keyboardType: TextInputType.text,
                                decoration: new InputDecoration(
                                    labelText: "Prix",
                                    border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          //color: Colors.red,
                                          width: 5.0),
                                    )),
                              ),
                            ),

                             Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: DropdownButton(
                                    value: _currentDevice,
                                    items: _dropDownMenuItems,
                                    // style: GoogleFonts.lato(color: Colors.grey[800]),
                                    onChanged: changedDropDownItem,

                                    elevation: 2,
                                    style: TextStyle(color: Colors.black54),
                                    underline: Container(
                                      height: 2,
                                    ),
                                  ),
                                ),
                              ],
                            ),

                             Padding(
                               padding: const EdgeInsets.all(8.0),
                               child: GestureDetector(
                                 onTap: 
                                   barcodeScanning
                                 ,
                                 child:  Row(
                                    
                                   children: [
                                     Image(image: AssetImage('assets/images/bar_code.png'),width: 40,),
                                     Text('$barcode'),
                                   ],
                                 ),
                               ),
                             ),

                             Padding(
                               padding: const EdgeInsets.all(8.0),
                               child: GestureDetector(
                                 onTap: 
                                   QrcodeScanning
                                 ,
                                 child:  Row(
                                    
                                   children: [
                                     Icon(Icons.qr_code_scanner,size: 40,),
                                     Text('$qr_code'),
                                   ],
                                 ),
                               ),
                             ),
/*Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Row(
                                children: [
                                 InkWell(
                                   onTap: barcodeScanning,
                                   child:  Flexible(child:Image(image: AssetImage('assets/images/bar_code.png'),width: 40,)),
                                 ),
                                  SizedBox(width: 10.0,),
                                   
                                 Flexible(child:Text('$barcode'),)
                                  
                                ],
                              ),
                            ),*/
                             /*Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Row(
                                children: [
                                  InkWell(
                                    onTap:QrcodeScanning,
                                    child: Flexible(child:Icon(Icons.qr_code_scanner,size: 40,)),
                                  ),
                                  SizedBox(width: 10.0,),
                                   
                                 Flexible(child:Text('$qr_code'),)
                                  
                                ],
                              ),
                            ),*/
                            
                           
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(

                                decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.8),
                                    borderRadius: BorderRadius.circular(5),
                                    boxShadow: []
                                ),
                                child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        SearchableDropdown.single(
                                          items: categorie_items.map((item) {
                                            return DropdownMenuItem<CategorieModel>(
                                              child: Text(item.Categorie),
                                              value: item,
                                            );
                                          }).toList(),
                                          isCaseSensitiveSearch: true,
                                          value: categorie,
                                          hint: "Selectionner une categorie",
                                          searchHint: "Selectionner une categorie",
                                          onChanged: (value) {
                                            setState(() {
                                              categorie = value;
                                              type_categorie="cat";
                                              //refresh 
                                              LoadSuCat(categorie.id); 
                                              //show popup for subcategorie
                                             // _showDialogSubCategorie(context);
                                              //startTimerSubCategorie();
                                              //_currentCategorieModel = value;
                                              print('cat ' + categorie.id.toString());
                                              id_categorie=categorie.id;
                                            });
                                          },
                                          isExpanded: true,
                                        )
                                      ],
                                    )),
                              ),
                            ),

                            Padding(
                              padding: const EdgeInsets.only(left:8.0,right: 8.0,top: 5.0),
                              child: Container(

                                decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.8),
                                    borderRadius: BorderRadius.circular(5),
                                    boxShadow: []),
                                child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        SearchableDropdown.single(
                                          items: sous_items.map((item) {
                                            return DropdownMenuItem<SubCategorieModel>(
                                              child: Text(item.subcategorie),
                                              value: item,
                                            );
                                          }).toList(),
                                          isCaseSensitiveSearch: true,
                                          value: subCategorie,
                                          hint: "Sous categorie",
                                          searchHint: "",
                                          onChanged: (value) {
                                            setState(() {
                                              type_categorie="sub";
                                              //id_categorie=subCategorie.id;
                                              subCategorie=value;
                                              //categorie = value;
                                              //_currentCategorieModel = value;
                                              // print('cat ' + categorie.Categorie);
                                            });
                                          },
                                          isExpanded: true,
                                        )
                                      ],
                                    )),
                              ),
                            ),
 
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: FlatButton(
                                      onPressed: () {
                                        _showSelectionDialog(context);
                                      },
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(18.0),
                                          side: BorderSide(color: Colors.blue[700])),
                                      color: Colors.blue[700],
                                      child: Text(
                                        "Choisir l'image du produit",
                                        style: TextStyle(color: Colors.white),
                                      )),
                                ),
                              ],
                            ),
                            
                            InkWell(
                              onTap: (){
                                 _showSelectionDialog(context);
                                  
                              },
                              child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 90,
                                      height: 80,
                                      color: Colors.grey,
                                      child: _setImageView(),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: FlatButton(
                                      onPressed: () {
                                        // _showSelectionDialog(context);
                                        if (_produit.text.toString().isEmpty) {
                                          print('champ produit vide !');
                                          MessageToast m = MessageToast('champ produit vide!');
                                          m.ShowMessage();
                                        } else if (_prix.text.toString().isEmpty) {
                                          print('champ prix vide');
                                          MessageToast m = MessageToast('champ prix vide !');
                                          m.ShowMessage();
                                        } else if (categorie==null) {
                                          MessageToast m = MessageToast('Categorie vide !');
                                          m.ShowMessage();
                                        }
                                        else if (base64Image == null) {
                                          MessageToast m =
                                              MessageToast('l\'image du produit vide !');
                                          m.ShowMessage();
                                        } else if (_currentDevice == "Devise") {
                                          MessageToast m =
                                              MessageToast('Selectionnez la devise !');
                                          m.ShowMessage();
                                        } else if(isNumericUsingRegularExpression(_prix.text)==false){
                                           MessageToast m =
                                              MessageToast('Prix non valide !');
                                          m.ShowMessage();
                                        }
                                        
                                        else {
                                          
                                          ProduitModel produit_m = ProduitModel(
                                              Produit: _produit.text.toString(),
                                              Categorie:id_categorie.toString(),
                                              image: imagePath,
                                              prix: _prix.text.toString(),
                                              devise: _currentDevice.toString(),type_categorie: type_categorie,bar_code: barcode,qr_code: qr_code);
                                          DBProvider_new.db.newProduit(produit_m);
                                         
                                          print(
                                              'sucess  cat $_currentCategorieModel and device $_currentDevice');
                                          //Navigator.of(context).pop();
                                          _produit.clear();
                                          _prix.clear();
                                          stock_ctr.clear();
                                          _currentCategorieModel = "";
                                          startTimer();
                                          _showDialogLoad(context);
                                            
                                        }
                                      },
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(18.0),
                                          side: BorderSide(color: Colors.blue[700])),
                                      color: Colors.blue[700],
                                      child: Text(
                                        "Ajouter le produit",
                                        style: TextStyle(color: Colors.white),
                                      )),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            
          ],
        ),
      ),
    );
  }
  // all my object
  /* Future barcodeScanning() async {
    try {
      String barcode = (await BarcodeScanner.scan()) as String;

      setState(() => this.barcode = barcode.toString());
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          this.barcode = 'No camera permission!';
        });
      } else {
        setState(() => this.barcode = 'Unknown error: $e');
      }
    } on FormatException {
      setState(() => this.barcode =
      'Nothing captured.');
    } catch (e) {
      setState(() => this.barcode = 'Unknown error: $e');
    }
  }
*/
   Future barcodeScanning() async {
    try {
      ScanResult qrScanResult = await BarcodeScanner.scan();
      String qrResult = qrScanResult.rawContent;
      setState(() {
        barcode = qrResult;
      });
    } on PlatformException catch (ex) {
      if (ex.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          barcode = "Camera was denied";
        });
      } else {
        setState(() {
          barcode = "Unknown Error $ex";
        });
      }
    } on FormatException {
      setState(() {
        barcode = "You pressed the back button before scanning anything";
      });
    } catch (ex) {
      setState(() {
        barcode = "Unknown Error $ex";
      });
    }
  }

 /* Future QrcodeScanning() async {
    try {
      String barcode = (await BarcodeScanner.scan()) as String;
      setState(() => this.qr_code = barcode);
    } on PlatformException catch (e) {
      if (e.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          this.qr_code = 'No camera permission!';
        });
      } else {
        setState(() => this.qr_code = 'Unknown error: $e');
      }
    } on FormatException {
      setState(() => this.qr_code =
      'Nothing captured.');
    } catch (e) {
      setState(() => this.qr_code = 'Unknown error: $e');
    }
  }*/

     Future QrcodeScanning() async {
    try {
      ScanResult qrScanResult = await BarcodeScanner.scan();
      String qrResult = qrScanResult.rawContent;
      setState(() {
        qr_code = qrResult;
      });
    } on PlatformException catch (ex) {
      if (ex.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          qr_code = "Camera was denied";
        });
      } else {
        setState(() {
          qr_code = "Unknown Error $ex";
        });
      }
    } on FormatException {
      setState(() {
        qr_code = "You pressed the back button before scanning anything";
      });
    } catch (ex) {
      setState(() {
        qr_code = "Unknown Error $ex";
      });
    }
  }
}
