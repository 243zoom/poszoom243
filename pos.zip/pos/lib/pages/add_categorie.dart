import 'package:flutter/material.dart';
import 'package:smartpos/class_dart/categorieModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/utils/Database.dart';

class New_Categorie extends StatefulWidget {
  @override
  _New_CategorieState createState() => _New_CategorieState();
}

TextEditingController categorie_text=TextEditingController();
class _New_CategorieState extends State<New_Categorie> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ajout categorie'),

      ),

      body: SingleChildScrollView(
        child: Column(

          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextFormField(
                controller: categorie_text,
                decoration: new InputDecoration(labelText: "Nom categorie",
                    border: OutlineInputBorder(
                      borderSide: BorderSide(
                        // color: Colors.red,
                          width: 5.0),
                    )

                ),
              ),
            ),

            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FlatButton(onPressed: (){

                    if(categorie_text.text.toString().isEmpty){
                        MessageToast m=MessageToast('Veuillez saisir la categorie !');
                    }else{
                      CategorieModel categorieModel= CategorieModel(Categorie:categorie_text.text.toString());
                      DBProvider_new.db.newCategorie(categorieModel);
                      print("Success");
                      DBProvider_new.db.getAllCategorie();
                      
                      Navigator.of(context).pop();
                      categorie_text.clear();
                    }
                  },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                          side: BorderSide(color: Colors.blueAccent)
                      ),
                      color: Colors.blueAccent,
                      child: Text("Ajouter categorie",style: TextStyle(color: Colors.white),) ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


