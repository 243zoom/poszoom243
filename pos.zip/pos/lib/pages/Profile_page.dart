import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smartpos/class_dart/LoginModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/class_dart/tauxModel.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/UI.dart';
import 'package:smartpos/pages/add_produit_page.dart';
import 'package:smartpos/utils/Database.dart';

import 'package:http/http.dart' as http;

class Profile_UI extends StatefulWidget {
  @override
  _Profile_UIState createState() => _Profile_UIState();
}

File imageFile;
String ImageP;
TextEditingController utilisateur_ctl = TextEditingController();
TextEditingController mail_ctrl = TextEditingController();
TextEditingController entreprise_ctrl = TextEditingController();
TextEditingController password_ctrl = TextEditingController();
TextEditingController password_ctrl2 = TextEditingController();
TextEditingController adresse_ctrl = TextEditingController();
TextEditingController phone_ctrl = TextEditingController();
TextEditingController usd_ctrl = TextEditingController();
TextEditingController cdf_ctrl = TextEditingController();
TextEditingController password=TextEditingController();
TextEditingController confirmer_password=TextEditingController();

Uint8List _bytesImage;
File _image;
String base64Image;
Image img;
int existe;

class _Profile_UIState extends State<Profile_UI> {



  Future Send_notification(String email,String name) async{

    //String adresse_mac="123456789";
    var url = 'http://sendmail.zoom243.com/send_mail.php';

    // Store all data with Param Name.
    var data = {'adresse': email,"name":name};

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.

    if (response.statusCode == 200) {
      // If the call to the server was successful, parse the JSON
     // List<dynamic> values=new List<dynamic>();
     // values = json.decode(response.body);

      Map<String, dynamic> data = json.decode(response.body);
      String  req = data["reponse"].toString();
     // _showDialogLoadEmail(context,req);
       Fluttertoast.showToast(
            msg:req,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0
        );

    } else {
      // If that call was not successful, throw an error.
       
      throw Exception('Failed to load post verifier votre connexion');
    }


  }


  Future<void> _showSelectionDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text("From where do you want to take the photo?"),
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    GestureDetector(
                      child: Text("Gallery"),
                      onTap: () {
                        _openGallery(context);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text("Camera"),
                      onTap: () {
                        // _openCamera(context);
                        getImageFromCamera();
                      },
                    )
                  ],
                ),
              ));
        });
  }

  Future getImageFromCamera() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    List<int> imageBytes = image.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    img = Image.memory(base64Decode(base64Image));
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + image.path);
    ImageP = image.path;
    _bytesImage = Base64Decoder().convert(base64Image);
    // img= Image.memory(base64Decode(base64Image));
    setState(() {
      ImageP = image.path;
      imageFile = image;
      Navigator.of(context).pop();
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

      
  }

  void _openGallery(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.gallery);

    List<int> imageBytes = picture.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    img = Image.memory(base64Decode(base64Image));
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + picture.path);
    ImageP = picture.path;
    _bytesImage = Base64Decoder().convert(base64Image);
    this.setState(() {
      imageFile = picture;
      ImageP = picture.path;
      Navigator.of(context).pop();
    });
    // Navigator.of(context).pop();
  }

  _setImageView() {
    if (imageFile != null) {
      return Image.file(imageFile);
    } else {
      // return Text("Please select an image");

      return Icon(
        Icons.person,
        size: 80,
      );
    }
  }

  Verify() async {
    int ex = await DBProvider_new.db.Verifier();
    setState(() {
      return existe = ex;
    });
  }

  startTimer() async {
    var dur = Duration(seconds: 4);
    return Timer(dur, route);
  }

  route() {
    Navigator.of(context).pop();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => ProfilePage()));

    utilisateur_ctl.clear();
    mail_ctrl.clear();
    entreprise_ctrl.clear();
    password_ctrl.clear();
    password_ctrl2.clear();
    adresse_ctrl.clear();
    phone_ctrl.clear();
    confirmer_password.clear();
    password.clear();
  }

  Future _showDialogEssaie(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Vous utilisez l'application une version d'essaie de 7 jours",
                        style: TextStyle(color: Colors.blue),
                      ),
                      Spacer(),
                      Text('OK')
                      //your code dropdown button here
                    ]),
              );
            },
          ),
        );
      },
    );
  }
bool isNumericUsingRegularExpression(String string) {
  final numericRegex = 
    RegExp(r'^-?(([0-9]*)|(([0-9]*)\.([0-9]*)))$');

  return numericRegex.hasMatch(string);
}

 /*isConnected()async{
     try {
     final result = await InternetAddress.lookup('m.com');
     if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
     print('connected');
   

     return true;
    } 
   } on SocketException catch (_) {
    print('not connected');
  //
  _showDialogLoadNotInternet(context);
   /*Fluttertoast.showToast(
            msg: "Veuillez vous connecter à un réseau internet pour créer le compte",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.blue,
            textColor: Colors.white,
            fontSize: 16.0
        );*/
    return false;
   }
    }

*/
Future _showDialogLoadEmail(context,String ms) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        ms,
                        style: TextStyle(color: Colors.blue),
                      ),
                      Spacer(),
                      InkWell(
                        onTap:(){

                        },
                        child:Text('OK'),
                      )
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }

  Future _showDialogLoadNotInternet(context) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "Veuillez vous connecter à un réseau internet pour créer le compte",
                        style: TextStyle(color: Colors.blue),
                      ),
                      Spacer(),
                      InkWell(
                        onTap:(){
                             Navigator.of(context).pop();
                        },
                        child:Text('OK'),
                      )
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }
 Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SpinKitCircle(
                          color: Colors.blue,
                          size: 40.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),
          );
        },
      );
    }
  @override
  Widget build(BuildContext context) {
    //load

    Future _showDialogLoadEmail(context,String ms) async {
    return await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              return SingleChildScrollView(
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        ms,
                        style: TextStyle(color: Colors.blue),
                      ),
                      Spacer(),
                      InkWell(
                        onTap:(){

                        },
                        child:Text('OK'),
                      )
                      //your code dropdown button here
                    ]),
              );
            },
          ),

        );

      },
    );

  }

   

    Widget _title() {
      return Column(
        // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          ///SizedBox(height: 20,),
        ],
      );
    }

    Widget Text_field() {
      return Card(
          child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
          child: TextField(
            // maxLength: 10,
            textAlign: TextAlign.start,
            autocorrect: true,
            controller: mail_ctrl,
            style: GoogleFonts.lato(color: Colors.grey[700]),
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Contact",
              labelStyle: TextStyle(
                color: Colors.grey,
              ),
              // prefixText: "Saisissez votre nom"
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
          child: TextField(
            // maxLength: 10,
            textAlign: TextAlign.start,
            autocorrect: true,
            controller: entreprise_ctrl,
            style: GoogleFonts.lato(color: Colors.grey[700]),
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "Nom entreprise",
              labelStyle: TextStyle(
                color: Colors.grey,
              ),
              // prefixText: "Saisissez votre nom"
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        FlatButton(
          onPressed: () {
            setState(() {
              if (mail_ctrl.text.toString().isEmpty) {
                MessageToast m = MessageToast("Email vide !");
                m.ShowMessage();
              }
              if (entreprise_ctrl.text.toString().isEmpty) {
                MessageToast m = MessageToast("nom entreprise vide !");
                m.ShowMessage();
              } else if (base64Image == null) {
                MessageToast m = MessageToast("Veuillez inserer le logo !");
                m.ShowMessage();
              } else {
                ProfileModel pm = ProfileModel(
                    email: mail_ctrl.text.toString(),
                    business_name: entreprise_ctrl.text.toString());
                DBProvider_new.db.newProfile(pm);

                //Message m=Message("Success saved !");
                //  m.ShowMessage();
                // Verify();
                startTimer();
                _showDialogLoad(context);

                // utilisateur_ctl.clear();
                // mail_ctrl.clear();
              }
            });
          },
          color: Colors.blueAccent,
          child: Text(
            'Continuer',
            style: TextStyle(color: Colors.white),
          ),
        ),
        SizedBox(
          height: 100,
        )
      ]));
    }

    
    return SafeArea(
        child: Scaffold(
            body: Stack(
      children: [
        Container(
          decoration: new BoxDecoration(
              image: new DecorationImage(
            image: new AssetImage("assets/images/walpaper.jpg"),
            fit: BoxFit.cover,
          )),
        ),
        Container(
          color: Colors.grey.withOpacity(0.5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              /* Container(
                  width: 120,
                  child: Image(
                    image:  AssetImage("assets/images/pos_logo.png"),
                  ),
                ),*/
              SizedBox(height: 70.0,),
              Padding(
                padding: const EdgeInsets.only(left: 8.0, right: 8.8),
                child: Text(
                  'Identification de l\'entreprise',
                  style: TextStyle(color: Colors.white, fontSize: 15),
                ),
              ),
              SizedBox(height: 10.0,),

              Expanded(
                child: ListView(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left:8.0,right: 8.0,top: 8.0),
                      child: Card(
                        child: Container(
                          height: 495,
                          //color: Colors.grey.withOpacity(0.5),
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  controller: mail_ctrl,
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  textInputAction: TextInputAction.done,

                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "Adresse email",
                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  controller: phone_ctrl,
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  textInputAction: TextInputAction.done,
                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "Numero de téléphone",
                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  controller: entreprise_ctrl,
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  textInputAction: TextInputAction.done,

                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "Nom du business",
                                    // hintStyle: TextStyle(color: Colors.white),

                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  controller: adresse_ctrl,
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "Adresse de l'entreprise",
                                    // hintStyle: TextStyle(color: Colors.white),
                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  controller: password,
                                  obscureText: true,
                                  obscuringCharacter: "*",
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "Mot de passe ",
                                    // hintStyle: TextStyle(color: Colors.white),
                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  obscureText: true,
                                  obscuringCharacter: "*",
                                  controller: confirmer_password,
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "Confirmer mot de passe ",
                                    // hintStyle: TextStyle(color: Colors.white),
                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                                child: TextField(
                                  // maxLength: 10,
                                  textAlign: TextAlign.start,
                                  autocorrect: true,
                                  controller: usd_ctrl,
                                  style: GoogleFonts.lato(color: Colors.grey[700]),
                                  textInputAction: TextInputAction.done,
                                  decoration: InputDecoration(
                                    // border: OutlineInputBorder(),
                                    hintText: "1 USD =? CDF",
                                    // hintStyle: TextStyle(color: Colors.white),
                                    labelStyle: TextStyle(
                                      color: Colors.grey,
                                    ),
                                    // prefixText: "Saisissez votre nom"
                                  ),
                                ),
                              ),
                              /*Padding(
                          padding: const EdgeInsets.fromLTRB(30, 10, 30, 0),
                          child: TextField(
                            // maxLength: 10,
                            textAlign: TextAlign.start,
                            autocorrect: true,
                            controller: cdf_ctrl,
                            style: GoogleFonts.lato(color: Colors.grey[700]),
                            textInputAction: TextInputAction.done,
                            decoration: InputDecoration(
                              // border: OutlineInputBorder(),
                              hintText: "Taux CDF",
                              // hintStyle: TextStyle(color: Colors.white),
                              labelStyle: TextStyle(
                                color: Colors.grey,
                              ),
                              // prefixText: "Saisissez votre nom"
                            ),
                          ),
                        ),*/
                              Padding(
                                  padding: const EdgeInsets.all(22.0),
                                  child: InkWell(
                                    onTap: () {
                                      String email = mail_ctrl.text;
                                      final bool isValid =
                                      EmailValidator.validate(email);

                                      if (isValid == false) {
                                        print('Email is valid? ' +
                                            (isValid ? 'yes' : 'no'));
                                        MessageToast m =
                                        MessageToast("Adresse email non valide !");
                                        m.ShowMessage();
                                      }else if (mail_ctrl.text.toString().isEmpty) {
                                        MessageToast m = MessageToast("Email vide !");
                                        m.ShowMessage();
 
                                      } else if (entreprise_ctrl.text
                                          .toString()
                                          .isEmpty) {
                                        MessageToast m = MessageToast("nom entreprise vide !");
                                        m.ShowMessage();
                                      } else if (phone_ctrl.text.isEmpty) {
                                        MessageToast m =
                                        MessageToast("Saisir le numéro de telephone");
                                        m.ShowMessage();
                                      } else if(phone_ctrl.text.length<10){
                                        MessageToast m =
                                        MessageToast("Numéro de télephone non valide");
                                        m.ShowMessage();
                                      }
                                      else if (entreprise_ctrl.text.isEmpty) {
                                        MessageToast m = MessageToast(
                                            "Saisir le nom de l'entreprise !");
                                        m.ShowMessage();
                                      } else if (adresse_ctrl.text
                                          .toString()
                                          .isEmpty) {
                                        MessageToast m = MessageToast("Saisir l'adresse  !");
                                        m.ShowMessage();
                                      } else if (usd_ctrl.text.isEmpty) {
                                        MessageToast m =
                                        MessageToast("Taux du jour vide  !");
                                        m.ShowMessage();
                                      }
                                      else if(isNumericUsingRegularExpression(usd_ctrl.text.toString())==false){
                                            MessageToast m =
                                        MessageToast("Taux non valide !");
                                        m.ShowMessage();
                                      }
                                      
                                      else if(password.text.isEmpty){
                                        MessageToast m =
                                        MessageToast("Veuillez saisir votre mot de passe !");
                                        m.ShowMessage();
                                      }  else if(confirmer_password.text.isEmpty){
                                        MessageToast m =
                                        MessageToast("Veuillez confirmer votre mot de passe !");
                                        m.ShowMessage();
                                      } 

                                      
                                      
                                      else if(password.text.toString()==confirmer_password.text.toString()){

                                     
                                        print('password identique');
                                      

                                         Send_notification(mail_ctrl.text,entreprise_ctrl.text);
                                        ProfileModel pm = ProfileModel(
                                          email: mail_ctrl.text.toString(),
                                            business_name:
                                            entreprise_ctrl.text.toString(),
                                            telephone: phone_ctrl.text,
                                            adresse: adresse_ctrl.text);
                                        DBProvider_new.db.newProfile(pm);
                                        //new user for login
                                        LoginModel lm = LoginModel(
                                            username:
                                            mail_ctrl.text.toString(),
                                            password: confirmer_password.text.toString(),
                                            level: "0");
                                        DBProvider_new.db.newLogin(lm);
                                        //insert taux
                                        TauxModel tauxM = TauxModel(
                                            usd: usd_ctrl.text);
                                        DBProvider_new.db.newTaux(tauxM);
                                        print('taux success');
                                        //Message m=Message("Success saved !");
                                        //  m.ShowMessage();
                                        // Verify();
                                        startTimer();
                                        _showDialogLoad(context);

                                        //send notification email 

                                        

                                       /* Send_notification(mail_ctrl.text);
                                        ProfileModel pm = ProfileModel(
                                            email: mail_ctrl.text.toString(),
                                            business_name:
                                            entreprise_ctrl.text.toString(),
                                            telephone: phone_ctrl.text,
                                            adresse: adresse_ctrl.text);
                                        DBProvider_new.db.newProfile(pm);
                                        //new user for login
                                        LoginModel lm = LoginModel(
                                            username:
                                            mail_ctrl.text.toString(),
                                            password: confirmer_password.text.toString(),
                                            level: "0");
                                        DBProvider_new.db.newLogin(lm);
                                        //insert taux
                                        TauxModel tauxM = TauxModel(
                                            usd: usd_ctrl.text);
                                        DBProvider_new.db.newTaux(tauxM);
                                        print('taux success');
                                        //Message m=Message("Success saved !");
                                        //  m.ShowMessage();
                                        // Verify();
                                        startTimer();
                                        _showDialogLoad(context);

                                        */
                                      }
                                      //if password is no identique 

                                      /*else if(base64Image==null){
                                Message m=Message("Veuillez inserer le logo !");
                                m.ShowMessage();
                              }*/
                                      else {
                                        MessageToast m=MessageToast("Mot de passe non identique");
                                        m.ShowMessage();
                                      }
                                    },
                                    child: Container(
                                      decoration: new BoxDecoration(
                                          color: Colors.blue[700],
                                          borderRadius: new BorderRadius.all(
                                            Radius.circular(30.0),
                                          )),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.all(10.0),
                                            child: Text(
                                              'ENREGISTRER',
                                              style: TextStyle(color: Colors.white),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ))

                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            ],
          ),
        )
      ],
    )

            /*

        ListView(
        children: [
          _title(),
          Text_field()
        ],
      ) ,
         */
            ));
  }
}
