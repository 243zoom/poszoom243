import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:smartpos/utils/Database.dart';

class LicencePage extends StatefulWidget {
  @override
  _LicencePageState createState() => _LicencePageState();
}

class _LicencePageState extends State<LicencePage> {
  @override
  String date_from_db="";
  String reste_day="";

  void GetDateFromDb()async{
    String  date=await DBProvider_new.db.ActivationDate();
    setState(() {
      date_from_db=date.toString();
      print('her eis '+date.toString());

      // final birthdayDate = DateTime(date.toString(),,);
      var a = Jiffy(date).year;
      var d = Jiffy(date).dateTime.day;
      var m= Jiffy(date).month;

      final date1 = DateTime(a,m,d);//yyyy:m:d
      //final d= DateTime(2020,12, 28);
      final toDayDate = DateTime.now();
      var different = toDayDate.difference(date1).inDays;
      //   final difference = date2.difference(date1).inDays;
      int day=int.parse(different.toString());

      if(day<=7){
        print('votre périod est valide  $different');

        int periode=7;
        int rest=periode-day;
        reste_day=rest.toString();

        // 19362
      }else{
        print('Application expirée');

        /*if (Navigator.canPop(context)) {
          Navigator.pop(context);
        } else {
          SystemNavigator.pop();
        }*/


      }


    });
  }

  void initState() {
    GetDateFromDb();


      }




      Widget build(BuildContext context) {

        var now = DateTime.now();
        String d= DateFormat().format(now);


        return Scaffold(
      body: Container(

         decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,
            )
        ),

        child: Column(
          children: [
              Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,

              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('$d',style: TextStyle(color: Colors.white),),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Ma licence',style: TextStyle(color: Colors.white,fontSize: 19),),
                  ),


                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 5.0,),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pop();
                    },
                    child:  Row(
                      children: [
                        Icon(Icons.arrow_back,color: Colors.white,size: 26,),
                        Text('Retour',style: TextStyle(color: Colors.white,fontSize: 19),),
                      ],
                    ),
                  ),

                  Spacer(),
                  InkWell(
                    onTap: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child:  Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.settings,color: Colors.white,),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      Navigator.pushReplacement(context, MaterialPageRoute(

                          builder:(context)=> LoginPage()

                      )
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.logout,color: Colors.white,),
                    ),
                  )
                ],
              ),
            ),

             Padding(
               padding: const EdgeInsets.all(8.0),
              // child: Text('Type de licence :',style: TextStyle(fontSize: 25),),
             ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                decoration: new BoxDecoration(
                  color: Colors.white.withOpacity(0.5), //new Color.fromRGBO(255, 0, 0, 0.0),
                    borderRadius: new BorderRadius.all(
                       Radius.circular(5.0),
                       )
                  ),
                child: Column(
                  children: [
                    Padding(
                    padding: const EdgeInsets.all(8.0),
                     child: Text("Echéance d'activation ",style: TextStyle(fontSize: 15),),
                    ),
                    Divider(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [ 
                          Text(' $reste_day jours restant',style: TextStyle(fontSize: 30),),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            /*Padding(
              padding: const EdgeInsets.all(10.0),
              child: FlatButton(onPressed: (){
                //_showDialogCreerCompte(context);
              },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18.0),
                      side: BorderSide(color: Colors.blue)
                  ),
                  color: Colors.blue,
                  child: Text("Reactiver",style: TextStyle(color: Colors.white),) ),
            ),
*/

          ],
        ),
      ),
    );
  }
}
