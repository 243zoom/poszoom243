import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:smartpos/class_dart/s_categorieModel.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/parametre_pos.dart';
import 'package:searchable_dropdown/searchable_dropdown.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/class_dart/categorieModel.dart';
import 'package:smartpos/class_dart/message.dart';
import 'package:smartpos/pages/produit_page.dart';
import 'package:smartpos/styleguides/colors.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';

int id_produit;
String produit_set;
String prix_set;
class modifier_produit extends StatefulWidget {
  modifier_produit(int id,String produit,String prix){
    id_produit=id;
    produit_set=produit;
    prix_set=prix;
  }


  @override
  _modifier_produitState createState() => _modifier_produitState();
}



class _modifier_produitState extends State<modifier_produit> {


List _device = [
  "Devise",
  "CDF",
  "USD"
];

File imageFile;
Uint8List _bytesImage;
String  base64Image;
List<DropdownMenuItem<String>> _dropDownMenuItems;
String _currentDevice;
String  _currentCategorieModel="";
String imagePath="";

TextEditingController stock_ctr=TextEditingController();
TextEditingController _produit=TextEditingController();
TextEditingController _prix=TextEditingController();

  SubCategorieModel subCategorie;

  List<SubCategorieModel> sous_items = new List();
  List<CategorieModel> categorie_items = new List();
  CategorieModel categorie;
  int id_categorie=0;
  String type_categorie="";


  LoadSuCat(int id){
    DBProvider_new.db.getAllSousCategorieByID(id).then((notes) {
      setState(() {
        notes.forEach((note) {
          sous_items.add(SubCategorieModel.fromMap(note.toMap()));
        });
      });
    });
  }

  @override
  void initState() {
    _dropDownMenuItems = getDropDownMenuItems();
    _currentDevice = _dropDownMenuItems[0].value;
    // TODO: implement initState
    super.initState();

    _produit.text=produit_set;
    _prix.text=prix_set;

    DBProvider_new.db.getCategorie().then((notes) {
      setState(() {
        notes.forEach((note) {
          categorie_items.add(CategorieModel.fromMap(note));
        });

      });
    });
  }
  List<DropdownMenuItem<String>> getDropDownMenuItems() {
    List<DropdownMenuItem<String>> items = new List();
    for (String city in _device) {
      items.add(new DropdownMenuItem(value: city, child: new Text(city)));
    }
    return items;
  }
  void changedDropDownItem(String selectedCity) {
    setState(() {
      _currentDevice = selectedCity;
    });
  }
  Future<void> _showSelectionDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text("From where do you want to take the photo?"),
              content:  SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    GestureDetector(
                      child: Text("Gallery"),
                      onTap: () {
                        _openGallery(context);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text("Camera"),
                      onTap: () {
                        // _openCamera(context);
                        getImageFromCamera();
                      },
                    )
                  ],
                ),
              )
          );
        });
  }

  Future getImageFromCamera() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    List<int> imageBytes = image.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + image.path);
    imagePath=image.path;

    _bytesImage = Base64Decoder().convert(base64Image);
    setState(() {
      imagePath=image.path;
      imageFile = image;
      DBProvider_new.db.getAllCategorie();
      Navigator.of(context).pop();

    });


  }

  void _openGallery(BuildContext context) async {
    var picture = await ImagePicker.pickImage(source: ImageSource.gallery);
    List<int> imageBytes = picture.readAsBytesSync();
    print(imageBytes);
    base64Image = base64Encode(imageBytes);
    //  img= Image.memory(base64Decode(base64Image));
    print('string is');
    print(base64Image);
    print("You selected gallery image : " + picture.path);
    imagePath=picture.path;
    this.setState(() {
      imagePath=picture.path;
      imageFile = picture;
      Navigator.of(context).pop();
    });
    // Navigator.of(context).pop();
  }
  _setImageView() {
    if (imageFile != null) {
      return Image.file(imageFile);
    } else {
      // return Text("Please select an image");

      return Icon(

        Icons.image,
        color: Colors.white,
        size: 30,
      );
    }
  }
  startTimer()async{

    var dur=Duration(seconds: 1);
    return Timer(dur,route);
  }

  route(){
    Navigator.of(context).pop();
   // Navigator.of(context).pop();

    Navigator.pushReplacement(context, MaterialPageRoute(
        builder:(context)=> ProduitPage()
    ));
  }



  @override
  Widget build(BuildContext context) {


    Future _showDialogLoad(context) async {
      return await showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[

                        SpinKitCircle(
                          color: Colors.blue,
                          size: 40.0,
                        ),
                        //your code dropdown button here
                      ]),
                );
              },
            ),

          );

        },
      );

    }


    var now = DateTime.now();
    String d= DateFormat().format(now);
    return  Scaffold(

      body: Container(

        decoration: new BoxDecoration(
            image: new DecorationImage(
              image: new AssetImage("assets/images/bg3.png"),
              fit: BoxFit.cover,

            )
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color: Colors.black12.withOpacity(0.5),
              height: 80,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      '$d',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  Spacer(),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Modifier produit',
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ),

                ],
              ),
            ),
            Container(
              height: 50,
              color: Colors.grey.withOpacity(0.5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 5.0,
                  ),
                  InkWell(
                    onTap: () {
                      //Navigator.of(context).pop();
                      Navigator.pushReplacement(
                          context, MaterialPageRoute(builder: (context) => ProduitPage()));
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                        Text(
                          'Retour',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  InkWell(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Parametre(),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(
                        Icons.logout,
                        color: Colors.white,
                      ),
                    ),
                  )
                ],
              ),
            ),


            Expanded(
              child: ListView(
                 children: [
                   Container(
                     decoration: BoxDecoration(
                       //color: Colors.white,
                       color: Colors.white.withOpacity(0.7),
                       borderRadius: BorderRadius.all(
                         Radius.circular(5) ,

                       ),
                     ),
                     child: Column(
                       children: [
                         Padding(
                           padding: const EdgeInsets.all(10.0),
                           child: TextFormField(
                             controller: _produit,
                             decoration: new InputDecoration(labelText: "Nom du produit",
                                 border: OutlineInputBorder(
                                   borderSide: BorderSide(
                                     // color: Colors.red,
                                       width: 5.0),
                                 )

                             ),
                           ),
                         ),
                         Padding(
                           padding: const EdgeInsets.all(10.0),
                           child: TextFormField(
                             controller: _prix,
                             keyboardType: TextInputType.text,
                             decoration: new InputDecoration(labelText: "Prix du produit",
                                 border: OutlineInputBorder(
                                   borderSide: BorderSide(
                                     //color: Colors.red,
                                       width: 5.0),
                                 )

                             ),
                           ),
                         ),

                         Column(
                           crossAxisAlignment: CrossAxisAlignment.stretch,
                           children: [
                             Padding(
                               padding: const EdgeInsets.all(10.0),
                               child: DropdownButton(
                                 value: _currentDevice,
                                 items: _dropDownMenuItems,
                                 // style: GoogleFonts.lato(color: Colors.grey[800]),
                                 onChanged: changedDropDownItem,

                                 elevation: 2,
                                 style: TextStyle(color: Colors.black54),
                                 underline: Container(
                                   height: 2,

                                 ),
                               ),

                             ),
                           ],
                         ),
                         Padding(
                           padding: const EdgeInsets.all(10.0),
                           child: Container(

                             decoration: BoxDecoration(
                                 color: Colors.white,
                                 borderRadius: BorderRadius.circular(10),
                                 boxShadow: [
                                 ]
                             ),
                             child: Padding(
                                 padding: const EdgeInsets.all(8.0),
                                 child: Column(
                                   crossAxisAlignment: CrossAxisAlignment.stretch,
                                   mainAxisAlignment: MainAxisAlignment.start,
                                   children: [
                                     SearchableDropdown.single(


                                       items: categorie_items.map((item){
                                         return DropdownMenuItem<CategorieModel>(
                                           child: Text(item.Categorie),value: item,
                                         );
                                       }).toList(),
                                       isCaseSensitiveSearch: true,
                                       value: categorie,
                                       hint: "Selectionner une categorie",
                                       searchHint: "Selectionner une categorie",
                                       onChanged: (value) {
                                         setState(() {
                                           categorie=value;
                                           LoadSuCat(categorie.id);
                                           //_currentCategorieModel = value;
                                           print('cat '+categorie.Categorie);
                                         });
                                       },
                                       isExpanded: true,
                                     )

                                   ],
                                 )
                             ),
                           ),

                         ),
                         Padding(
                           padding: const EdgeInsets.only(left:8.0,right: 8.0,top: 5.0),
                           child: Container(

                             decoration: BoxDecoration(
                                 color: Colors.white.withOpacity(0.8),
                                 borderRadius: BorderRadius.circular(5),
                                 boxShadow: []),
                             child: Padding(
                                 padding: const EdgeInsets.all(8.0),
                                 child: Column(
                                   crossAxisAlignment: CrossAxisAlignment.stretch,
                                   mainAxisAlignment: MainAxisAlignment.start,
                                   children: [
                                     SearchableDropdown.single(
                                       items: sous_items.map((item) {
                                         return DropdownMenuItem<SubCategorieModel>(
                                           child: Text(item.subcategorie),
                                           value: item,
                                         );
                                       }).toList(),
                                       isCaseSensitiveSearch: true,
                                       value: subCategorie,
                                       hint: "Sous categorie",
                                       searchHint: "",
                                       onChanged: (value) {
                                         setState(() {
                                           type_categorie="sub";
                                           //id_categorie=subCategorie.id;
                                           subCategorie=value;
                                           //categorie = value;
                                           //_currentCategorieModel = value;
                                           // print('cat ' + categorie.Categorie);
                                         });
                                       },
                                       isExpanded: true,
                                     )
                                   ],
                                 )),
                           ),
                         ),

                         Column(
                           crossAxisAlignment: CrossAxisAlignment.stretch,
                           children: [
                             Padding(
                               padding: const EdgeInsets.all(10.0),
                               child: FlatButton(onPressed: (){
                                 _showSelectionDialog(context);
                               },
                                   shape: RoundedRectangleBorder(
                                       borderRadius: BorderRadius.circular(18.0),
                                       side: BorderSide(color: Colors.blue[700])
                                   ),
                                   color: Colors.blue[700],
                                   child: Text("Choisir l'image du produit",style: TextStyle(color: Colors.white),) ),
                             ),
                           ],
                         ),

                         InkWell(
                           onTap: (){
                             _showSelectionDialog(context);

                           },
                           child: Center(
                             child: Padding(
                               padding: const EdgeInsets.all(10.0),
                               child: Column(
                                 // mainAxisAlignment: MainAxisAlignment.start,
                                 children: [
                                   Container(
                                     width: 90,
                                     height: 80,
                                     color: Colors.grey,
                                     child: _setImageView(),
                                   ),
                                 ],
                               ),
                             ),
                           ),
                         ),
                         Column(
                           crossAxisAlignment: CrossAxisAlignment.stretch,
                           children: [
                             Padding(
                               padding: const EdgeInsets.all(10.0),
                               child: FlatButton(onPressed: (){

                          //print('device '+_currentDevice.toString());

                                 // _showSelectionDialog(context);
                                 if(_currentDevice.toString()=="Devise"){
                                   MessageToast m=MessageToast('Selectionnez la devise !');
                                   m.ShowMessage();
                                 }else
                                 if(_produit.text.toString().isEmpty){
                                   print('champ produit vide !');
                                   MessageToast m=MessageToast('champ produit vide!');
                                   m.ShowMessage();
                                 } else if(_prix.text.toString().isEmpty) {
                                   print('champ prix vide');
                                   MessageToast m=MessageToast('champ prix vide !');
                                   m.ShowMessage();
                                 }
                                 else if(categorie==null){
                                   MessageToast m=MessageToast('Veuillez choisir la categorie');
                                   m.ShowMessage();
                                 }else if(subCategorie==null){
                                   MessageToast m=MessageToast('Veuillez choisir la sous categorie');
                                   m.ShowMessage();
                                 }
                                 else if(base64Image==null){
                                   MessageToast m=MessageToast('l\'image du produit vide !');
                                   m.ShowMessage();
                                 }else if(_currentDevice=="devise"){
                                   MessageToast m=MessageToast('Selectionnez la devise !');
                                   m.ShowMessage();
                                 }
                                 else {

                                   DBProvider_new.db.EditProduit(id_produit, _produit.text, categorie.Categorie, imagePath, _prix.text, _currentDevice.toString(),subCategorie.id);
                                   print('sucess edit $_currentCategorieModel and device $_currentDevice' );
                                   //Navigator.of(context).pop();
                                   _produit.clear();
                                   _prix.clear();
                                   stock_ctr.clear();
                                   _currentCategorieModel="";
                                   startTimer();
                                   _showDialogLoad(context);
                                   /*
                     */
                                 }

                               },
                                   shape: RoundedRectangleBorder(
                                       borderRadius: BorderRadius.circular(18.0),
                                       side: BorderSide(color: Colors.blue[700])
                                   ),
                                   color: Colors.blue[700],
                                   child: Text("Modifier produit",style: TextStyle(color: Colors.white),) ),
                             ),
                           ],
                         ),

                       ],
                     ),
                   ) ,
                 ],
              ),
            ),


          ],
        ),
      ),
    );
  }
}
