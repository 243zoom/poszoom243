import 'package:flutter/material.dart';
import 'package:smartpos/styleguides/colors.dart';

class OpaqueImage  extends StatelessWidget {
  final imageUrl;
  @override
  const OpaqueImage({Key key,@required this.imageUrl}):super(key: key);
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Image.asset(
          imageUrl,
          width: double.maxFinite,
          height: double.maxFinite,
          fit: BoxFit.fill,
        ),
        Container(
          color: primaryColorOpacity.withOpacity(0.85),
        )
      ],
    );
  }
}
