import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:smartpos/pages/Login_page.dart';
import 'package:smartpos/pages/Profile_page.dart';
import 'package:smartpos/pages/UI.dart';
import 'package:smartpos/pages/Verification.dart';
import 'package:smartpos/pages/VersionEssaie_page.dart';
import 'package:smartpos/pages/demandeActivation.dart';
import 'package:smartpos/utils/Database.dart';


void main()=>runApp(MaterialApp(
  debugShowCheckedModeBanner: false,
  theme: ThemeData(
      primarySwatch: Colors.blue,
      fontFamily: 'Raleway'
  ),
  home: ME(),
));
int existe;
class ME extends StatefulWidget {
  @override
  _MEState createState() => _MEState();
}

class _MEState extends State<ME> {

  void Verify() async{
    int  ex =await DBProvider_new.db.Verifier();

    setState(() {
      existe=ex;
    });
  }
  void initState(){
    super.initState();

    startTimer();
    Verify();
  }
  //create a timer async
  startTimer()async{
    var dur=Duration(seconds: 4);
    Verify();
    return Timer(dur,route);
  }

  route(){

    if(existe==0){
      print('not existe $existe');
      Navigator.pushReplacement(context, MaterialPageRoute( 
          builder:(context)=> VerificationPage() 
      )
      );
     /* Navigator.pushReplacement(context, MaterialPageRoute(

          builder:(context)=> VerificationPage()

      )
      );*/
      /*   Navigator.pushReplacement(context, MaterialPageRoute(

        builder:(context)=> LoginPage()

    )
    );
    */
    }else{
      print(' existe $existe');
      Navigator.pushReplacement(context, MaterialPageRoute(

          builder:(context)=> LoginPage()

      )
      );
//open register profile


    }



  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: new BoxDecoration(
                image: new DecorationImage(
                  image: new AssetImage("assets/images/background_pos.jpg"),
                  fit: BoxFit.fill,
                )
            ), 
          ), 
          
          SizedBox(height: 50,), 
          Column( 
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                //crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: 120,
                    child: Image(
                       image:  AssetImage("assets/images/pos_logo.png"),
                    ),
                  ),
                ],
              ),
              Container(
                child: SpinKitCircle(
                  color: Colors.white,
                  size: 30.0,
                ),

              ),
            ],
          )
        ],


      )
 
    ));
  }
}