
class ReceveCommandeModel {
  
  int ID;
  String produit;
  int prix;
  String devise;
  String resto;
  String date;
  String server;
  String client; 

  ReceveCommandeModel({
    this.ID,
    this.produit,
    this.prix,
    this.devise,
    this.resto,
    this.client,
    this.server,
    this.date
  });

  factory ReceveCommandeModel.fromJson(Map<String, dynamic> json) {
    return ReceveCommandeModel(
      ID: json['id'],
      produit: json['produit'],
      prix: json['prix'],
      devise: json['devise'],
      resto: json['restaurant'],
      date: json['date_add'],
      server: json['serveur'],
       client: json['client'] 
    );
  }
}
 