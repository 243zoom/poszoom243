import 'dart:io';


import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart';

/*
class PdfGenerator{

  static void openFileBytesForMobile(List<int>bytes)async{
    final output=await getTemporaryDirectory();
    final file=File("${output.path}/deals.pdf");
    await file.writeAsBytes(bytes);
   // OpenFile.open(file.path);
  }

  static generateAndViewSample(){

    final heading="What is lorem";
    final description="Lorm ipsum is simple text";

    try{
      final doc=Document();
      doc.addPage(MultiPage(
        build: (Context context)=>[
          Center(
            child: Text(heading),

          ),
          SizedBox(height: 10),
          Text(description)
        ]
      ));
      final pdfBytes =doc.save();
      if(pdfBytes.length>0){
        openFileBytesForMobile(pdfBytes);
        print('PDF Generated!');
      }
    }catch(exception ){
      print('Exception : \n$exception');
    }
  }
}*/