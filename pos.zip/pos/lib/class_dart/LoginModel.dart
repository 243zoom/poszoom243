import 'package:flutter/material.dart';

class LoginModel{

  int id;
  String username;
  String password;
  String level;

  LoginModel({this.username,this.password,this.level});

  factory LoginModel.fromMap(Map<String, dynamic> json) => new LoginModel(
    //id: json["id"],
      username: json["username"],
      password: json['password'],
      level: json['level']

    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    //"id": id,
    "username": username,
    "password" :password,
    "level":level,
    "id":id
  };

}