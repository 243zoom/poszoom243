 
class ClientModel{
  int id;
  String Client;
  String date_client;
  ClientModel({this.id,this.Client,this.date_client});

  factory ClientModel.fromMap(Map<String, dynamic> json) => new ClientModel(
    id: json["id"],
    Client: json["client"],
    date_client: json['date_client']
    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    "client": Client,
    "date_client" :date_client
  };

  @override
  String toString() {
    return '${Client.toLowerCase()}';
  }

}