 
class ActivationModel{

        int id;
        String delais;
        String date;

        ActivationModel({this.id,this.delais,this.date});

        factory ActivationModel.fromMap(Map<String, dynamic> json) => new ActivationModel(
            id: json["id"],
            delais: json['delais'],
            date: json['date_act']
          // blocked: json["blocked"] == 1,
        );

        Map<String, dynamic> toMap() => {
          "id": id,
          "delais" :delais,
          "date_act":date
        };
}