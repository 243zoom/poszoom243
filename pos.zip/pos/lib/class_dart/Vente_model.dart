import 'package:flutter/material.dart';


class VenteModel{

  int id;
  String produit_vendu;
  String client;
  String quantite;
  String montant;
  String devise;
  String date_vente;

  VenteModel({this.id,this.produit_vendu,this.client,this.quantite,this.montant,this.devise,this.date_vente});

  factory VenteModel.fromMap(Map<String, dynamic> json) => new VenteModel(
      id: json["id"],
      produit_vendu: json["produit_vendu"],
      quantite: json['quantite'],
      client: json['client'],
      montant: json['montant'],
      devise: json['devise'],
      date_vente: json['date_vente']

    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    "produit_vendu": produit_vendu,
    "quantite" :quantite,
    "client":client,
    "montant":montant,
    "devise":devise,
    "date_vente":date_vente
  };
}