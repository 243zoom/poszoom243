import 'package:flutter/material.dart';

class CommandeModel{

  int id;
  String Client_id;
  String quantite;
  String montant;
  String devise;
  String produit_id;
  String statuts;
  String date_commande;
  String view_client;
  String view_produit;
  String total;

  CommandeModel({this.id,this.Client_id,this.quantite,this.montant,this.devise,this.produit_id,this.statuts,this.date_commande,this.view_client,this.view_produit,this.total});

  factory CommandeModel.fromMap(Map<String, dynamic> json) => new CommandeModel(

      id: json["id"],
      Client_id: json["client"],
      quantite: json['quantite'],
      montant: json['montant'],
      devise: json['devise'],
      produit_id: json['produit'],
      statuts: json['statut'],
      date_commande: json['date_commande'],
      view_client: json['view_client'],
      view_produit:json['view_produit'],
      total: json['total']

    // blocked: json["blocked"] == 1,

  );

  Map<String, dynamic> toMap() => {

    "id": id,
    "client": Client_id,
    "quantite" :quantite,
    "montant":montant,
    "devise":devise,
    "produit":produit_id,
    "statut":statuts,
    "date_commande":date_commande,
    "view_client":view_client,
    "view_produit":view_produit,
    "total":total

  };


}