 

class ProfileModel{

  int id;

  String email;
  String picture;
  String business_name;
  String exist;
  String adresse;
  String telephone;

  ProfileModel({this.id,this.email,this.business_name,this.adresse,this.telephone});


  factory ProfileModel.fromMap(Map<String, dynamic> json) => new ProfileModel(
    id: json["id"],
    //utilisateur:json["utilisateur"],
    email: json['email'],

   // picture: json['picture'],
    business_name:json['businesse'],
    telephone: json['telephone'],
    adresse: json['adresse'],


    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    //"utilisateur": utilisateur,
    "telephone":telephone,
    "email" :email,
   // "picture":picture,
    "businesse":business_name,
    "adresse":adresse

  };

}