
class ClientFromServer {
  
 int clientID;
 String clientName;
 String clientDate;
 String resto;
 String server;


  ClientFromServer({
    this.clientID,
    this.clientName,
    this.clientDate,
    this.resto,
    this.server
  });

  factory ClientFromServer.fromJson(Map<String, dynamic> json) {
    return ClientFromServer(
      clientID: json['id'],
      clientName: json['client'],
      clientDate: json['date_add'],
      server: json['server'],
       resto: json['resto'] 
    );
  }
}
 