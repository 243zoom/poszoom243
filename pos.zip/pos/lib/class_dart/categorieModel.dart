 

class CategorieModel{
int id;
  String Categorie;

  CategorieModel({this.id,this.Categorie});


  factory CategorieModel.fromMap(Map<String, dynamic> json) => new CategorieModel(
    id: json["id"],
    Categorie: json["categorie"],

    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    "categorie": Categorie,
  };
@override
String toString() {
  return '${Categorie.toLowerCase()}';
}
}