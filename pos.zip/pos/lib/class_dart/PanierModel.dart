import 'package:flutter/material.dart';

class PanierModel{

  int id;
  String produit;
  String prix;
  String devise;
  String client;
  String date;


  PanierModel({this.id,this.produit,this.prix,this.devise,this.client,this.date}); 

  factory PanierModel.fromMap(Map<String, dynamic> json) => new PanierModel(
    id: json["id"],
    produit: json["produit"], 
    prix: json["prix"],
    devise: json["devise"],
    client: json['client'] ,
    date: json['date_panier']
    // blocked: json["blocked"] == 1,
  ); 

  Map<String, dynamic> toMap() => {
    "id": id,
    "produit": produit,
    "prix":prix,
    "devise":devise,
    "client":client,
    "date_panier":date
  };

  @override
  String toString() {
    return '${produit.toLowerCase()}';
  }

}