import 'package:flutter/material.dart';

class TauxModel{
  int id;
  String usd; 


  TauxModel({this.id,this.usd});
  
  factory TauxModel.fromMap(Map<String, dynamic> json) => new TauxModel(
    id: json["id"],
    usd: json["usd"], 
    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    "usd": usd
  };

  @override
  String toString() {
    return '${usd.toLowerCase()}';
  }

}