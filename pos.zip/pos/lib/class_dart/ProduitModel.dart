import 'package:flutter/material.dart';

class ProduitModel{

  String Produit;
  String Categorie;
  String  image;
  String prix;
  String devise;
  String type_categorie;
  String bar_code;
  String qr_code;

int id;
  ProduitModel({this.id,this.Produit,this.Categorie,this.image,this.prix,this.devise,this.type_categorie,this.bar_code,this.qr_code});


  factory ProduitModel.fromMap(Map<String, dynamic> json) => new ProduitModel(
    id: json["id"],
    Produit: json["produit"],
    Categorie: json['categorie'],
    image: json['image_produit'],
    prix: json['prix'],
    devise: json['devise'],
    type_categorie: json['id_sub'],
    bar_code: json['bar_code'],
    qr_code: json['qr_code']
  //  stock: json['stock']
    // blocked: json["blocked"] == 1,
  );

  Map<String, dynamic> toMap() => {
    "id":id,
    "produit": Produit,
    "categorie":Categorie,
    "image_produit":image,
    "prix":prix,
    "devise":devise,
    "id_sub":type_categorie,
    "bar_code":bar_code,
    "qr_code":qr_code
    //"stock":stock
  };
  @override
  String toString() {
    return '${Produit.toLowerCase()}';
  }
}