import 'package:flutter/material.dart';

// ignore: camel_case_types
class SubCategorieModel{

  int id;
  String  id_categorie;
  String subcategorie; 

  SubCategorieModel({this.id,this.subcategorie,this.id_categorie});
 
  factory SubCategorieModel.fromMap(Map<String, dynamic> json) => new SubCategorieModel(
    id: json["id"],
    subcategorie: json["subcategorie"], 
    id_categorie: json["categorie"],  
    // blocked: json["blocked"] == 1,
  );
   Map<String, dynamic> toMap() => {
    "id": id,
    "subcategorie": subcategorie,
    "categorie":id_categorie
  };

  @override
  String toString() {
    return '${subcategorie.toLowerCase()}';
  }


}