import 'dart:async';
import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:smartpos/class_dart/PanierModel.dart';
import 'package:smartpos/class_dart/Vente_model.dart';
import 'package:smartpos/class_dart/ActivationModel.dart';
import 'package:smartpos/class_dart/s_categorieModel.dart'; 
import 'package:smartpos/class_dart/tauxModel.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';
import 'package:smartpos/class_dart/ClientModel.dart';
import 'package:smartpos/class_dart/CommandeModel.dart';
import 'package:smartpos/class_dart/LoginModel.dart';
import 'package:smartpos/class_dart/ProduitModel.dart';
import 'package:smartpos/class_dart/ProfileModel.dart';
import 'package:smartpos/class_dart/categorieModel.dart';

class DBProvider_new {
  DBProvider_new._();
  static final DBProvider_new db = DBProvider_new._();

  Database _database;

  Future<Database> get database async {
    if (_database != null) return _database;
    // if _database is null we instantiate it
    _database = await initDB();
    return _database;
  }

  initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, "TestDB.db");
    return await openDatabase(path, version: 1, onOpen: (db) {},
        onCreate: (Database db, int version) async { 
      // PRIMARY KEY("Field1" AUTOINCREMENT)
     await db.execute("CREATE TABLE panier("
          "id INTEGER PRIMARY KEY AUTOINCREMENT,"
          "produit TEXT," 
          "prix TEXT,"
          "devise TEXT,"
          "client TEXT," 
          "date_panier TEXT" 
          ")");

      await db.execute("CREATE TABLE taux("
          "id INTEGER PRIMARY KEY AUTOINCREMENT,"
          "usd TEXT" 
          ")");
      await db.execute("CREATE TABLE souscategorie("
          "id INTEGER PRIMARY KEY AUTOINCREMENT,"
          "subcategorie TEXT,"
          "categorie TEXT"
          ")");
      await db.execute("CREATE TABLE business("
          "id INTEGER PRIMARY KEY AUTOINCREMENT,"
          "business TEXT,"
          "adresse TEXT,"
          "email   TEXT"
          ")");

      await db.execute("CREATE TABLE user ("
          "id INTEGER PRIMARY KEY,"
          "username TEXT,"
          "email TEXT,"
          "password TEXT,"
          "level TEXT,"
          "business TEXT"
          ")");
      //categorie table
     await db.execute("CREATE TABLE categorie("
          "id INTEGER PRIMARY KEY,"
          "categorie TEXT)");

      await db.execute("CREATE TABLE produit_pos("
          "id INTEGER PRIMARY KEY,"
          "produit TEXT,"
          "categorie TEXT,"
          "image_produit TEXT,"
          "prix TEXT,"
          "devise TEXT,"
          "id_sub TEXT,"
          "bar_code TEXT,"
          "qr_code TEXT"
          ")");
      await db.execute("CREATE TABLE vente("
          "id INTEGER PRIMARY KEY,"
          "produit_vendu TEXT,"
          "quantite TEXT,"
          "devise TEXT,"
          "client TEXT,"
          "date_vente TEXT"
          ")");
      await db.execute("CREATE TABLE client("
          "id INTEGER PRIMARY KEY,"
          "client TEXT,"
          "date_client TEXT)");

      await db.execute("CREATE TABLE commande("
          "id INTEGER PRIMARY KEY,"
          "client TEXT,"
          "quantite TEXT,"
          "produit TEXT,"
          "montant TEXT,"
          "devise  TEXT,"
          "date_commande TEXT,"
          "statut TEXT,"
          "view_client TEXT,"
          "view_produit TEXT,"
          "total TEXT"
          ")");

      await db.execute("CREATE TABLE profile("
          "id INTEGER PRIMARY KEY,"
          "email TEXT,"
          // "picture TEXT,"
          "businesse TEXT,"
          "telephone TEXT,"
          "adresse TEXT"
          ")");
      await db.execute("CREATE TABLE login("
          "id INTEGER PRIMARY KEY AUTOINCREMENT,"
          "username TEXT,"
          "password TEXT,"
          "level TEXT"
          ")");
      await db.execute("CREATE TABLE activation("
          "id INTEGER PRIMARY KEY AUTOINCREMENT,"
          "delais TEXT,"
          "date_act TEXT"
          ")");
    });
  }

//new sous categorie 
 newSousCategorie(SubCategorieModel sousCategorieModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM souscategorie");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into souscategorie(id,subcategorie,categorie)"
        " VALUES (?,?,?)",
        [id, sousCategorieModel.subcategorie, sousCategorieModel.id_categorie]);
    print('insert');
    return raw; 
  }
  newPanier(PanierModel panierModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM panier");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into panier(id,prix,devise,produit,client,date_panier)"
        " VALUES (?,?,?,?,?,?)",
        [id, panierModel.prix,panierModel.devise,panierModel.produit,panierModel.client,panierModel.date]); 
    return raw; 
  }
  //load list
  Future<List<PanierModel>> getAllProduitFromPanier() async {
    final db = await database;
    var res = await db.query("panier order by id desc"); 
    List<PanierModel> list =res.isNotEmpty ? res.map((c) => PanierModel.fromMap(c)).toList() : []; 
    return list;
  }
  //load sous categorie 

  Future<List<SubCategorieModel>> getAllSousCategorieByID(int id) async {
    final db = await database;
    var res = await db.query("souscategorie where categorie='$id'"); 
    List<SubCategorieModel> list =res.isNotEmpty ? res.map((c) => SubCategorieModel.fromMap(c)).toList() : [];
    return list;
  }

  //activation
  newActivation(ActivationModel activationModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM activation");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into activation (id,delais,date_act)"
        " VALUES (?,?,?)",
        [id, activationModel.delais, activationModel.date]);
    return raw;
  }

  /// categorie
  newCategorie(CategorieModel Categorie) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM categorie");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into categorie (id,categorie)"
        " VALUES (?,?)",
        [id, Categorie.Categorie]);
    return raw;
  }

  //get all categorie
  Future<List<CategorieModel>> getAllCategorie() async {
    final db = await database;
    var res = await db.query("categorie order by id desc");
    List<CategorieModel> list = res.isNotEmpty
        ? res.map((c) => CategorieModel.fromMap(c)).toList()
        : [];
    return list;
  }

  void loadSampleData() async {
    Map<String, dynamic> map = Map();
    for (int i = 0; i < 10; i++) {
      map['categorie'] = "Categorie : $i";
    }
  }

//delete the row
  deleteCategorie(String cat) async {
    final db = await database;
    return db.delete("categorie", where: "id = ?", whereArgs: [cat]);
  }

  deleteSousCategorie(int id) async {
    final db = await database;
    return db.delete("souscategorie", where: "id = ?", whereArgs: [id]);
  }

  Future<int> getCountCategorie() async {
    //database connection
    final db = await database;
    var x = await db.rawQuery('SELECT COUNT (*) from categorie');
    int count = Sqflite.firstIntValue(x);

    /*  Map<String,dynamic> map=Map();
    map['count']="$count";*/
    return count;
  }

  Future<int> queryRowCount() async {
    final db = await database;
    return Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM categorie'));
    Map<String, dynamic> map = Map();
  }

  Future<String> getPrix_produit(String pd) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE id='$pd'");
    String prix = table.first["prix"];
    return prix;
  }
  //
  Future<String> getProduitByNameCodeCodeBar(String code) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE bar_code='$code'");
    String prix = table.first["produit"];
   
    return prix;
  }
  // prix of the same produit
  Future<String> getProduitPrixCodeCodeBar(String code) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE bar_code='$code'");
    String prix = table.first["prix"];
   
    return prix;
  }
  // devise of same product
   Future<String> getProduitDeviseCodeCodeBar(String code) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE bar_code='$code'");
    String devise = table.first["devise"];
   
    return devise;
  }
  Future<String> getProduitByNameCodeQrCode(String code) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE qr_code='$code'");
    String prix = table.first["produit"];
    return prix;
  }
  // prix the same prix 
   Future<String> getProduitPrixCodeQrCode(String code) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE qr_code='$code'");
    String prix = table.first["produit"];
    return prix;
  }
  // devise of same product
  Future<String> getProduitDeviseCodeQrCode(String code) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE qr_code='$code'");
    String devise = table.first["devise"];
    return devise;
  }
  //new Produit
  newProduit(ProduitModel produitModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM produit_pos");
    int id = table.first["id"];
    print('is clong ' + id.toString());

    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into produit_pos (id,produit,categorie,image_produit,prix,devise,id_sub,bar_code,qr_code)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        [
          id,
          produitModel.Produit,
          produitModel.Categorie,
          produitModel.image,
          produitModel.prix,
          produitModel.devise,
          produitModel.type_categorie,
          produitModel.bar_code,
          produitModel.qr_code
        ]);
    return raw;
  }

  newTaux(TauxModel tauxModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM taux");
    int id = table.first["id"];

    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into taux (id,usd)"
        " VALUES (?,?)",
        [id, tauxModel.usd]);
    return raw;
  }

  //get all taux
  Future<List> getTaux() async {
    final db = await database;
    var res = await db.query("taux");
    return res.toList();
  }
  //new compte

  newVente(VenteModel venteModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM vente");
    int id = table.first["id"];
    print('is clong ' + id.toString());

    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into vente (id,produit_vendu,quantite,devise,client,date_vente)"
        " VALUES (?,?,?,?,?,?)",
        [
          id,
          venteModel.produit_vendu,
          venteModel.quantite,
          venteModel.devise,
          venteModel.client,
          venteModel.date_vente
        ]);
    return raw;
  }

  //get all vente
  Future<List<VenteModel>> getAllVente() async {
    final db = await database;
    var res = await db.query("vente order by id desc");
    List<VenteModel> list =
        res.isNotEmpty ? res.map((c) => VenteModel.fromMap(c)).toList() : [];
    return list;
  }

  //get produit
  Future<List<ProduitModel>> getAllProduit() async {
    final db = await database;
    var res = await db.query("produit_pos order by id desc");
    List<ProduitModel> list =
        res.isNotEmpty ? res.map((c) => ProduitModel.fromMap(c)).toList() : [];
    return list;
  }

  deleteProduit(int id) async {
    final db = await database;
    return db.delete("produit_pos", where: "id = ?", whereArgs: [id]);
  }

  deletePanier(int id) async {
    final db = await database;
    return db.delete("panier", where: "id = ?", whereArgs: [id]);
  }
   deleteAllPanier() async {
    final db = await database;
    return db.delete("panier");
  }

  Future<int> getCountProduit() async {
    //database connection
    final db = await database;
    var x = await db.rawQuery('SELECT COUNT (*) from produit_pos');
    int count = Sqflite.firstIntValue(x);

    /*  Map<String,dynamic> map=Map();
    map['count']="$count";*/
    return count;
  }

  //client
  newClient(ClientModel clientModel,) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM client");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into client (id,client,date_client)"
        " VALUES (?,?,?)", 
        [id, clientModel.Client, clientModel.date_client]);
    return raw;
  }
  newSyncroClient(ClientModel clientModel,String client) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM client");
    int id = table.first["id"];
    //insert to the table using the new id
    /*var raw = await db.rawInsert(
        "INSERT Into client (id,client,date_client)"
        " VALUES (?,?,?)",*/
    var raw=await db.rawInsert(
      "INSERT INTO client(id,client,date_client)"
      "SELECT :client"
      "WHERE NOT EXISTS(SELECT 1 FROM client WHERE client = :$client)",

       [id, clientModel.Client, clientModel.date_client]);
    return raw;
  }

  Future<List<ClientModel>> getAllClient() async {
    final db = await database;
    var res = await db.query("client order by id desc");
    List<ClientModel> list =
        res.isNotEmpty ? res.map((c) => ClientModel.fromMap(c)).toList() : [];
    return list;
  }

  Future<int> getCountClient() async {
    //database connection
    final db = await database;
    var x = await db.rawQuery('SELECT COUNT (*) from client');
    int count = Sqflite.firstIntValue(x);

    /*  Map<String,dynamic> map=Map();
    map['count']="$count";*/
    return count;
  }

  //delete client
  deleteClient(int id_client) async {
    final db = await database;
    return db.delete("client", where: "id = ?", whereArgs: [id_client]);
  }

  deleteCommande(int id) async {
    final db = await database;
    return db.delete("commande", where: "id = ?", whereArgs: [id]);
  }

  //commande client
  Future<List<CommandeModel>> getAllCommande() async {
    final db = await database;
    var res = await db.query("commande order by id desc");
    List<CommandeModel> list =
        res.isNotEmpty ? res.map((c) => CommandeModel.fromMap(c)).toList() : [];
    return list;
  }

  Future<List<CommandeModel>> getAllCommandeByClient(int client_id) async {
    final db = await database;
    var res = await db.query("commande where client='$client_id'");
    List<CommandeModel> list =
        res.isNotEmpty ? res.map((c) => CommandeModel.fromMap(c)).toList() : [];
    return list;
  }

  //insert commande client
  newCommande(CommandeModel commandeModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM commande");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into commande (id,client,quantite,montant,devise,produit,date_commande,statut,view_client,view_produit,total)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [
          id,
          commandeModel.Client_id,
          commandeModel.quantite,
          commandeModel.montant,
          commandeModel.devise,
          commandeModel.produit_id,
          commandeModel.date_commande,
          commandeModel.statuts,
          commandeModel.view_client,
          commandeModel.view_produit,
          commandeModel.total
        ]);
    return raw;
  }

  //new Profile
  newProfile(ProfileModel profileModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM profile");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into profile (id,email,businesse,telephone,adresse)"
        " VALUES (?,?,?,?,?)",
        [
          id,
          profileModel.email,
          profileModel.business_name,
          profileModel.telephone,
          profileModel.adresse
        ]);
    return raw;
  }

  Future<String> getNom_Profile() async {
    final db = await database;
    var table = await db.rawQuery("SELECT * FROM profile");
    String prix = table.first["businesse"];
    return prix;
  }

  //photo
  Future<String> getPhoto() async {
    final db = await database;
    var table = await db.rawQuery("SELECT * FROM profile");
    String picture = table.first["picture"];
    return picture;
  }
  //if profile exist
  /*Future<String> get_existe() async{
    final db = await database;
    var table = await db.rawQuery("SELECT * FROM profile");
    String prix= table.first["existe"];
    return prix;
  }*/

  //login
  Future<List<LoginModel>> getLogin() async {
    final db = await database;
    var res = await db.query("login");
    List<LoginModel> list =
        res.isNotEmpty ? res.map((c) => LoginModel.fromMap(c)).toList() : [];
    return list;
  }

  newLogin(LoginModel loginModel) async {
    final db = await database;
    //get the biggest id in the table
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM login");
    int id = table.first["id"];
    //insert to the table using the new id
    var raw = await db.rawInsert(
        "INSERT Into login (id,username,password,level)"
        " VALUES (?,?,?,?)",
        [id, loginModel.username, loginModel.password, loginModel.level]);
    return raw;
  }

//delete login
  deleteLogin(String login) async {
    final db = await database;
    return db.delete("login", where: "username = ?", whereArgs: [login]);
  }

//login compte
  Login(String username, String password) async {
    final db = await database;
    var table = await db.rawQuery(
        "SELECT * FROM login WHERE username='$username' AND password='$password'");
    String prix = table.first["level"];
    return prix;
  }

  //if table login is empty
  Verifier() async {
    final db = await database;
    int count = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM profile'));
    return count;
  }

  //verify commande
  Verifier_commande() async {
    final db = await database;
    int count = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM commande'));
    return count;
  }

  //pa
  Paye_commande(int id_client, String statut) async {
    final db = await database;

    int updateCount = await db.rawUpdate('''
    UPDATE commande 
    SET statut = ?
    WHERE client = ?
    ''', ['$statut', id_client]);
    return updateCount;
  }

//get statut by commande
  get_statut_by_client(int client) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM commande WHERE client='$client'");
    String prix = table.first["statut"];
    return prix;
  }

  Verifier_commande_by_Client(String id_client) async {
    final db = await database;
    int count = Sqflite.firstIntValue(await db
        .rawQuery("SELECT COUNT(*) FROM commande where client='$id_client'"));
    return count;
  }

  //statistique
  Nombre_commande(String date_from,String date_to) async {
    final db = await database;
    int count = Sqflite.firstIntValue(
        await db.rawQuery("SELECT COUNT(*) FROM commande WHERE date_commande BETWEEN '$date_from' AND '$date_to'"));
    return count;
  }

  Nombre_Client(String date_from,String date_to) async {
    final db = await database;
    int count =Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM client WHERE date_client BETWEEN '$date_from' AND '$date_to'"));
    return count;
  }

  Nombre_Vente(String st,String date_from,String date_to) async {
    final db = await database;
    int count = Sqflite.firstIntValue(
        await db.rawQuery("SELECT COUNT(*) FROM commande WHERE date_commande BETWEEN '$date_from' AND '$date_to' AND statut='$st' "));
    return count;
  }

  Vente_commande() async {
    final db = await database;
    int count = Sqflite.firstIntValue(
        await db.rawQuery("SELECT COUNT(*) FROM commande WHERE statut='2'"));
    return count;
  }

  verifier_commande_by_client(int id) async {
    final db = await database;
    int count = Sqflite.firstIntValue(
        await db.rawQuery("SELECT COUNT(*) FROM commande WHERE client='$id'"));
    return count;
  }

  verifier_email_client(String email) async {
    final db = await database;
    int count = Sqflite.firstIntValue(await db
        .rawQuery("SELECT COUNT(*) FROM login WHERE username='$email'"));
    return count;
  }

  Ver_if() async {
    final db = await database;
    var table = await db.rawQuery("SELECT MAX(id)+1 as id FROM produit_pos");
    int id = table.first["id"];
    return id;
  }

//View for id
  getViewNameClientByID(int id) async {
    final db = await database;
    var table = await db.rawQuery("SELECT * FROM client where id='$id'");
    String name_id = table.first['client'];
    return name_id;
  }

  Stock_set(int produit, int stock) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
    UPDATE produit_pos 
    SET stock = ?
    WHERE id = ?
    ''', ['$stock', produit]);
  }


  Future getTotalCDF(String date_from,String date_to) async {
    var db = await database;//like devise='CDF'
    var result = await db.rawQuery(
        "SELECT SUM(total) FROM commande WHERE date_commande BETWEEN '$date_from' AND '$date_to'  AND statut='2' AND devise='CDF'");
    int value = result[0]["SUM(total)"]; // value = 220
    return value;
  }

Future getTotalUSD(String date_from,String date_to) async {
    var db = await database;//like devise='CDF'
    var result = await db.rawQuery(
        "SELECT SUM(total) FROM commande WHERE date_commande BETWEEN '$date_from' AND '$date_to'  AND statut='2' AND devise='USD'");
    int value = result[0]["SUM(total)"]; // value = 220
    return value;
  }

  Future getTotalCommandeCDF() async {
    var db = await database;
    var result = await db.rawQuery(
        "SELECT SUM(total) FROM commande WHERE devise='CDF' AND statut='2'");
    int value = result[0]["SUM(total)"]; // value = 220
    return value;
  }

 /* Future<int> getTotalUSD() async {
    var db = await database;
    //var result = await dbClient.rawQuery("SELECT SUM(columnName) FROM $tableScorer");
    //recuperation id statut
    var result = await db.rawQuery(
        "SELECT SUM(montant) FROM commande WHERE devise='USD' AND statut='2'");
    int value = result[0]["SUM(montant)"]; // value = 220
    return value;
  }*/

  //ViewProduitByClient
  getViewProduitNameByID(String id_produit) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM produit_pos WHERE id='$id_produit'");
    String produit = table.first["produit"];
    //return map;
    return produit;
  }

  getViewProduitClientByID(String id_produit) async {
    final db = await database;
    var table =
        await db.rawQuery("SELECT * FROM client WHERE id='$id_produit'");
    String produit = table.first["client"];
    //return map;
    return produit;
  }

  Future<List> getAllNotes(String client_id) async {
    final db = await database;
    var res = await db.query("commande where client='$client_id'");
    return res.toList();
  }
  Future<List> getAllPanier() async {
    final db = await database;
    var res = await db.query("panier");
    return res.toList();
  }


  Future<List> getInfos() async {
    final db = await database;
    var res = await db.query("profile");
    return res.toList();
  }
  Future<List> getCurrentUser(int level) async {
    final db = await database;
    var res = await db.query("login where level='$level'");
    return res.toList();
  }

  // panier get all data
    Future<List> getCmdPanier() async {
    final db = await database;
    var res = await db.query("panier");
    return res.toList();
  }

   

  Future<List> getCategorie() async {
    final db = await database;
    var res = await db.query("categorie");
    return res.toList();
  }

  Future<List> getProduit() async {
    final db = await database;
    var res = await db.query("produit_pos");
    return res.toList();
  }

  Future<List> getActivation() async {
    final db = await database;
    var res = await db.query("activation");
    return res.toList();
  }

  ActivationDate() async {
    final db = await database;
    var table = await db.rawQuery("SELECT * FROM activation order by id desc");
    String name_id = table.first['date_act'];
    return name_id;
  }

  EditCategorie(String categorie, int id) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
    UPDATE categorie 
    SET categorie = ?
    WHERE id = ?
    ''', ['$categorie', id]);
  }

  EditSubCategorie(String categorie, int id) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
    UPDATE souscategorie 
    SET subcategorie = ?
    WHERE id = ?
    ''', ['$categorie', id]);
  }

  EditClient(String client, int id) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
    UPDATE client 
    SET client = ?
    WHERE id = ?
    ''', ['$client', id]);
  }
  //edit produit

//edit taux
  EditTaux(int id, String usd) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
      UPDATE taux 
      SET usd = ?
      WHERE id = ?
      ''', [usd,'$id']);
  }

  EditProduit(int id, String produit, String categorie, String image,
      String prix, String device,id_sub) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
    UPDATE produit_pos 
    SET produit = ?,
    categorie=?,
    image_produit=?,
    prix=?,
    devise=?,
    id_sub=?
    WHERE id = ?
    ''', [produit, categorie, image, prix, device,id_sub, '$id']);
  }




  //edit business name
EditInfos(int id, String name,String email,String telephone,String adresse) async {
    final db = await database;
    int updateCount = await db.rawUpdate('''
      UPDATE profile 
      SET businesse = ?,email=?,telephone=?,adresse=?
      WHERE id = ?
      ''', [name,email,telephone,adresse,'$id']);
  }
}

