import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/cupertino.dart';
import 'package:smartpos/commons/radial_progress.dart';
import 'package:smartpos/commons/rounded_image.dart';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:smartpos/styleguides/text_style.dart';
import 'package:smartpos/utils/Database.dart';
String profile_name="";
String photo="";
class MyInfo extends StatefulWidget {
  @override
  _MyInfoState createState() => _MyInfoState();
}
Uint8List _image;
Image img=Image(image: AssetImage('assets/images/client.png'),);

class _MyInfoState extends State<MyInfo> {

  void getProfile() async{
    String  profile = await DBProvider_new.db.getNom_Profile();
    setState(() => profile_name = profile);

  }
  //_image= base64Decode(item.image);
  //profile
  void getPhoto() async{
    String  photo1 = await DBProvider_new.db.getPhoto();
   // setState(() =>  img=Image.memory(base64Decode(photo)));

    setState(() {
      photo=photo1;
    });

  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      getProfile();
      getPhoto();
      /* getProfile();
      getPhoto();*/
    });
  }
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

          /*RadialProgress(
              width: 4,
              goalCompleted: 0.9,
              child: Container(
                width: 70.0,
                height: 70.0,
                child: ClipOval(
                  child:photo== null
                      ? new Text('No image.')
                      :  Image.file(
                    File(photo),
                    fit: BoxFit.contain,
                  ),
                ),
              )

          ),*/

          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                ""+profile_name,
                style: whiteNameTextStyle,
              ),

            ],
          ),
          SizedBox(height: 5,),
        ],
      ),
    );
  }
}
